-- Advanced Inventory Forecasting Schema
-- Manages demand forecasting, stock optimization, and predictive analytics

CREATE TABLE IF NOT EXISTS inventory_forecasts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  forecast_period_start DATE NOT NULL,
  forecast_period_end DATE NOT NULL,
  forecast_method VARCHAR(50), -- 'moving_average', 'exponential_smoothing', 'linear_regression', 'seasonal'
  forecasted_demand INTEGER,
  confidence_level DECIMAL(5, 2), -- 0-100
  lower_bound INTEGER,
  upper_bound INTEGER,
  actual_demand INTEGER,
  accuracy_percentage DECIMAL(5, 2),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS stock_optimization (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  reorder_point INTEGER, -- Minimum stock level
  reorder_quantity INTEGER, -- Quantity to order
  safety_stock INTEGER, -- Buffer stock
  lead_time_days INTEGER,
  holding_cost DECIMAL(10, 2), -- Cost per unit per year
  ordering_cost DECIMAL(10, 2), -- Cost per order
  economic_order_quantity INTEGER, -- EOQ calculation
  last_calculated_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(company_id, product_id)
);

CREATE TABLE IF NOT EXISTS demand_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  demand_date DATE NOT NULL,
  quantity_sold INTEGER,
  revenue DECIMAL(15, 2),
  season VARCHAR(20), -- 'spring', 'summer', 'fall', 'winter'
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(company_id, product_id, demand_date)
);

CREATE TABLE IF NOT EXISTS inventory_alerts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  alert_type VARCHAR(50), -- 'low_stock', 'overstock', 'slow_moving', 'stockout_risk'
  current_stock INTEGER,
  threshold_value INTEGER,
  severity VARCHAR(20), -- 'low', 'medium', 'high', 'critical'
  is_resolved BOOLEAN DEFAULT FALSE,
  resolved_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS supplier_performance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  supplier_id UUID, -- Reference to supplier
  on_time_delivery_rate DECIMAL(5, 2),
  quality_score DECIMAL(5, 2),
  average_lead_time_days INTEGER,
  total_orders INTEGER,
  defect_rate DECIMAL(5, 2),
  last_evaluated_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_inventory_forecasts_company ON inventory_forecasts(company_id);
CREATE INDEX idx_inventory_forecasts_product ON inventory_forecasts(product_id);
CREATE INDEX idx_stock_optimization_company ON stock_optimization(company_id);
CREATE INDEX idx_demand_history_company ON demand_history(company_id);
CREATE INDEX idx_demand_history_date ON demand_history(demand_date);
CREATE INDEX idx_inventory_alerts_company ON inventory_alerts(company_id);
CREATE INDEX idx_inventory_alerts_severity ON inventory_alerts(severity);

ALTER TABLE inventory_forecasts ENABLE ROW LEVEL SECURITY;
ALTER TABLE stock_optimization ENABLE ROW LEVEL SECURITY;
ALTER TABLE demand_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory_alerts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view inventory forecasts in their company"
  ON inventory_forecasts FOR SELECT
  USING (company_id IN (SELECT company_id FROM company_members WHERE user_id = auth.uid()));

CREATE POLICY "Users can view stock optimization in their company"
  ON stock_optimization FOR SELECT
  USING (company_id IN (SELECT company_id FROM company_members WHERE user_id = auth.uid()));

CREATE POLICY "Users can view demand history in their company"
  ON demand_history FOR SELECT
  USING (company_id IN (SELECT company_id FROM company_members WHERE user_id = auth.uid()));

CREATE POLICY "Users can view inventory alerts in their company"
  ON inventory_alerts FOR SELECT
  USING (company_id IN (SELECT company_id FROM company_members WHERE user_id = auth.uid()));
