-- Multi-Currency Support Schema
-- Adds currency management, exchange rates, and multi-currency transactions

-- Create currencies table
CREATE TABLE IF NOT EXISTS currencies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  code VARCHAR(3) NOT NULL UNIQUE, -- ISO 4217 code (USD, EUR, INR, etc.)
  name VARCHAR(100) NOT NULL,
  symbol VARCHAR(10),
  exchange_rate DECIMAL(18, 6) NOT NULL DEFAULT 1.0, -- Rate to base currency
  is_base_currency BOOLEAN DEFAULT FALSE,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(company_id, code)
);

-- Create exchange_rates table for historical tracking
CREATE TABLE IF NOT EXISTS exchange_rates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  from_currency_id UUID NOT NULL REFERENCES currencies(id) ON DELETE CASCADE,
  to_currency_id UUID NOT NULL REFERENCES currencies(id) ON DELETE CASCADE,
  rate DECIMAL(18, 8) NOT NULL,
  rate_date DATE NOT NULL,
  source VARCHAR(50), -- API source (ECB, OANDA, etc.)
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(company_id, from_currency_id, to_currency_id, rate_date)
);

-- Create multi_currency_transactions table
CREATE TABLE IF NOT EXISTS multi_currency_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  transaction_id UUID NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
  original_currency_id UUID NOT NULL REFERENCES currencies(id),
  original_amount DECIMAL(18, 2) NOT NULL,
  base_currency_id UUID NOT NULL REFERENCES currencies(id),
  base_amount DECIMAL(18, 2) NOT NULL,
  exchange_rate DECIMAL(18, 8) NOT NULL,
  exchange_rate_date DATE NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create currency_conversion_logs table
CREATE TABLE IF NOT EXISTS currency_conversion_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  from_currency_id UUID NOT NULL REFERENCES currencies(id),
  to_currency_id UUID NOT NULL REFERENCES currencies(id),
  amount DECIMAL(18, 2) NOT NULL,
  converted_amount DECIMAL(18, 2) NOT NULL,
  exchange_rate DECIMAL(18, 8) NOT NULL,
  conversion_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_by UUID REFERENCES auth.users(id)
);

-- Create indexes
CREATE INDEX idx_currencies_company ON currencies(company_id);
CREATE INDEX idx_exchange_rates_company ON exchange_rates(company_id);
CREATE INDEX idx_exchange_rates_date ON exchange_rates(rate_date);
CREATE INDEX idx_multi_currency_transactions_company ON multi_currency_transactions(company_id);
CREATE INDEX idx_currency_conversion_logs_company ON currency_conversion_logs(company_id);

-- Enable RLS
ALTER TABLE currencies ENABLE ROW LEVEL SECURITY;
ALTER TABLE exchange_rates ENABLE ROW LEVEL SECURITY;
ALTER TABLE multi_currency_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE currency_conversion_logs ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view currencies in their company"
  ON currencies FOR SELECT
  USING (company_id IN (SELECT company_id FROM company_members WHERE user_id = auth.uid()));

CREATE POLICY "Admins can manage currencies"
  ON currencies FOR ALL
  USING (company_id IN (SELECT company_id FROM company_members WHERE user_id = auth.uid() AND role = 'admin'));

CREATE POLICY "Users can view exchange rates in their company"
  ON exchange_rates FOR SELECT
  USING (company_id IN (SELECT company_id FROM company_members WHERE user_id = auth.uid()));

CREATE POLICY "Admins can manage exchange rates"
  ON exchange_rates FOR ALL
  USING (company_id IN (SELECT company_id FROM company_members WHERE user_id = auth.uid() AND role = 'admin'));

CREATE POLICY "Users can view multi-currency transactions in their company"
  ON multi_currency_transactions FOR SELECT
  USING (company_id IN (SELECT company_id FROM company_members WHERE user_id = auth.uid()));

CREATE POLICY "Users can view currency conversion logs in their company"
  ON currency_conversion_logs FOR SELECT
  USING (company_id IN (SELECT company_id FROM company_members WHERE user_id = auth.uid()));
