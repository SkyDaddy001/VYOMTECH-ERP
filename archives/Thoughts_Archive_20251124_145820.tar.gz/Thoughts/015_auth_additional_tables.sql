-- Additional auth tables for complete authentication system
-- This migration adds missing auth tables like sessions, refresh_tokens, etc.

-- Create auth schema if it doesn't exist
CREATE SCHEMA IF NOT EXISTS auth;

-- Create auth.sessions table
CREATE TABLE IF NOT EXISTS auth.sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  factor_id UUID,
  aal TEXT,
  not_after TIMESTAMP WITH TIME ZONE,
  refreshed_at TIMESTAMP WITH TIME ZONE,
  user_agent TEXT,
  ip TEXT,
  tag TEXT
);

-- Create auth.refresh_tokens table
CREATE TABLE IF NOT EXISTS auth.refresh_tokens (
  id BIGSERIAL PRIMARY KEY,
  instance_id UUID,
  token TEXT UNIQUE NOT NULL,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  revoked BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  parent TEXT,
  session_id UUID REFERENCES auth.sessions(id) ON DELETE CASCADE
);

-- Create auth.instances table
CREATE TABLE IF NOT EXISTS auth.instances (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  uuid UUID,
  raw_base_config TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create auth.audit_log_entries table
CREATE TABLE IF NOT EXISTS auth.audit_log_entries (
  instance_id UUID,
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  payload JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  ip_address TEXT DEFAULT '',
  session_id UUID REFERENCES auth.sessions(id) ON DELETE CASCADE
);

-- Create auth.identities table
CREATE TABLE IF NOT EXISTS auth.identities (
  id TEXT PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  identity_data JSONB NOT NULL,
  provider TEXT NOT NULL,
  last_sign_in_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  email TEXT GENERATED ALWAYS AS (lower(identity_data->>'email')) STORED,
  UNIQUE(provider, id)
);

-- Create auth.mfa_amr_claims table
CREATE TABLE IF NOT EXISTS auth.mfa_amr_claims (
  session_id UUID NOT NULL REFERENCES auth.sessions(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  authentication_method TEXT NOT NULL,
  id UUID PRIMARY KEY DEFAULT gen_random_uuid()
);

-- Create auth.mfa_challenges table
CREATE TABLE IF NOT EXISTS auth.mfa_challenges (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  factor_id UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  verified_at TIMESTAMP WITH TIME ZONE,
  ip_address TEXT NOT NULL
);

-- Create auth.mfa_factors table
CREATE TABLE IF NOT EXISTS auth.mfa_factors (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  friendly_name TEXT,
  factor_type TEXT NOT NULL CHECK (factor_type IN ('totp', 'webauthn')),
  status TEXT NOT NULL CHECK (status IN ('unverified', 'verified')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  secret TEXT,
  phone TEXT,
  last_challenged_at TIMESTAMP WITH TIME ZONE,
  UNIQUE(user_id, phone)
);

-- Create auth.flow_state table
CREATE TABLE IF NOT EXISTS auth.flow_state (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  auth_code TEXT NOT NULL,
  code_challenge_method TEXT NOT NULL CHECK (code_challenge_method IN ('s256', 'plain')),
  code_challenge TEXT NOT NULL,
  provider_type TEXT NOT NULL,
  provider_access_token TEXT,
  provider_refresh_token TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  authentication_method TEXT NOT NULL,
  auth_code_encrypted TEXT NOT NULL
);

-- Create auth.one_time_tokens table
CREATE TABLE IF NOT EXISTS auth.one_time_tokens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  token_type TEXT NOT NULL CHECK (token_type IN ('confirmation_token', 'recovery_token', 'email_change_token_new', 'email_change_token_current', 'phone_change_token')),
  token_hash TEXT NOT NULL,
  relates_to TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, token_type)
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON auth.sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_refresh_tokens_user_id ON auth.refresh_tokens(user_id);
CREATE INDEX IF NOT EXISTS idx_refresh_tokens_token ON auth.refresh_tokens(token);
CREATE INDEX IF NOT EXISTS idx_refresh_tokens_session_id ON auth.refresh_tokens(session_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_entries_instance_id ON auth.audit_log_entries(instance_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_entries_session_id ON auth.audit_log_entries(session_id);
CREATE INDEX IF NOT EXISTS idx_identities_user_id ON auth.identities(user_id);
CREATE INDEX IF NOT EXISTS idx_identities_email ON auth.identities(email);
CREATE INDEX IF NOT EXISTS idx_mfa_amr_claims_session_id ON auth.mfa_amr_claims(session_id);
CREATE INDEX IF NOT EXISTS idx_mfa_challenges_factor_id ON auth.mfa_challenges(factor_id);
CREATE INDEX IF NOT EXISTS idx_mfa_factors_user_id ON auth.mfa_factors(user_id);
CREATE INDEX IF NOT EXISTS idx_flow_state_user_id ON auth.flow_state(user_id);
CREATE INDEX IF NOT EXISTS idx_one_time_tokens_user_id ON auth.one_time_tokens(user_id);
CREATE INDEX IF NOT EXISTS idx_one_time_tokens_token_hash ON auth.one_time_tokens(token_hash);

-- Grant permissions
GRANT ALL ON SCHEMA auth TO postgres;
GRANT ALL ON ALL TABLES IN SCHEMA auth TO postgres;
GRANT ALL ON ALL SEQUENCES IN SCHEMA auth TO postgres;
