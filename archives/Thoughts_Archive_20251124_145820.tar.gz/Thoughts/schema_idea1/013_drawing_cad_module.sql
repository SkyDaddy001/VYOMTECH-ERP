-- Drawing & CAD Management Module
CREATE TABLE drawing_projects (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL REFERENCES core_clients(id),
    project_name VARCHAR(200) NOT NULL,
    description TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by CHAR(26) REFERENCES core_users(id),
    updated_by CHAR(26) REFERENCES core_users(id),
    company_id CHAR(26),
    INDEX idx_client_company (client_id, company_id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
);

CREATE TABLE drawing_files (
    id CHAR(26) PRIMARY KEY,
    project_id CHAR(26) NOT NULL REFERENCES drawing_projects(id),
    file_name VARCHAR(255) NOT NULL,
    file_type VARCHAR(50) NOT NULL, -- CAD, BIM, PDF, etc.
    file_path TEXT NOT NULL,
    file_size BIGINT NOT NULL,
    version INT NOT NULL DEFAULT 1,
    metadata JSON, -- For BIM data and other metadata
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by CHAR(26) REFERENCES core_users(id),
    updated_by CHAR(26) REFERENCES core_users(id),
    company_id CHAR(26),
    INDEX idx_project_company (project_id, company_id),
    INDEX idx_type_company (file_type, company_id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
);

CREATE TABLE drawing_versions (
    id CHAR(26) PRIMARY KEY,
    drawing_id CHAR(26) NOT NULL REFERENCES drawing_files(id),
    version_number INT NOT NULL,
    change_notes TEXT,
    file_path TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by CHAR(26) REFERENCES core_users(id)
);

CREATE TABLE drawing_annotations (
    id CHAR(26) PRIMARY KEY,
    drawing_id CHAR(26) NOT NULL REFERENCES drawing_files(id),
    annotation_type VARCHAR(50) NOT NULL, -- markup, comment, revision
    coordinates JSON NOT NULL, -- stores x,y coordinates or vectors
    content TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by CHAR(26) REFERENCES core_users(id),
    updated_by CHAR(26) REFERENCES core_users(id)
);

CREATE TABLE bim_data (
    id CHAR(26) PRIMARY KEY,
    drawing_id CHAR(26) NOT NULL REFERENCES drawing_files(id),
    element_type VARCHAR(100) NOT NULL,
    element_id VARCHAR(100) NOT NULL,
    properties JSON NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_drawing_company (drawing_id, company_id),
    INDEX idx_element_company (element_type, company_id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
);