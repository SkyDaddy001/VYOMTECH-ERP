-- Dashboard Module - Analytics and Reporting

-- Dashboard Templates
CREATE TABLE dash_templates (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    type VARCHAR(50) NOT NULL,
    layout JSON NOT NULL,
    widgets JSON NOT NULL,
    filters JSON,
    permissions JSON,
    is_system BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    created_by CHAR(26) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_client_type (client_id, type),
    INDEX idx_client_company (client_id, company_id),
    INDEX idx_type_company (type, company_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (created_by) REFERENCES core_users(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- User Dashboards
CREATE TABLE dash_instances (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    template_id CHAR(26) NOT NULL,
    user_id CHAR(26) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    layout JSON NOT NULL,
    widgets JSON NOT NULL,
    filters JSON,
    is_favorite BOOLEAN DEFAULT FALSE,
    sort_order INT DEFAULT 0,
    last_viewed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_client_user (client_id, user_id),
    INDEX idx_template (template_id),
    INDEX idx_client_company (client_id, company_id),
    INDEX idx_template_company (template_id, company_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (template_id) REFERENCES dash_templates(id),
    FOREIGN KEY (user_id) REFERENCES core_users(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Saved Reports
CREATE TABLE dash_reports (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    type VARCHAR(50) NOT NULL,
    query JSON NOT NULL,
    filters JSON,
    columns JSON,
    sort_options JSON,
    chart_config JSON,
    schedule JSON,
    last_run_at TIMESTAMP NULL,
    next_run_at TIMESTAMP NULL,
    created_by CHAR(26) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_client_type (client_id, type),
    INDEX idx_client_company (client_id, company_id),
    INDEX idx_type_company (type, company_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (created_by) REFERENCES core_users(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Report Subscriptions
CREATE TABLE dash_report_subscriptions (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    report_id CHAR(26) NOT NULL,
    user_id CHAR(26) NOT NULL,
    frequency ENUM('daily', 'weekly', 'monthly', 'quarterly') NOT NULL,
    day_of_week INT,
    day_of_month INT,
    time_of_day TIME NOT NULL,
    timezone VARCHAR(50) DEFAULT 'UTC',
    format ENUM('pdf', 'excel', 'csv') NOT NULL,
    email_to VARCHAR(255) NOT NULL,
    last_sent_at TIMESTAMP NULL,
    next_send_at TIMESTAMP NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_report (report_id),
    INDEX idx_user (user_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (report_id) REFERENCES dash_reports(id),
    FOREIGN KEY (user_id) REFERENCES core_users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- KPI Definitions
CREATE TABLE dash_kpis (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    code VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(50) NOT NULL,
    calculation_method JSON NOT NULL,
    data_source JSON NOT NULL,
    unit VARCHAR(50),
    frequency ENUM('realtime', 'hourly', 'daily', 'weekly', 'monthly') NOT NULL,
    thresholds JSON,
    comparison_period VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_client_category (client_id, category),
    INDEX idx_client_company (client_id, company_id),
    INDEX idx_category_company (category, company_id),
    UNIQUE KEY uk_client_code (client_id, code),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- KPI Values
CREATE TABLE dash_kpi_values (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    kpi_id CHAR(26) NOT NULL,
    period_type VARCHAR(50) NOT NULL,
    period_value VARCHAR(50) NOT NULL,
    actual_value DECIMAL(15,4) NOT NULL,
    target_value DECIMAL(15,4),
    comparison_value DECIMAL(15,4),
    growth_percentage DECIMAL(8,4),
    status VARCHAR(50),
    metadata JSON,
    calculated_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_client_kpi (client_id, kpi_id),
    INDEX idx_period (period_type, period_value),
    INDEX idx_client_company (client_id, company_id),
    INDEX idx_kpi_company (kpi_id, company_id),
    UNIQUE KEY uk_kpi_period (kpi_id, period_type, period_value),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (kpi_id) REFERENCES dash_kpis(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Alerts
CREATE TABLE dash_alerts (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    kpi_id CHAR(26),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    conditions JSON NOT NULL,
    severity ENUM('info', 'warning', 'critical') NOT NULL,
    notification_channels JSON,
    is_active BOOLEAN DEFAULT TRUE,
    last_triggered_at TIMESTAMP NULL,
    created_by CHAR(26) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_client_severity (client_id, severity),
    INDEX idx_kpi (kpi_id),
    INDEX idx_client_company (client_id, company_id),
    INDEX idx_severity_company (severity, company_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (kpi_id) REFERENCES dash_kpis(id),
    FOREIGN KEY (created_by) REFERENCES core_users(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Alert History
CREATE TABLE dash_alert_history (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    alert_id CHAR(26) NOT NULL,
    triggered_value JSON NOT NULL,
    notification_sent BOOLEAN DEFAULT FALSE,
    notification_status JSON,
    resolved_at TIMESTAMP NULL,
    resolution_note TEXT,
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_alert (alert_id),
    INDEX idx_client_date (client_id, created_at),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (alert_id) REFERENCES dash_alerts(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;