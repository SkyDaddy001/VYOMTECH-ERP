-- Marketing Module - Campaigns, Channel Partners, and Analytics

-- Campaign Management
CREATE TABLE mkt_campaigns (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    parent_id CHAR(26),
    name VARCHAR(255) NOT NULL,
    type ENUM('awareness', 'lead_generation', 'sales', 'retention', 'referral') NOT NULL,
    status ENUM('draft', 'active', 'paused', 'completed', 'cancelled') NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE,
    budget DECIMAL(15,2),
    spent_amount DECIMAL(15,2) DEFAULT 0,
    target_audience JSON,
    goals JSON,
    kpis JSON,
    description TEXT,
    metadata JSON,
    created_by CHAR(26) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_client_status (client_id, status),
    INDEX idx_parent (parent_id),
    INDEX idx_date (start_date, end_date),
    INDEX idx_client_company (client_id, company_id),
    INDEX idx_client_status_company (client_id, status, company_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (parent_id) REFERENCES mkt_campaigns(id),
    FOREIGN KEY (created_by) REFERENCES core_users(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Campaign Channels
CREATE TABLE mkt_campaign_channels (
    id CHAR(26) PRIMARY KEY,
    campaign_id CHAR(26) NOT NULL,
    channel_type VARCHAR(50) NOT NULL,
    platform VARCHAR(50),
    budget DECIMAL(15,2),
    spent_amount DECIMAL(15,2) DEFAULT 0,
    start_date DATE,
    end_date DATE,
    target_metrics JSON,
    actual_metrics JSON,
    content_urls JSON,
    tracking_codes JSON,
    settings JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_campaign (campaign_id),
    INDEX idx_channel (channel_type),
    INDEX idx_campaign_company (campaign_id, company_id),
    FOREIGN KEY (campaign_id) REFERENCES mkt_campaigns(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Channel Partner Management
CREATE TABLE mkt_channel_partners (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    code VARCHAR(50) NOT NULL,
    type ENUM('broker', 'agency', 'referral', 'affiliate') NOT NULL,
    company_name VARCHAR(255) NOT NULL,
    contact_person VARCHAR(255),
    email VARCHAR(255),
    phone VARCHAR(50),
    alternate_phone VARCHAR(50),
    address TEXT,
    city VARCHAR(100),
    state VARCHAR(100),
    country VARCHAR(100),
    pincode VARCHAR(20),
    gst_number VARCHAR(20),
    pan_number VARCHAR(20),
    bank_details JSON,
    commission_structure JSON,
    credit_limit DECIMAL(15,2),
    credit_used DECIMAL(15,2) DEFAULT 0,
    status ENUM('active', 'inactive', 'suspended', 'blacklisted') DEFAULT 'active',
    kyc_status ENUM('pending', 'verified', 'rejected') DEFAULT 'pending',
    documents JSON,
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_client_status (client_id, status),
    UNIQUE KEY uk_client_code (client_id, code),
    FOREIGN KEY (client_id) REFERENCES core_clients(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Partner Campaign Performance
CREATE TABLE mkt_partner_campaigns (
    id CHAR(26) PRIMARY KEY,
    partner_id CHAR(26) NOT NULL,
    campaign_id CHAR(26) NOT NULL,
    target_leads INT,
    actual_leads INT DEFAULT 0,
    target_sales INT,
    actual_sales INT DEFAULT 0,
    commission_earned DECIMAL(15,2) DEFAULT 0,
    commission_paid DECIMAL(15,2) DEFAULT 0,
    start_date DATE NOT NULL,
    end_date DATE,
    status ENUM('active', 'completed', 'terminated') DEFAULT 'active',
    performance_metrics JSON,
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_partner (partner_id),
    INDEX idx_campaign (campaign_id),
    FOREIGN KEY (partner_id) REFERENCES mkt_channel_partners(id),
    FOREIGN KEY (campaign_id) REFERENCES mkt_campaigns(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Partner Commissions and Settlements
CREATE TABLE mkt_partner_commissions (
    id CHAR(26) PRIMARY KEY,
    partner_id CHAR(26) NOT NULL,
    booking_id CHAR(26) NOT NULL,
    campaign_id CHAR(26),
    commission_type VARCHAR(50) NOT NULL,
    base_amount DECIMAL(15,2) NOT NULL,
    commission_rate DECIMAL(5,2) NOT NULL,
    commission_amount DECIMAL(15,2) NOT NULL,
    tax_rate DECIMAL(5,2),
    tax_amount DECIMAL(15,2),
    net_amount DECIMAL(15,2) NOT NULL,
    status ENUM('calculated', 'approved', 'rejected', 'paid') DEFAULT 'calculated',
    payment_date DATE,
    payment_reference VARCHAR(100),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_partner (partner_id),
    INDEX idx_booking (booking_id),
    INDEX idx_campaign (campaign_id),
    FOREIGN KEY (partner_id) REFERENCES mkt_channel_partners(id),
    FOREIGN KEY (booking_id) REFERENCES prop_bookings(id),
    FOREIGN KEY (campaign_id) REFERENCES mkt_campaigns(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Marketing Analytics
CREATE TABLE mkt_analytics (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    campaign_id CHAR(26),
    channel_id CHAR(26),
    metric_date DATE NOT NULL,
    metric_type VARCHAR(50) NOT NULL,
    metric_value DECIMAL(15,4) NOT NULL,
    dimension_type VARCHAR(50),
    dimension_value VARCHAR(255),
    metadata JSON,
    company_id CHAR(26),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_client_date (client_id, metric_date),
    INDEX idx_campaign (campaign_id),
    INDEX idx_channel (channel_id),
    INDEX idx_metric (metric_type),
    INDEX idx_client_company (client_id, company_id),
    INDEX idx_campaign_company_date (campaign_id, company_id, metric_date),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (campaign_id) REFERENCES mkt_campaigns(id),
    FOREIGN KEY (channel_id) REFERENCES mkt_campaign_channels(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Campaign Lead Attribution
CREATE TABLE mkt_campaign_leads (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    campaign_id CHAR(26) NOT NULL,
    lead_id CHAR(26) NOT NULL,
    channel_id CHAR(26),
    attribution_type ENUM('first_touch', 'last_touch', 'multi_touch') NOT NULL,
    touch_point_order INT NOT NULL,
    attribution_score DECIMAL(5,2) DEFAULT 1.00,
    source_details JSON,
    utm_parameters JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_campaign (campaign_id),
    INDEX idx_lead (lead_id),
    INDEX idx_channel (channel_id),
    UNIQUE KEY uk_campaign_lead_touch (campaign_id, lead_id, touch_point_order),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (campaign_id) REFERENCES mkt_campaigns(id),
    FOREIGN KEY (lead_id) REFERENCES crm_leads(id),
    FOREIGN KEY (channel_id) REFERENCES mkt_campaign_channels(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Lead Credit Rules
CREATE TABLE mkt_lead_credit_rules (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    attribution_model ENUM('first_touch', 'last_touch', 'linear', 'time_decay', 'position_based', 'custom') NOT NULL,
    credit_weights JSON, -- For custom attribution models
    lookback_window_days INT DEFAULT 30,
    exclusion_criteria JSON,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_client (client_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Lead Credit Attribution
CREATE TABLE mkt_lead_credits (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    lead_id CHAR(26) NOT NULL,
    campaign_id CHAR(26) NOT NULL,
    channel_id CHAR(26),
    partner_id CHAR(26),
    rule_id CHAR(26) NOT NULL,
    credit_value DECIMAL(15,2) NOT NULL,
    credit_percentage DECIMAL(5,2) NOT NULL,
    conversion_type VARCHAR(50),
    conversion_value DECIMAL(15,2),
    attribution_data JSON,
    company_id CHAR(26),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_lead (lead_id),
    INDEX idx_campaign (campaign_id),
    INDEX idx_partner (partner_id),
    INDEX idx_client_company (client_id, company_id),
    INDEX idx_campaign_company (campaign_id, company_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (lead_id) REFERENCES crm_leads(id),
    FOREIGN KEY (campaign_id) REFERENCES mkt_campaigns(id),
    FOREIGN KEY (channel_id) REFERENCES mkt_campaign_channels(id),
    FOREIGN KEY (partner_id) REFERENCES mkt_channel_partners(id),
    FOREIGN KEY (rule_id) REFERENCES mkt_lead_credit_rules(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Campaign Attribution Summary
CREATE TABLE mkt_campaign_attribution_summary (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    campaign_id CHAR(26) NOT NULL,
    channel_id CHAR(26),
    date DATE NOT NULL,
    total_leads INT DEFAULT 0,
    attributed_leads INT DEFAULT 0,
    total_credit_value DECIMAL(15,2) DEFAULT 0,
    conversion_value DECIMAL(15,2) DEFAULT 0,
    attribution_metrics JSON,
    company_id CHAR(26),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_campaign_date (campaign_id, date),
    INDEX idx_channel (channel_id),
    INDEX idx_client_company (client_id, company_id),
    INDEX idx_campaign_company_date (campaign_id, company_id, date),
    UNIQUE KEY uk_campaign_channel_date (campaign_id, channel_id, date),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (campaign_id) REFERENCES mkt_campaigns(id),
    FOREIGN KEY (channel_id) REFERENCES mkt_campaign_channels(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Marketing Campaign Analytics Optimization
CREATE TABLE mkt_campaign_metrics (
    id CHAR(26) PRIMARY KEY,
    campaign_id CHAR(26) NOT NULL,
    channel_id CHAR(26),
    metric_date DATE NOT NULL,
    impressions BIGINT DEFAULT 0,
    clicks BIGINT DEFAULT 0,
    conversions INT DEFAULT 0,
    spend DECIMAL(15,2) DEFAULT 0,
    revenue DECIMAL(15,2) DEFAULT 0,
    metrics JSON CHECK (JSON_VALID(metrics)),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_campaign_date (campaign_id, metric_date), -- For campaign performance analysis
    INDEX idx_channel_metrics (channel_id, metric_date), -- For channel performance
    FOREIGN KEY (campaign_id) REFERENCES mkt_campaigns(id),
    FOREIGN KEY (channel_id) REFERENCES mkt_campaign_channels(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
PARTITION BY RANGE COLUMNS(metric_date) ( -- Partition by date for efficient analytics
    PARTITION p_2024h1 VALUES LESS THAN ('2024-07-01'),
    PARTITION p_2024h2 VALUES LESS THAN ('2025-01-01'),
    PARTITION p_future VALUES LESS THAN (MAXVALUE)
);

-- Campaign Attribution Optimization
CREATE TABLE mkt_campaign_attribution (
    id CHAR(26) PRIMARY KEY,
    lead_id CHAR(26) NOT NULL,
    campaign_id CHAR(26) NOT NULL,
    channel_id CHAR(26),
    touch_point_date TIMESTAMP NOT NULL,
    touch_point_type VARCHAR(50) NOT NULL,
    contribution_weight DECIMAL(5,4) DEFAULT 1.0,
    revenue_share DECIMAL(15,2) DEFAULT 0,
    attribution_data JSON CHECK (JSON_VALID(attribution_data)),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_lead_campaign (lead_id, campaign_id), -- For lead journey analysis
    INDEX idx_channel_date (channel_id, touch_point_date), -- For channel attribution
    INDEX idx_revenue (revenue_share), -- For ROI analysis
    FOREIGN KEY (lead_id) REFERENCES crm_leads(id),
    FOREIGN KEY (campaign_id) REFERENCES mkt_campaigns(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
PARTITION BY HASH(YEAR(touch_point_date)) -- Partition by year for historical analysis
PARTITIONS 4;