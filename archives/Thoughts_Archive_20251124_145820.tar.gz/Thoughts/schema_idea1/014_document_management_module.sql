-- Document Management Module
CREATE TABLE document_categories (
    id CHAR(26) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    parent_id CHAR(26) REFERENCES document_categories(id),
    client_id CHAR(26) NOT NULL REFERENCES core_clients(id),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_hierarchy (parent_id, client_id) -- Optimize hierarchy queries
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE document_templates (
    id CHAR(26) PRIMARY KEY,
    category_id CHAR(26) REFERENCES document_categories(id),
    name VARCHAR(200) NOT NULL,
    content TEXT,
    metadata JSON,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE documents (
    id CHAR(26) PRIMARY KEY,
    category_id CHAR(26) REFERENCES document_categories(id),
    template_id CHAR(26) REFERENCES document_templates(id),
    title VARCHAR(255) NOT NULL,
    file_path TEXT NOT NULL ENCRYPTED, -- Encrypt sensitive file paths
    version INT NOT NULL DEFAULT 1,
    status VARCHAR(50) NOT NULL, -- draft, in_review, approved, archived
    checked_out_by CHAR(26) REFERENCES core_users(id),
    checked_out_at TIMESTAMP,
    metadata JSON,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by CHAR(26) REFERENCES core_users(id),
    updated_by CHAR(26) REFERENCES core_users(id),
    INDEX idx_category_status (category_id, status), -- Optimize document listing
    INDEX idx_version_date (version, created_at), -- For version history queries
    FULLTEXT INDEX ft_title (title), -- Enable full text search on titles
    INDEX idx_checkout (checked_out_by, checked_out_at) -- Optimize checkout queries
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
ROW_FORMAT=COMPRESSED -- Enable compression for storage efficiency
KEY_BLOCK_SIZE=8;

CREATE TABLE document_versions (
    id CHAR(26) PRIMARY KEY,
    document_id CHAR(26) NOT NULL REFERENCES documents(id),
    version_number INT NOT NULL,
    file_path TEXT NOT NULL ENCRYPTED,
    change_summary TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by CHAR(26) REFERENCES core_users(id),
    INDEX idx_doc_version (document_id, version_number), -- Optimize version history
    INDEX idx_created (created_at) -- For audit trails
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
ROW_FORMAT=COMPRESSED
KEY_BLOCK_SIZE=8;

CREATE TABLE document_workflows (
    id CHAR(26) PRIMARY KEY,
    document_id CHAR(26) NOT NULL REFERENCES documents(id),
    workflow_type VARCHAR(50) NOT NULL,
    current_step INT NOT NULL,
    status VARCHAR(50) NOT NULL,
    approvers JSON NOT NULL, -- Array of user IDs and their approval status
    due_date TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_doc_status (document_id, status), -- Optimize workflow queries
    INDEX idx_due_date (due_date) -- For deadline monitoring
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE digital_signatures (
    id CHAR(26) PRIMARY KEY,
    document_id CHAR(26) NOT NULL REFERENCES documents(id),
    user_id CHAR(26) NOT NULL REFERENCES core_users(id),
    signature_data TEXT NOT NULL,
    signature_timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    certificate_data JSON,
    ip_address VARCHAR(45)
);