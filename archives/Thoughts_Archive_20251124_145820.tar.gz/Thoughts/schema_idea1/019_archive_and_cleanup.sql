-- Archive tables with compression for historical data
CREATE TABLE archived_call_records (
    id CHAR(26) PRIMARY KEY,
    original_id CHAR(26) NOT NULL,
    archive_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    record_data JSON NOT NULL CHECK (JSON_VALID(record_data)),
    INDEX idx_original (original_id),
    INDEX idx_archive_date (archive_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
ROW_FORMAT=COMPRESSED KEY_BLOCK_SIZE=8;

CREATE TABLE archived_sensor_readings (
    id CHAR(26) PRIMARY KEY,
    original_id CHAR(26) NOT NULL,
    archive_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    reading_data JSON NOT NULL CHECK (JSON_VALID(reading_data)),
    INDEX idx_original (original_id),
    INDEX idx_archive_date (archive_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
ROW_FORMAT=COMPRESSED KEY_BLOCK_SIZE=8;

-- Standard Archive Configuration
CREATE TABLE sys_archive_policies (
    id CHAR(26) PRIMARY KEY,
    table_name VARCHAR(100) NOT NULL,
    archive_after_days INT NOT NULL,
    archive_retention_days INT NOT NULL,
    compression_enabled BOOLEAN DEFAULT TRUE,
    partition_key VARCHAR(100),
    archive_procedure VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    last_archived_at TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_table (table_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Temporal Data Management
CREATE TABLE sys_temporal_settings (
    id CHAR(26) PRIMARY KEY,
    table_name VARCHAR(100) NOT NULL,
    valid_time_tracking BOOLEAN DEFAULT FALSE,
    transaction_time_tracking BOOLEAN DEFAULT FALSE,
    bitemporal_tracking BOOLEAN DEFAULT FALSE,
    history_retention_days INT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_table (table_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Cleanup procedures
DELIMITER //

CREATE PROCEDURE sp_archive_old_call_records(IN days_old INT)
BEGIN
    INSERT INTO archived_call_records (original_id, record_data)
    SELECT id, JSON_OBJECT(
        'client_id', client_id,
        'queue_id', queue_id,
        'agent_id', agent_id,
        'call_data', JSON_OBJECT(
            'start_time', start_time,
            'end_time', end_time,
            'duration', duration,
            'status', status,
            'metadata', metadata
        )
    )
    FROM call_records
    WHERE start_time < DATE_SUB(NOW(), INTERVAL days_old DAY);

    DELETE FROM call_records 
    WHERE start_time < DATE_SUB(NOW(), INTERVAL days_old DAY)
    AND id IN (SELECT original_id FROM archived_call_records);
END //

CREATE PROCEDURE sp_archive_old_sensor_readings(IN days_old INT)
BEGIN
    INSERT INTO archived_sensor_readings (original_id, reading_data)
    SELECT id, JSON_OBJECT(
        'sensor_id', sensor_id,
        'reading_timestamp', reading_timestamp,
        'reading_value', reading_value,
        'metadata', metadata
    )
    FROM sensor_readings
    WHERE reading_timestamp < DATE_SUB(NOW(), INTERVAL days_old DAY);

    DELETE FROM sensor_readings 
    WHERE reading_timestamp < DATE_SUB(NOW(), INTERVAL days_old DAY)
    AND id IN (SELECT original_id FROM archived_sensor_readings);
END //

-- Archive Management Procedures
CREATE PROCEDURE sp_create_archive_table(
    IN p_table_name VARCHAR(100),
    IN p_compress BOOLEAN
)
BEGIN
    SET @create_sql = CONCAT(
        'CREATE TABLE ', p_table_name, '_archive LIKE ', p_table_name
    );
    
    IF p_compress THEN
        SET @create_sql = CONCAT(@create_sql, ' ROW_FORMAT=COMPRESSED KEY_BLOCK_SIZE=8');
    END IF;
    
    SET @create_sql = CONCAT(@create_sql, ';');
    PREPARE stmt FROM @create_sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
END //

CREATE PROCEDURE sp_archive_data(
    IN p_source_table VARCHAR(100),
    IN p_days_old INT
)
BEGIN
    DECLARE v_archive_table VARCHAR(100);
    SET v_archive_table = CONCAT(p_source_table, '_archive');
    
    -- Create archive table if not exists
    CALL sp_create_archive_table(p_source_table, TRUE);
    
    -- Move data to archive
    SET @move_sql = CONCAT(
        'INSERT INTO ', v_archive_table,
        ' SELECT * FROM ', p_source_table,
        ' WHERE created_at < DATE_SUB(NOW(), INTERVAL ', p_days_old, ' DAY)'
    );
    
    PREPARE stmt FROM @move_sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
    -- Delete archived data from source
    SET @delete_sql = CONCAT(
        'DELETE FROM ', p_source_table,
        ' WHERE created_at < DATE_SUB(NOW(), INTERVAL ', p_days_old, ' DAY)'
    );
    
    PREPARE stmt FROM @delete_sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
    -- Update archive policy
    UPDATE sys_archive_policies 
    SET last_archived_at = NOW()
    WHERE table_name = p_source_table;
END //

-- Point-in-time Recovery Support
CREATE PROCEDURE sp_enable_temporal_tracking(
    IN p_table_name VARCHAR(100),
    IN p_tracking_type VARCHAR(20)
)
BEGIN
    DECLARE v_column_exists INT;
    
    -- Add temporal columns if they don't exist
    IF p_tracking_type IN ('valid_time', 'bitemporal') THEN
        SELECT COUNT(*) INTO v_column_exists 
        FROM information_schema.COLUMNS 
        WHERE TABLE_NAME = p_table_name 
        AND COLUMN_NAME = 'valid_from';
        
        IF v_column_exists = 0 THEN
            SET @alter_sql = CONCAT(
                'ALTER TABLE ', p_table_name,
                ' ADD COLUMN valid_from TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,',
                ' ADD COLUMN valid_to TIMESTAMP NULL'
            );
            PREPARE stmt FROM @alter_sql;
            EXECUTE stmt;
            DEALLOCATE PREPARE stmt;
        END IF;
    END IF;
    
    IF p_tracking_type IN ('transaction_time', 'bitemporal') THEN
        SELECT COUNT(*) INTO v_column_exists 
        FROM information_schema.COLUMNS 
        WHERE TABLE_NAME = p_table_name 
        AND COLUMN_NAME = 'sys_start';
        
        IF v_column_exists = 0 THEN
            SET @alter_sql = CONCAT(
                'ALTER TABLE ', p_table_name,
                ' ADD COLUMN sys_start TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,',
                ' ADD COLUMN sys_end TIMESTAMP NULL'
            );
            PREPARE stmt FROM @alter_sql;
            EXECUTE stmt;
            DEALLOCATE PREPARE stmt;
        END IF;
    END IF;
    
    -- Update temporal settings
    INSERT INTO sys_temporal_settings (
        id, table_name,
        valid_time_tracking,
        transaction_time_tracking,
        bitemporal_tracking
    )
    VALUES (
        REPLACE(UUID(),'-',''),
        p_table_name,
        p_tracking_type IN ('valid_time', 'bitemporal'),
        p_tracking_type IN ('transaction_time', 'bitemporal'),
        p_tracking_type = 'bitemporal'
    )
    ON DUPLICATE KEY UPDATE
        valid_time_tracking = p_tracking_type IN ('valid_time', 'bitemporal'),
        transaction_time_tracking = p_tracking_type IN ('transaction_time', 'bitemporal'),
        bitemporal_tracking = p_tracking_type = 'bitemporal';
END //

-- Create maintenance procedure
CREATE PROCEDURE sp_perform_maintenance()
BEGIN
    -- Analyze and optimize tables
    ANALYZE TABLE call_records, sensor_readings, crm_activities;
    
    -- Update statistics for better query optimization
    ANALYZE TABLE call_records UPDATE HISTOGRAM ON status;
    ANALYZE TABLE crm_leads UPDATE HISTOGRAM ON status;
    
    -- Defragment critical tables
    OPTIMIZE TABLE call_records, crm_leads, prop_bookings;
END //

-- Add automated cleanup procedures
CREATE TABLE sys_cleanup_jobs (
    id CHAR(26) PRIMARY KEY,
    job_type VARCHAR(50) NOT NULL,
    last_run_at TIMESTAMP,
    next_run_at TIMESTAMP,
    configuration JSON,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_job_type (job_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DELIMITER //

CREATE PROCEDURE sp_schedule_cleanup_jobs()
BEGIN
    -- Schedule standard cleanup jobs
    INSERT INTO sys_cleanup_jobs (id, job_type, configuration)
    VALUES 
    (REPLACE(UUID(),'-',''), 'audit_logs_cleanup', 
        JSON_OBJECT(
            'retention_days', 365,
            'batch_size', 1000,
            'schedule', 'DAILY'
        )
    ),
    (REPLACE(UUID(),'-',''), 'temp_data_cleanup',
        JSON_OBJECT(
            'retention_days', 7,
            'batch_size', 1000,
            'schedule', 'DAILY'
        )
    ),
    (REPLACE(UUID(),'-',''), 'archived_data_cleanup',
        JSON_OBJECT(
            'retention_years', 7,
            'batch_size', 1000,
            'schedule', 'MONTHLY'
        )
    )
    ON DUPLICATE KEY UPDATE
        configuration = VALUES(configuration),
        is_active = TRUE;
END //

CREATE PROCEDURE sp_run_cleanup_jobs()
BEGIN
    DECLARE v_job_id CHAR(26);
    DECLARE v_job_type VARCHAR(50);
    DECLARE v_config JSON;
    DECLARE done INT DEFAULT FALSE;
    DECLARE cur CURSOR FOR 
        SELECT id, job_type, configuration
        FROM sys_cleanup_jobs
        WHERE is_active = TRUE
        AND (next_run_at IS NULL OR next_run_at <= NOW());
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN cur;
    read_loop: LOOP
        FETCH cur INTO v_job_id, v_job_type, v_config;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        -- Execute specific cleanup job
        CASE v_job_type
            WHEN 'audit_logs_cleanup' THEN
                CALL sp_cleanup_audit_logs();
            WHEN 'temp_data_cleanup' THEN
                CALL sp_cleanup_temp_data();
            WHEN 'archived_data_cleanup' THEN
                CALL sp_cleanup_archived_data();
        END CASE;
        
        -- Update job execution time
        UPDATE sys_cleanup_jobs
        SET last_run_at = NOW(),
            next_run_at = CASE 
                WHEN JSON_UNQUOTE(JSON_EXTRACT(configuration, '$.schedule')) = 'DAILY'
                    THEN DATE_ADD(NOW(), INTERVAL 1 DAY)
                WHEN JSON_UNQUOTE(JSON_EXTRACT(configuration, '$.schedule')) = 'WEEKLY'
                    THEN DATE_ADD(NOW(), INTERVAL 1 WEEK)
                WHEN JSON_UNQUOTE(JSON_EXTRACT(configuration, '$.schedule')) = 'MONTHLY'
                    THEN DATE_ADD(NOW(), INTERVAL 1 MONTH)
                ELSE DATE_ADD(NOW(), INTERVAL 1 DAY)
            END
        WHERE id = v_job_id;
    END LOOP;
    CLOSE cur;
END //

CREATE PROCEDURE sp_cleanup_temp_data()
BEGIN
    -- Clean up temporary tables
    DELETE FROM temp_data 
    WHERE created_at < DATE_SUB(NOW(), 
        INTERVAL 7 DAY);
        
    -- Clean up expired sessions
    DELETE FROM core_sessions 
    WHERE expires_at < NOW();
    
    -- Clean up expired tokens
    DELETE FROM core_password_resets 
    WHERE expires_at < NOW();
END //

CREATE PROCEDURE sp_cleanup_archived_data()
BEGIN
    -- Clean up old archived data
    DELETE FROM archived_call_records 
    WHERE archive_date < DATE_SUB(NOW(), 
        INTERVAL 7 YEAR);
        
    DELETE FROM archived_sensor_readings 
    WHERE archive_date < DATE_SUB(NOW(), 
        INTERVAL 7 YEAR);
        
    -- Optimize tables after cleanup
    OPTIMIZE TABLE archived_call_records;
    OPTIMIZE TABLE archived_sensor_readings;
END //

DELIMITER ;