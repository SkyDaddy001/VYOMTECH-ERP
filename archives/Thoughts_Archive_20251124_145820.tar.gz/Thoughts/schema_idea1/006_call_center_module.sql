-- Call Center Module - Asterisk Integration and Call Management

-- Asterisk Configuration
CREATE TABLE call_asterisk_config (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    name VARCHAR(100) NOT NULL,
    host VARCHAR(255) NOT NULL,
    port INT NOT NULL,
    username VARCHAR(100) NOT NULL,
    password_encrypted VARCHAR(255) NOT NULL,
    context VARCHAR(100) NOT NULL,
    dialplan_context VARCHAR(100),
    queue_context VARCHAR(100),
    settings JSON,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_client (client_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Call Queues
CREATE TABLE call_queues (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    company_id CHAR(26),
    name VARCHAR(100) NOT NULL,
    description TEXT,
    asterisk_queue VARCHAR(100) NOT NULL,
    strategy ENUM('ringall', 'leastrecent', 'fewestcalls', 'random', 'rrmemory', 'linear', 'wrandom') NOT NULL,
    timeout INT DEFAULT 60,
    retry_timeout INT DEFAULT 5,
    max_wait_time INT,
    max_callers INT,
    agent_timeout INT DEFAULT 15,
    wrap_up_time INT DEFAULT 0,
    join_empty BOOLEAN DEFAULT FALSE,
    leave_when_empty BOOLEAN DEFAULT FALSE,
    ring_strategy JSON,
    priority_weight INT DEFAULT 0,
    announcement_id CHAR(26),
    moh_class VARCHAR(100),
    recording_enabled BOOLEAN DEFAULT TRUE,
    settings JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_client (client_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Queue Members (Agents)
CREATE TABLE call_queue_members (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    queue_id CHAR(26) NOT NULL,
    user_id CHAR(26) NOT NULL,
    extension VARCHAR(50) NOT NULL,
    state ENUM('logged_out', 'available', 'on_call', 'on_break', 'busy') DEFAULT 'logged_out',
    penalty INT DEFAULT 0,
    priority_level INT DEFAULT 0,
    max_calls INT,
    status_callback_url VARCHAR(255),
    last_call_at TIMESTAMP NULL,
    company_id CHAR(26),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_queue (queue_id),
    INDEX idx_user (user_id),
    INDEX idx_state (state),
    INDEX idx_client_company (client_id, company_id),
    INDEX idx_queue_company (queue_id, company_id),
    UNIQUE KEY uk_queue_extension (queue_id, extension),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (queue_id) REFERENCES call_queues(id),
    FOREIGN KEY (user_id) REFERENCES core_users(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Call Records
CREATE TABLE call_records (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    queue_id CHAR(26),
    agent_id CHAR(26),
    lead_id CHAR(26),
    company_id CHAR(26),
    unique_id VARCHAR(100) NOT NULL,
    caller_id VARCHAR(50),
    caller_name VARCHAR(100),
    destination VARCHAR(50),
    direction ENUM('inbound', 'outbound', 'internal') NOT NULL,
    status VARCHAR(50) NOT NULL,
    start_time TIMESTAMP NULL,
    answer_time TIMESTAMP NULL,
    end_time TIMESTAMP NULL,
    duration INT,
    recording_url VARCHAR(255) ENCRYPTED, -- Encrypt sensitive URLs
    quality_score INT,
    metadata JSON,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_time_range (start_time, end_time), -- Optimize time-based queries
    INDEX idx_agent_status (agent_id, status, direction), -- For agent performance monitoring
    INDEX idx_queue_time (queue_id, start_time), -- For queue analytics
    PARTITION BY RANGE (UNIX_TIMESTAMP(start_time)) ( -- Partition by time for better performance
        PARTITION p_2024h1 VALUES LESS THAN (UNIX_TIMESTAMP('2024-07-01 00:00:00')),
        PARTITION p_2024h2 VALUES LESS THAN (UNIX_TIMESTAMP('2025-01-01 00:00:00')),
        PARTITION p_2025h1 VALUES LESS THAN (UNIX_TIMESTAMP('2025-07-01 00:00:00')),
        PARTITION p_future VALUES LESS THAN MAXVALUE
    ),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Call Events
CREATE TABLE call_events (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    call_id CHAR(26) NOT NULL,
    event_type VARCHAR(50) NOT NULL,
    event_data JSON NOT NULL,
    timestamp TIMESTAMP NOT NULL,
    company_id CHAR(26),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_call (call_id),
    INDEX idx_type_time (event_type, timestamp),
    INDEX idx_client_company (client_id, company_id),
    INDEX idx_call_company (call_id, company_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (call_id) REFERENCES call_records(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Queue Statistics (Real-time and Historical)
CREATE TABLE call_queue_stats (
    id CHAR(26) PRIMARY KEY,
    queue_id CHAR(26) NOT NULL,
    period_type ENUM('realtime', 'hourly', 'daily', 'weekly', 'monthly') NOT NULL,
    period_start TIMESTAMP NOT NULL,
    total_calls INT DEFAULT 0,
    answered_calls INT DEFAULT 0,
    abandoned_calls INT DEFAULT 0,
    avg_wait_time DECIMAL(10,2) DEFAULT 0,
    metrics JSON,
    company_id CHAR(26),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_queue_period (queue_id, period_type, period_start),
    INDEX idx_period_metrics (period_type, period_start), -- For analytics queries
    INDEX idx_queue_company (queue_id, company_id),
    FOREIGN KEY (queue_id) REFERENCES call_queues(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
PARTITION BY LIST COLUMNS(period_type) ( -- Partition by period type for efficient stats queries
    PARTITION p_realtime VALUES IN ('realtime'),
    PARTITION p_hourly VALUES IN ('hourly'),
    PARTITION p_daily VALUES IN ('daily'),
    PARTITION p_other VALUES IN ('weekly', 'monthly')
);

-- Agent Statistics
CREATE TABLE call_agent_stats (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    agent_id CHAR(26) NOT NULL,
    queue_id CHAR(26) NOT NULL,
    period_type ENUM('realtime', 'hourly', 'daily', 'weekly', 'monthly') NOT NULL,
    period_start TIMESTAMP NOT NULL,
    total_calls INT DEFAULT 0,
    answered_calls INT DEFAULT 0,
    missed_calls INT DEFAULT 0,
    total_talk_time INT DEFAULT 0,
    avg_talk_time DECIMAL(10,2) DEFAULT 0,
    total_wrap_up_time INT DEFAULT 0,
    avg_wrap_up_time DECIMAL(10,2) DEFAULT 0,
    total_hold_time INT DEFAULT 0,
    avg_hold_time DECIMAL(10,2) DEFAULT 0,
    login_time INT DEFAULT 0,
    break_time INT DEFAULT 0,
    idle_time INT DEFAULT 0,
    occupancy_rate DECIMAL(5,2) DEFAULT 0,
    metrics JSON,
    company_id CHAR(26),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_agent_period (agent_id, period_type, period_start),
    INDEX idx_queue (queue_id),
    INDEX idx_client_company (client_id, company_id),
    INDEX idx_agent_company (agent_id, company_id),
    UNIQUE KEY uk_agent_queue_period (agent_id, queue_id, period_type, period_start),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (agent_id) REFERENCES call_queue_members(id),
    FOREIGN KEY (queue_id) REFERENCES call_queues(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- IVR Menus
CREATE TABLE call_ivr_menus (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    welcome_message TEXT NOT NULL,
    timeout INT DEFAULT 10,
    max_retries INT DEFAULT 3,
    invalid_message TEXT,
    timeout_message TEXT,
    exit_message TEXT,
    options JSON NOT NULL,
    operating_hours JSON,
    holiday_handling JSON,
    fallback_destination JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_client (client_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Call Dispositions
CREATE TABLE call_dispositions (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    company_id CHAR(26),
    code VARCHAR(50) NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    category VARCHAR(50),
    requires_notes BOOLEAN DEFAULT FALSE,
    requires_callback BOOLEAN DEFAULT FALSE,
    is_positive_outcome BOOLEAN DEFAULT FALSE,
    follow_up_interval INT,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_client_category (client_id, category),
    UNIQUE KEY uk_client_code (client_id, code),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;