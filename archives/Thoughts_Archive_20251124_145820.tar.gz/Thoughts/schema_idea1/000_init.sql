-- Database Initialization and Core Settings

-- Set database configuration
SET NAMES utf8mb4;
SET collation_connection = 'utf8mb4_unicode_ci';

-- Create Database
CREATE DATABASE IF NOT EXISTS veloct
    DEFAULT CHARACTER SET utf8mb4
    DEFAULT COLLATE utf8mb4_unicode_ci;

USE veloct;

-- Add foreign key behavior configuration
SET @foreign_key_checks = 1;
SET @default_delete_behavior = 'RESTRICT';

-- Common Reference Tables

-- Countries
CREATE TABLE ref_countries (
    id CHAR(26) PRIMARY KEY,
    code VARCHAR(3) NOT NULL,
    name VARCHAR(100) NOT NULL,
    dial_code VARCHAR(10),
    currency_code VARCHAR(3),
    currency_symbol VARCHAR(5),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- States/Provinces
CREATE TABLE ref_states (
    id CHAR(26) PRIMARY KEY,
    country_id CHAR(26) NOT NULL,
    code VARCHAR(10) NOT NULL,
    name VARCHAR(100) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_country_code (country_id, code),
    FOREIGN KEY (country_id) REFERENCES ref_countries(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Cities
CREATE TABLE ref_cities (
    id CHAR(26) PRIMARY KEY,
    state_id CHAR(26) NOT NULL,
    name VARCHAR(100) NOT NULL,
    latitude DECIMAL(10,8),
    longitude DECIMAL(11,8),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_state (state_id),
    INDEX idx_coordinates (latitude, longitude),
    FOREIGN KEY (state_id) REFERENCES ref_states(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Units of Measurement
CREATE TABLE ref_units (
    id CHAR(26) PRIMARY KEY,
    type VARCHAR(50) NOT NULL,
    code VARCHAR(20) NOT NULL,
    name VARCHAR(100) NOT NULL,
    symbol VARCHAR(10),
    base_unit_id CHAR(26),
    conversion_factor DECIMAL(15,6),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_code (code),
    INDEX idx_type (type),
    FOREIGN KEY (base_unit_id) REFERENCES ref_units(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Standard Taxonomies
CREATE TABLE ref_taxonomies (
    id CHAR(26) PRIMARY KEY,
    type VARCHAR(50) NOT NULL,
    code VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    parent_id CHAR(26),
    level INT NOT NULL,
    sort_order INT DEFAULT 0,
    metadata JSON,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_type_code (type, code),
    INDEX idx_parent (parent_id),
    FOREIGN KEY (parent_id) REFERENCES ref_taxonomies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- System Jobs
CREATE TABLE sys_jobs (
    id CHAR(26) PRIMARY KEY,
    type VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL,
    data JSON NOT NULL,
    result JSON,
    error TEXT,
    started_at TIMESTAMP NULL,
    completed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_type_status (type, status),
    INDEX idx_status_date (status, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Job Schedules
CREATE TABLE sys_job_schedules (
    id CHAR(26) PRIMARY KEY,
    job_type VARCHAR(50) NOT NULL,
    cron_expression VARCHAR(100) NOT NULL,
    timezone VARCHAR(50) DEFAULT 'UTC',
    parameters JSON,
    is_active BOOLEAN DEFAULT TRUE,
    last_run_at TIMESTAMP NULL,
    next_run_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_job_type (job_type),
    INDEX idx_next_run (next_run_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Audit Logs
CREATE TABLE sys_audit_logs (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26),
    user_id CHAR(26),
    entity_type VARCHAR(50) NOT NULL,
    entity_id CHAR(26) NOT NULL,
    action VARCHAR(50) NOT NULL,
    old_values JSON,
    new_values JSON,
    metadata JSON,
    ip_address VARCHAR(45),
    user_agent VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_entity (entity_type, entity_id),
    INDEX idx_client_date (client_id, created_at),
    INDEX idx_user (user_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (user_id) REFERENCES core_users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
PARTITION BY RANGE (YEAR(created_at)) (
    PARTITION p2024 VALUES LESS THAN (2025),
    PARTITION p2025 VALUES LESS THAN (2026),
    PARTITION p2026 VALUES LESS THAN (2027)
);

-- Error Logs
CREATE TABLE sys_error_logs (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26),
    user_id CHAR(26),
    error_type VARCHAR(50) NOT NULL,
    error_code VARCHAR(50),
    error_message TEXT NOT NULL,
    stack_trace TEXT,
    context JSON,
    severity ENUM('low', 'medium', 'high', 'critical') NOT NULL,
    status ENUM('new', 'investigating', 'resolved', 'ignored') DEFAULT 'new',
    resolution_note TEXT,
    ip_address VARCHAR(45),
    user_agent VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL,
    INDEX idx_client_date (client_id, created_at),
    INDEX idx_type_severity (error_type, severity),
    INDEX idx_status (status),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (user_id) REFERENCES core_users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
PARTITION BY RANGE (YEAR(created_at)) (
    PARTITION p2024 VALUES LESS THAN (2025),
    PARTITION p2025 VALUES LESS THAN (2026),
    PARTITION p2026 VALUES LESS THAN (2027)
);

-- Standard Foreign Key Behavior Settings
CREATE TABLE sys_foreign_key_rules (
    id CHAR(26) PRIMARY KEY,
    source_table VARCHAR(100) NOT NULL,
    target_table VARCHAR(100) NOT NULL,
    delete_behavior ENUM('CASCADE', 'RESTRICT', 'SET NULL') NOT NULL DEFAULT 'RESTRICT',
    update_behavior ENUM('CASCADE', 'RESTRICT', 'SET NULL') NOT NULL DEFAULT 'RESTRICT',
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_source (source_table),
    INDEX idx_target (target_table)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Transaction Management Settings
CREATE TABLE sys_transaction_settings (
    id CHAR(26) PRIMARY KEY,
    transaction_type VARCHAR(100) NOT NULL,
    isolation_level ENUM('READ UNCOMMITTED', 'READ COMMITTED', 'REPEATABLE READ', 'SERIALIZABLE') NOT NULL,
    retry_count INT DEFAULT 3,
    retry_delay_ms INT DEFAULT 1000,
    deadlock_priority INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_transaction_type (transaction_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add data validation configuration
CREATE TABLE sys_validation_rules (
    id CHAR(26) PRIMARY KEY,
    table_name VARCHAR(100) NOT NULL,
    column_name VARCHAR(100) NOT NULL,
    validation_type ENUM('regex', 'range', 'enum', 'custom') NOT NULL,
    validation_rule JSON NOT NULL,
    error_message VARCHAR(255) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_table_column (table_name, column_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Common validation patterns
CREATE TABLE sys_validation_patterns (
    id CHAR(26) PRIMARY KEY,
    pattern_name VARCHAR(100) NOT NULL,
    pattern_regex VARCHAR(255) NOT NULL,
    description TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_pattern_name (pattern_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert common validation patterns
INSERT INTO sys_validation_patterns 
(id, pattern_name, pattern_regex, description) VALUES
(REPLACE(UUID(),'-',''), 'email', '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$', 'Standard email format'),
(REPLACE(UUID(),'-',''), 'phone', '^\\+?[1-9][0-9]{7,14}$', 'International phone number format'),
(REPLACE(UUID(),'-',''), 'password', '^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{8,}$', 'Password with minimum 8 characters, at least one letter and one number'),
(REPLACE(UUID(),'-',''), 'pan_number', '[A-Z]{5}[0-9]{4}[A-Z]{1}', 'PAN card number format'),
(REPLACE(UUID(),'-',''), 'gst_number', '^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$', 'GST number format');

-- Validation procedures
DELIMITER //

CREATE PROCEDURE sp_validate_data(
    IN p_table_name VARCHAR(100),
    IN p_data JSON
)
BEGIN
    DECLARE v_valid BOOLEAN DEFAULT TRUE;
    DECLARE v_error_messages JSON DEFAULT JSON_ARRAY();
    
    -- Validate against defined rules
    SELECT 
        JSON_ARRAYAGG(
            CASE
                WHEN validation_type = 'regex' AND NOT REGEXP_LIKE(
                    JSON_UNQUOTE(JSON_EXTRACT(p_data, CONCAT('$.', column_name))),
                    JSON_UNQUOTE(JSON_EXTRACT(validation_rule, '$.pattern'))
                ) THEN error_message
                WHEN validation_type = 'range' AND (
                    CAST(JSON_UNQUOTE(JSON_EXTRACT(p_data, CONCAT('$.', column_name))) AS DECIMAL) < 
                    CAST(JSON_UNQUOTE(JSON_EXTRACT(validation_rule, '$.min')) AS DECIMAL) OR
                    CAST(JSON_UNQUOTE(JSON_EXTRACT(p_data, CONCAT('$.', column_name))) AS DECIMAL) > 
                    CAST(JSON_UNQUOTE(JSON_EXTRACT(validation_rule, '$.max')) AS DECIMAL)
                ) THEN error_message
                WHEN validation_type = 'enum' AND JSON_SEARCH(
                    validation_rule->'$.allowed_values',
                    'one',
                    JSON_UNQUOTE(JSON_EXTRACT(p_data, CONCAT('$.', column_name)))
                ) IS NULL THEN error_message
                ELSE NULL
            END
        )
    INTO v_error_messages
    FROM sys_validation_rules
    WHERE table_name = p_table_name
    AND is_active = TRUE;
    
    -- Remove nulls from error messages
    SET v_error_messages = JSON_REMOVE(v_error_messages, 
        JSON_SEARCH(v_error_messages, 'all', NULL));
    
    -- Return validation result
    SELECT 
        JSON_LENGTH(v_error_messages) = 0 as is_valid,
        v_error_messages as error_messages;
END //

CREATE PROCEDURE sp_add_validation_rule(
    IN p_table_name VARCHAR(100),
    IN p_column_name VARCHAR(100),
    IN p_validation_type VARCHAR(10),
    IN p_validation_rule JSON,
    IN p_error_message VARCHAR(255)
)
BEGIN
    INSERT INTO sys_validation_rules (
        id,
        table_name,
        column_name,
        validation_type,
        validation_rule,
        error_message
    ) VALUES (
        REPLACE(UUID(),'-',''),
        p_table_name,
        p_column_name,
        p_validation_type,
        p_validation_rule,
        p_error_message
    )
    ON DUPLICATE KEY UPDATE
        validation_type = p_validation_type,
        validation_rule = p_validation_rule,
        error_message = p_error_message,
        is_active = TRUE;
END //

DELIMITER ;

-- Integration Management
CREATE TABLE sys_integration_endpoints (
    id CHAR(26) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    endpoint_type VARCHAR(50) NOT NULL,
    config JSON NOT NULL,
    auth_config JSON NOT NULL ENCRYPTED,
    retry_config JSON,
    rate_limit_config JSON,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE sys_integration_mappings (
    id CHAR(26) PRIMARY KEY,
    endpoint_id CHAR(26) NOT NULL,
    source_entity VARCHAR(100) NOT NULL,
    target_entity VARCHAR(100) NOT NULL,
    field_mappings JSON NOT NULL,
    transform_rules JSON,
    validation_rules JSON,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (endpoint_id) REFERENCES sys_integration_endpoints(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE sys_integration_logs (
    id CHAR(26) PRIMARY KEY,
    endpoint_id CHAR(26) NOT NULL,
    direction ENUM('inbound', 'outbound') NOT NULL,
    entity_type VARCHAR(100) NOT NULL,
    entity_id CHAR(26) NOT NULL,
    status ENUM('success', 'failed', 'pending', 'retry') NOT NULL,
    request_data JSON,
    response_data JSON,
    error_details JSON,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_endpoint_status (endpoint_id, status),
    INDEX idx_entity (entity_type, entity_id),
    FOREIGN KEY (endpoint_id) REFERENCES sys_integration_endpoints(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
PARTITION BY RANGE (UNIX_TIMESTAMP(created_at)) (
    PARTITION p_current VALUES LESS THAN (UNIX_TIMESTAMP(NOW())),
    PARTITION p_future VALUES LESS THAN MAXVALUE
);

-- Add composite indexes for frequently queried columns
CREATE INDEX idx_country_name ON ref_countries (name, is_active);
CREATE INDEX idx_state_name ON ref_states (name, is_active);
CREATE INDEX idx_city_name ON ref_cities (name, is_active);

-- Add transaction isolation level for critical operations
SET SESSION TRANSACTION ISOLATION LEVEL SERIALIZABLE;