-- Property Module - Projects, Units, and Bookings

-- Project Structure
CREATE TABLE prop_projects (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    company_id CHAR(26),
    name VARCHAR(255) NOT NULL,
    code VARCHAR(50) NOT NULL,
    location_address TEXT,
    coordinates POINT,
    total_area DECIMAL(15,2),
    description TEXT,
    amenities JSON,
    features JSON,
    status ENUM('planning', 'pre_launch', 'launching', 'ongoing', 'completed') NOT NULL,
    start_date DATE,
    completion_date DATE,
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_client_status (client_id, status),
    UNIQUE KEY uk_client_code (client_id, code),
    SPATIAL INDEX idx_location (coordinates),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE prop_blocks (
    id CHAR(26) PRIMARY KEY,
    project_id CHAR(26) NOT NULL,
    name VARCHAR(255) NOT NULL,
    code VARCHAR(50) NOT NULL,
    type VARCHAR(50) NOT NULL,
    total_floors INT NOT NULL,
    units_per_floor INT,
    amenities JSON,
    status ENUM('planning', 'construction', 'completed') NOT NULL,
    completion_percentage DECIMAL(5,2) DEFAULT 0,
    metadata JSON,
    company_id CHAR(26),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_project (project_id),
    INDEX idx_project_company (project_id, company_id),
    UNIQUE KEY uk_project_code (project_id, code),
    FOREIGN KEY (project_id) REFERENCES prop_projects(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE prop_floors (
    id CHAR(26) PRIMARY KEY,
    block_id CHAR(26) NOT NULL,
    floor_number VARCHAR(50) NOT NULL,
    name VARCHAR(255),
    type VARCHAR(50),
    total_units INT,
    common_area DECIMAL(10,2),
    amenities JSON,
    status VARCHAR(50),
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_block (block_id),
    UNIQUE KEY uk_block_number (block_id, floor_number),
    FOREIGN KEY (block_id) REFERENCES prop_blocks(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE prop_units (
    id CHAR(26) PRIMARY KEY,
    floor_id CHAR(26) NOT NULL,
    unit_number VARCHAR(50) NOT NULL,
    type VARCHAR(50) NOT NULL,
    category VARCHAR(50),
    status ENUM('available', 'reserved', 'sold', 'under_maintenance') NOT NULL,
    carpet_area DECIMAL(10,2),
    built_up_area DECIMAL(10,2),
    super_built_up_area DECIMAL(10,2),
    bedrooms INT,
    bathrooms INT,
    balconies INT,
    facing VARCHAR(50),
    base_price DECIMAL(15,2),
    price_per_sqft DECIMAL(10,2),
    maintenance_charges DECIMAL(10,2),
    amenities JSON,
    features JSON,
    metadata JSON,
    company_id CHAR(26),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_floor_status (floor_id, status),
    INDEX idx_floor_company (floor_id, company_id),
    INDEX idx_status_company (status, company_id),
    UNIQUE KEY uk_floor_number (floor_id, unit_number),
    FOREIGN KEY (floor_id) REFERENCES prop_floors(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Customer Management
CREATE TABLE prop_customers (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    company_id CHAR(26),
    lead_id CHAR(26),
    type ENUM('individual', 'company') NOT NULL,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    phone VARCHAR(50),
    alternate_phone VARCHAR(50),
    address TEXT,
    identity_type VARCHAR(50),
    identity_number VARCHAR(100),
    pan_number VARCHAR(20),
    gst_number VARCHAR(20),
    documentation_status JSON,
    kyc_status VARCHAR(50),
    credit_score INT,
    bank_details JSON,
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_client (client_id),
    INDEX idx_lead (lead_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (lead_id) REFERENCES crm_leads(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Unified Booking Management
CREATE TABLE prop_bookings (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    company_id CHAR(26),
    unit_id CHAR(26) NOT NULL,
    customer_id CHAR(26) NOT NULL,
    status ENUM('pending', 'confirmed', 'cancelled') NOT NULL,
    booking_date DATE NOT NULL,
    booking_amount DECIMAL(15,2) NOT NULL,
    payment_plan_id CHAR(26),
    base_price DECIMAL(15,2) NOT NULL,
    discount_amount DECIMAL(15,2) DEFAULT 0,
    tax_amount DECIMAL(15,2) DEFAULT 0,
    total_amount DECIMAL(15,2) NOT NULL,
    booking_source VARCHAR(50),
    broker_id CHAR(26),
    broker_commission_percentage DECIMAL(5,2),
    metadata JSON CHECK (JSON_VALID(metadata)),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_unit_status (unit_id, status), -- For unit availability queries
    INDEX idx_customer_date (customer_id, booking_date), -- For customer history
    INDEX idx_broker_commission (broker_id, broker_commission_percentage), -- For commission tracking
    PARTITION BY LIST COLUMNS(status) ( -- Partition for booking status queries
        PARTITION p_active VALUES IN ('pending', 'confirmed'),
        PARTITION p_cancelled VALUES IN ('cancelled')
    ),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE prop_booking_parties (
    id CHAR(26) PRIMARY KEY,
    booking_id CHAR(26) NOT NULL,
    type ENUM('applicant', 'co_applicant', 'poa') NOT NULL,
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    alternate_phone VARCHAR(50),
    email VARCHAR(255),
    address_line1 TEXT NOT NULL,
    address_line2 TEXT,
    city VARCHAR(100) NOT NULL,
    state VARCHAR(100) NOT NULL,
    country VARCHAR(100) NOT NULL,
    pincode VARCHAR(20) NOT NULL,
    permanent_address_line1 TEXT,
    permanent_address_line2 TEXT,
    permanent_city VARCHAR(100),
    permanent_state VARCHAR(100),
    permanent_country VARCHAR(100),
    permanent_pincode VARCHAR(20),
    id_type VARCHAR(50) NOT NULL,
    id_number VARCHAR(100) NOT NULL,
    pan_number VARCHAR(20),
    aadhar_number VARCHAR(20),
    share_percentage DECIMAL(5,2),
    occupation VARCHAR(100),
    annual_income DECIMAL(15,2),
    relation_to_primary VARCHAR(50),
    poa_details JSON,                        -- For POA holders
    verification_status ENUM('pending', 'in_progress', 'verified', 'rejected') DEFAULT 'pending',
    verification_notes TEXT,
    documents JSON,                          -- KYC and other documents
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_booking_type (booking_id, type),
    UNIQUE KEY uk_booking_pan (booking_id, pan_number),
    FOREIGN KEY (booking_id) REFERENCES prop_bookings(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Payment Plans and Schedules
CREATE TABLE prop_payment_plans (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    name VARCHAR(255) NOT NULL,
    type ENUM('construction_linked', 'time_linked', 'custom') NOT NULL,
    description TEXT,
    installments JSON NOT NULL,
    interest_rate DECIMAL(5,2),
    late_payment_interest DECIMAL(5,2),
    early_payment_discount DECIMAL(5,2),
    terms_conditions TEXT,
    metadata JSON,
    company_id CHAR(26),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_client_type (client_id, type),
    INDEX idx_client_company (client_id, company_id),
    INDEX idx_type_company (type, company_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE prop_payments (
    id CHAR(26) PRIMARY KEY,
    booking_id CHAR(26) NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    payment_date DATE NOT NULL,
    payment_mode VARCHAR(50) NOT NULL,
    status ENUM('pending', 'completed', 'failed', 'refunded') NOT NULL,
    bank_details JSON CHECK (JSON_VALID(bank_details)),
    transaction_ref VARCHAR(100),
    company_id CHAR(26),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_booking_status (booking_id, status), -- For payment tracking
    INDEX idx_date_status (payment_date, status) INVISIBLE, -- For financial reporting
    INDEX idx_booking_company (booking_id, company_id),
    INDEX idx_date_company (payment_date, company_id),
    PARTITION BY RANGE COLUMNS(payment_date) ( -- Partition by date for better query performance
        PARTITION p_2024h1 VALUES LESS THAN ('2024-07-01'),
        PARTITION p_2024h2 VALUES LESS THAN ('2025-01-01'),
        PARTITION p_future VALUES LESS THAN (MAXVALUE)
    ),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;