-- Project Management Module
CREATE TABLE project_tasks (
    id CHAR(26) PRIMARY KEY,
    project_id CHAR(26) NOT NULL,
    parent_task_id CHAR(26) REFERENCES project_tasks(id) ON DELETE SET NULL,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    start_date TIMESTAMP,
    end_date TIMESTAMP,
    duration INT, -- in hours
    progress DECIMAL(5,2),
    dependencies JSON, -- Array of dependent task IDs
    critical_path BOOLEAN DEFAULT FALSE,
    company_id CHAR(26),
    INDEX idx_project_company (project_id, company_id),
    INDEX idx_critical_company (critical_path, company_id),
    FOREIGN KEY (project_id) REFERENCES prop_projects(id) ON DELETE CASCADE,
    FOREIGN KEY (company_id) REFERENCES core_companies(id) ON DELETE RESTRICT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE resource_allocation (
    id CHAR(26) PRIMARY KEY,
    task_id CHAR(26) NOT NULL REFERENCES project_tasks(id) ON DELETE CASCADE,
    resource_id CHAR(26) NOT NULL, -- Can be user_id or equipment_id
    resource_type VARCHAR(50) NOT NULL, -- human, equipment, material
    allocation_percentage DECIMAL(5,2),
    start_date TIMESTAMP,
    end_date TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_task_company (task_id, company_id),
    INDEX idx_resource_company (resource_id, company_id),
    INDEX idx_type_company (resource_type, company_id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id) ON DELETE RESTRICT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE project_milestones (
    id CHAR(26) PRIMARY KEY,
    project_id CHAR(26) NOT NULL,
    name VARCHAR(200) NOT NULL,
    due_date TIMESTAMP NOT NULL,
    status VARCHAR(50) NOT NULL,
    priority INT,
    description TEXT,
    company_id CHAR(26),
    INDEX idx_project_company (project_id, company_id),
    INDEX idx_status_company (status, company_id),
    INDEX idx_due_company (due_date, company_id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE project_risks (
    id CHAR(26) PRIMARY KEY,
    project_id CHAR(26) NOT NULL,
    risk_type VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    probability DECIMAL(5,2),
    impact DECIMAL(5,2),
    mitigation_strategy TEXT,
    status VARCHAR(50),
    company_id CHAR(26),
    INDEX idx_project_company (project_id, company_id),
    INDEX idx_type_company (risk_type, company_id),
    INDEX idx_status_company (status, company_id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE project_issues (
    id CHAR(26) PRIMARY KEY,
    project_id CHAR(26) NOT NULL,
    reported_by CHAR(26) REFERENCES core_users(id),
    assigned_to CHAR(26) REFERENCES core_users(id),
    title VARCHAR(200) NOT NULL,
    description TEXT,
    priority VARCHAR(20),
    status VARCHAR(50),
    resolution TEXT,
    due_date TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_project_company (project_id, company_id),
    INDEX idx_status_company (status, company_id),
    INDEX idx_assigned_company (assigned_to, company_id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE resource_capacity (
    id CHAR(26) PRIMARY KEY,
    resource_id CHAR(26) NOT NULL,
    resource_type VARCHAR(50) NOT NULL,
    available_hours DECIMAL(8,2),
    start_date TIMESTAMP,
    end_date TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_resource_company (resource_id, company_id),
    INDEX idx_type_company (resource_type, company_id),
    INDEX idx_date_company (start_date, company_id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);