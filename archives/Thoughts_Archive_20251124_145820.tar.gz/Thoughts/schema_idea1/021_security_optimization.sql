-- Security optimization for sensitive data
-- Create secure audit triggers for sensitive data operations
DELIMITER //

CREATE TRIGGER trg_encrypt_sensitive_data
BEFORE INSERT ON crm_leads
FOR EACH ROW
BEGIN
    -- Encrypt sensitive contact information
    SET NEW.email = AES_ENCRYPT(NEW.email, @encryption_key);
    SET NEW.phone = AES_ENCRYPT(NEW.phone, @encryption_key);
    SET NEW.alternate_phone = AES_ENCRYPT(NEW.alternate_phone, @encryption_key);
END //

CREATE TRIGGER trg_mask_sensitive_data
BEFORE INSERT ON prop_customers
FOR EACH ROW
BEGIN
    -- Mask PAN and GST numbers
    IF NEW.pan_number IS NOT NULL THEN
        SET NEW.pan_number = CONCAT('XXXXX', RIGHT(NEW.pan_number, 4));
    END IF;
    IF NEW.gst_number IS NOT NULL THEN
        SET NEW.gst_number = CONCAT('XXXXX', RIGHT(NEW.gst_number, 4));
    END IF;
END //

-- Create security monitoring views
CREATE OR REPLACE VIEW vw_security_audit AS
SELECT 
    al.id,
    al.entity_type,
    al.action,
    al.ip_address,
    al.created_at,
    CASE 
        WHEN al.entity_type IN ('crm_leads', 'prop_customers') THEN 'SENSITIVE'
        ELSE 'NORMAL'
    END as data_classification
FROM sys_audit_logs al
WHERE al.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY);

-- Add security-focused indexes
ALTER TABLE sys_audit_logs
ADD INDEX idx_security_monitoring (entity_type, action, created_at);

-- Create security monitoring procedures
CREATE PROCEDURE sp_security_health_check()
BEGIN
    -- Check for failed login attempts
    SELECT user_id, COUNT(*) as failed_attempts
    FROM sys_audit_logs
    WHERE action = 'login_failed'
    AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
    GROUP BY user_id
    HAVING COUNT(*) >= 5;

    -- Check for sensitive data access
    SELECT user_id, entity_type, COUNT(*) as access_count
    FROM sys_audit_logs
    WHERE entity_type IN ('crm_leads', 'prop_customers')
    AND action = 'view'
    AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
    GROUP BY user_id, entity_type
    HAVING COUNT(*) > 100;
END //

CREATE PROCEDURE sp_rotate_encryption_keys()
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Error during encryption key rotation';
    END;

    START TRANSACTION;
        -- Backup current keys
        INSERT INTO sys_encryption_keys_history (key_id, key_value, valid_until)
        SELECT id, key_value, NOW()
        FROM sys_encryption_keys
        WHERE is_active = 1;

        -- Generate and store new keys
        UPDATE sys_encryption_keys
        SET key_value = UUID(), 
            updated_at = NOW()
        WHERE is_active = 1;
    COMMIT;
END //

-- Transaction Management
CREATE PROCEDURE sp_begin_transaction(
    IN p_transaction_type VARCHAR(100)
)
BEGIN
    DECLARE v_isolation_level VARCHAR(50);
    DECLARE v_retry_count INT;
    DECLARE v_retry_delay INT;
    
    -- Get transaction settings
    SELECT 
        isolation_level,
        retry_count,
        retry_delay_ms
    INTO 
        v_isolation_level,
        v_retry_count,
        v_retry_delay
    FROM sys_transaction_settings
    WHERE transaction_type = p_transaction_type;
    
    -- Set isolation level
    SET TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    
    -- Start transaction
    START TRANSACTION;
END //

CREATE PROCEDURE sp_commit_transaction()
BEGIN
    COMMIT;
END //

CREATE PROCEDURE sp_rollback_transaction()
BEGIN
    ROLLBACK;
END //

-- Add standard transaction procedures
CREATE OR REPLACE PROCEDURE sp_transaction_wrapper(
    IN p_transaction_type VARCHAR(100),
    IN p_procedure_name VARCHAR(100),
    IN p_parameters JSON
)
BEGIN
    DECLARE exit handler FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        CALL sp_handle_error(
            'TRANSACTION_ERROR',
            CONCAT('Transaction failed for procedure: ', p_procedure_name),
            JSON_OBJECT(
                'transaction_type', p_transaction_type,
                'procedure', p_procedure_name,
                'parameters', p_parameters
            )
        );
    END;

    CALL sp_begin_transaction(p_transaction_type);
    
    SET @proc_call = CONCAT('CALL ', p_procedure_name, '(');
    
    -- Build parameter list dynamically
    SELECT GROUP_CONCAT(
        CASE 
            WHEN param_value IS NULL THEN 'NULL'
            WHEN JSON_TYPE(param_value) IN ('STRING', 'BOOLEAN') THEN 
                CONCAT('"', param_value, '"')
            ELSE param_value
        END
    )
    INTO @params
    FROM JSON_TABLE(
        p_parameters,
        '$[*]' COLUMNS(
            param_value JSON PATH '$'
        )
    );
    
    SET @proc_call = CONCAT(@proc_call, @params, ')');
    
    PREPARE stmt FROM @proc_call;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
    COMMIT;
END;

-- Add foreign key error handler
CREATE OR REPLACE PROCEDURE sp_handle_foreign_key_error(
    IN p_table_name VARCHAR(100),
    IN p_foreign_key_name VARCHAR(100),
    IN p_referenced_id CHAR(26)
)
BEGIN
    DECLARE v_referenced_table VARCHAR(100);
    DECLARE v_error_message VARCHAR(255);
    
    -- Get referenced table name
    SELECT REFERENCED_TABLE_NAME 
    INTO v_referenced_table
    FROM information_schema.KEY_COLUMN_USAGE
    WHERE CONSTRAINT_NAME = p_foreign_key_name
    AND TABLE_NAME = p_table_name;
    
    SET v_error_message = CONCAT(
        'Foreign key constraint violation: ',
        'Referenced record in table ', v_referenced_table,
        ' with ID ', p_referenced_id, ' does not exist'
    );
    
    CALL sp_handle_error(
        'FOREIGN_KEY_ERROR',
        v_error_message,
        JSON_OBJECT(
            'table', p_table_name,
            'foreign_key', p_foreign_key_name,
            'referenced_table', v_referenced_table,
            'referenced_id', p_referenced_id
        )
    );
END;

-- Add constraint check procedure
CREATE OR REPLACE PROCEDURE sp_check_constraints(
    IN p_table_name VARCHAR(100),
    IN p_data JSON
)
BEGIN
    DECLARE v_constraint_valid BOOLEAN DEFAULT TRUE;
    DECLARE v_error_message TEXT;
    
    -- Check foreign key constraints
    FOR constraint_rec IN (
        SELECT 
            CONSTRAINT_NAME,
            COLUMN_NAME,
            REFERENCED_TABLE_NAME,
            REFERENCED_COLUMN_NAME
        FROM information_schema.KEY_COLUMN_USAGE
        WHERE TABLE_NAME = p_table_name
        AND REFERENCED_TABLE_NAME IS NOT NULL
    ) DO
        IF NOT EXISTS (
            SELECT 1 
            FROM constraint_rec.REFERENCED_TABLE_NAME
            WHERE constraint_rec.REFERENCED_COLUMN_NAME = 
                JSON_UNQUOTE(JSON_EXTRACT(p_data, CONCAT('$.', constraint_rec.COLUMN_NAME)))
        ) THEN
            SET v_constraint_valid = FALSE;
            SET v_error_message = CONCAT(
                'Foreign key constraint violation on column ',
                constraint_rec.COLUMN_NAME
            );
            LEAVE constraint_loop;
        END IF;
    END FOR;
    
    -- Check unique constraints
    FOR unique_rec IN (
        SELECT 
            GROUP_CONCAT(COLUMN_NAME) as columns
        FROM information_schema.KEY_COLUMN_USAGE
        WHERE TABLE_NAME = p_table_name
        AND CONSTRAINT_NAME != 'PRIMARY'
        AND POSITION_IN_UNIQUE_CONSTRAINT IS NULL
        GROUP BY CONSTRAINT_NAME
    ) DO
        SET @check_sql = CONCAT(
            'SELECT COUNT(*) INTO @duplicate_count FROM ',
            p_table_name, ' WHERE '
        );
        
        SET @conditions = '';
        FOR column_name IN (
            SELECT TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(unique_rec.columns, ',', n), ',', -1))
            FROM (
                SELECT unique_rec.columns, 
                       (SELECT COUNT(*) FROM information_schema.COLUMNS) n
            ) numbers
            WHERE n <= 1 + (LENGTH(unique_rec.columns) - LENGTH(REPLACE(unique_rec.columns, ',', '')))
        ) DO
            SET @conditions = CONCAT(
                @conditions,
                IF(@conditions = '', '', ' AND '),
                column_name, ' = ',
                JSON_UNQUOTE(JSON_EXTRACT(p_data, CONCAT('$.', column_name)))
            );
        END FOR;
        
        SET @check_sql = CONCAT(@check_sql, @conditions);
        PREPARE stmt FROM @check_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
        
        IF @duplicate_count > 0 THEN
            SET v_constraint_valid = FALSE;
            SET v_error_message = CONCAT(
                'Unique constraint violation on columns: ',
                unique_rec.columns
            );
            LEAVE unique_loop;
        END IF;
    END FOR;
    
    -- Handle constraint violations
    IF NOT v_constraint_valid THEN
        CALL sp_handle_error(
            'CONSTRAINT_ERROR',
            v_error_message,
            JSON_OBJECT(
                'table', p_table_name,
                'data', p_data
            )
        );
    END IF;
END;

-- Error Handling
CREATE PROCEDURE sp_handle_error(
    IN p_error_type VARCHAR(50),
    IN p_error_message TEXT,
    IN p_context JSON
)
BEGIN
    DECLARE v_client_id CHAR(26);
    DECLARE v_user_id CHAR(26);
    
    -- Get current context
    SET v_client_id = JSON_UNQUOTE(JSON_EXTRACT(p_context, '$.client_id'));
    SET v_user_id = JSON_UNQUOTE(JSON_EXTRACT(p_context, '$.user_id'));
    
    -- Log error
    INSERT INTO sys_error_logs (
        id,
        client_id,
        user_id,
        error_type,
        error_message,
        context,
        severity,
        created_at
    ) VALUES (
        REPLACE(UUID(),'-',''),
        v_client_id,
        v_user_id,
        p_error_type,
        p_error_message,
        p_context,
        CASE 
            WHEN p_error_type IN ('DEADLOCK', 'SYSTEM_ERROR') THEN 'critical'
            WHEN p_error_type IN ('VALIDATION_ERROR', 'BUSINESS_RULE_ERROR') THEN 'medium'
            ELSE 'low'
        END,
        NOW()
    );
    
    -- Handle specific error types
    CASE p_error_type
        WHEN 'DEADLOCK' THEN
            -- Attempt retry
            SIGNAL SQLSTATE '40001' 
            SET MESSAGE_TEXT = 'Deadlock detected, retry transaction';
        WHEN 'VALIDATION_ERROR' THEN
            -- Return validation error
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = p_error_message;
        ELSE
            -- Generic error
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'An error occurred. Please try again.';
    END CASE;
END //

-- Dead Lock Prevention
CREATE PROCEDURE sp_check_deadlock_risk(
    IN p_table_name VARCHAR(100),
    IN p_operation VARCHAR(10)
)
BEGIN
    DECLARE v_lock_wait_count INT;
    
    -- Check for existing locks
    SELECT COUNT(*)
    INTO v_lock_wait_count
    FROM performance_schema.events_waits_current
    WHERE EVENT_NAME LIKE 'wait/io/table/%'
    AND OBJECT_NAME = p_table_name;
    
    -- If locks exist, analyze risk
    IF v_lock_wait_count > 0 THEN
        -- Log potential deadlock risk
        INSERT INTO sys_error_logs (
            id,
            error_type,
            error_message,
            context,
            severity,
            created_at
        ) VALUES (
            REPLACE(UUID(),'-',''),
            'DEADLOCK_RISK',
            CONCAT('Potential deadlock risk detected on table: ', p_table_name),
            JSON_OBJECT(
                'table_name', p_table_name,
                'operation', p_operation,
                'lock_wait_count', v_lock_wait_count
            ),
            'high',
            NOW()
        );
    END IF;
END //

DELIMITER ;