-- HR & Payroll Module
CREATE TABLE employee_details (
    id CHAR(26) PRIMARY KEY,
    user_id CHAR(26) NOT NULL,
    employee_code VARCHAR(50),
    department_id CHAR(26),
    position VARCHAR(100),
    join_date DATE,
    employment_type VARCHAR(50),
    manager_id CHAR(26),
    personal_info JSON,
    documents JSON,
    status VARCHAR(50) NOT NULL,
    company_id CHAR(26),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_emp_status (status, employee_code), -- Optimize employee lookup by status
    INDEX idx_dept_mgr (department_id, manager_id), -- Optimize department hierarchy queries
    INDEX idx_join_date (join_date), -- For tenure based queries
    INDEX idx_company_status (company_id, status),
    INDEX idx_company_dept (company_id, department_id),
    UNIQUE KEY uk_employee_code (employee_code),
    FOREIGN KEY (user_id) REFERENCES core_users(id) ON DELETE RESTRICT,
    FOREIGN KEY (manager_id) REFERENCES employee_details(id) ON DELETE SET NULL,
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
ENCRYPTION='Y'; -- Enable table encryption for sensitive data

CREATE TABLE salary_structures (
    id CHAR(26) PRIMARY KEY,
    employee_id CHAR(26) NOT NULL,
    basic_salary DECIMAL(12,2),
    allowances JSON,
    deductions JSON,
    effective_from DATE,
    company_id CHAR(26),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_employee_date (employee_id, effective_from), -- Optimize salary history queries
    INDEX idx_employee_company (employee_id, company_id),
    INDEX idx_company_date (company_id, effective_from),
    FOREIGN KEY (employee_id) REFERENCES employee_details(id) ON DELETE CASCADE,
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
ENCRYPTION='Y'; -- Enable table encryption for sensitive salary data

-- Add triggers for audit trail
DELIMITER //
CREATE TRIGGER salary_audit_trail BEFORE UPDATE ON salary_structures
FOR EACH ROW
BEGIN
    INSERT INTO sys_audit_logs (
        id, entity_type, entity_id, action, old_values, new_values
    ) VALUES (
        REPLACE(UUID(),'-',''), 
        'salary_structure',
        OLD.id,
        'update',
        JSON_OBJECT(
            'basic_salary', OLD.basic_salary,
            'allowances', OLD.allowances,
            'deductions', OLD.deductions
        ),
        JSON_OBJECT(
            'basic_salary', NEW.basic_salary,
            'allowances', NEW.allowances,
            'deductions', NEW.deductions
        )
    );
END;
//
DELIMITER ;

CREATE TABLE payroll_periods (
    id CHAR(26) PRIMARY KEY,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    status VARCHAR(50) NOT NULL, -- draft, processing, completed
    company_id CHAR(26),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_company_period (company_id, period_start, period_end),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
);

CREATE TABLE payroll_entries (
    id CHAR(26) PRIMARY KEY,
    period_id CHAR(26) NOT NULL REFERENCES payroll_periods(id),
    employee_id CHAR(26) NOT NULL REFERENCES employee_details(id),
    basic_pay DECIMAL(12,2),
    allowances JSON,
    deductions JSON,
    overtime_hours DECIMAL(8,2),
    overtime_pay DECIMAL(12,2),
    gross_pay DECIMAL(12,2),
    net_pay DECIMAL(12,2),
    payment_status VARCHAR(50),
    company_id CHAR(26),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_period_company (period_id, company_id),
    INDEX idx_employee_company (employee_id, company_id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
);

CREATE TABLE leave_types (
    id CHAR(26) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    annual_days INT,
    paid BOOLEAN,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    requires_approval BOOLEAN DEFAULT true,
    requires_documentation BOOLEAN DEFAULT false,
    min_notice_days INT DEFAULT 0,
    max_consecutive_days INT,
    accrual_rules JSON,
    carry_forward_rules JSON,
    company_id CHAR(26),
    INDEX idx_company (company_id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE leave_balances (
    id CHAR(26) PRIMARY KEY,
    employee_id CHAR(26) NOT NULL REFERENCES employee_details(id),
    leave_type_id CHAR(26) NOT NULL REFERENCES leave_types(id),
    year INT NOT NULL,
    total_days INT,
    used_days INT,
    remaining_days INT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_employee_company (employee_id, company_id),
    INDEX idx_type_company (leave_type_id, company_id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE leave_requests (
    id CHAR(26) PRIMARY KEY,
    employee_id CHAR(26) NOT NULL REFERENCES employee_details(id),
    leave_type_id CHAR(26) NOT NULL REFERENCES leave_types(id),
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    status VARCHAR(50) NOT NULL, -- pending, approved, rejected
    approved_by CHAR(26) REFERENCES core_users(id),
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_employee_company (employee_id, company_id),
    INDEX idx_status_company (status, company_id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE attendance_records (
    id CHAR(26) PRIMARY KEY,
    employee_id CHAR(26) NOT NULL REFERENCES employee_details(id),
    date DATE NOT NULL,
    check_in TIMESTAMP,
    check_out TIMESTAMP,
    total_hours DECIMAL(5,2),
    status VARCHAR(50), -- present, absent, half-day
    primary_auth_method VARCHAR(50),
    verification_status VARCHAR(50),
    location_id CHAR(26) REFERENCES office_locations(id),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_employee_company (employee_id, company_id),
    INDEX idx_date_company (date, company_id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Biometric Devices Management
CREATE TABLE biometric_devices (
    id CHAR(26) PRIMARY KEY,
    device_name VARCHAR(100) NOT NULL,
    location VARCHAR(200) NOT NULL,
    device_type VARCHAR(50) NOT NULL, -- fingerprint, face, iris, etc.
    ip_address VARCHAR(45),
    api_key VARCHAR(100),
    status VARCHAR(50) NOT NULL, -- active, inactive, maintenance
    last_sync_time TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Enhanced Attendance Records with Multiple Authentication Methods
CREATE TABLE attendance_auth_methods (
    id CHAR(26) PRIMARY KEY,
    attendance_id CHAR(26) NOT NULL REFERENCES attendance_records(id),
    auth_type VARCHAR(50) NOT NULL, -- biometric, mobile_app, web_portal
    auth_details JSON, -- Stores specific authentication details
    geo_location JSON, -- latitude, longitude
    ip_address VARCHAR(45),
    device_id VARCHAR(100), -- Mobile device ID or biometric device ID
    verification_status VARCHAR(50) NOT NULL, -- verified, suspicious, rejected
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Geo-fence Locations
CREATE TABLE office_locations (
    id CHAR(26) PRIMARY KEY,
    location_name VARCHAR(200) NOT NULL,
    address TEXT,
    geo_fence_coordinates JSON NOT NULL, -- Array of lat/long points defining the fence
    radius_meters INT, -- For circular geo-fences
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_company_active (company_id, active),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Location Verification Rules
CREATE TABLE location_verification_rules (
    id CHAR(26) PRIMARY KEY,
    location_id CHAR(26) REFERENCES office_locations(id),
    department_id CHAR(26),
    max_distance_meters INT NOT NULL,
    required_auth_methods JSON, -- Array of required authentication methods
    active_hours JSON, -- Working hours for this location
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Compensatory Off Management
CREATE TABLE overtime_work (
    id CHAR(26) PRIMARY KEY,
    employee_id CHAR(26) NOT NULL REFERENCES employee_details(id),
    work_date DATE NOT NULL,
    hours_worked DECIMAL(5,2) NOT NULL,
    reason TEXT NOT NULL,
    status VARCHAR(50) NOT NULL, -- pending, approved, rejected, converted_to_compoff
    approved_by CHAR(26) REFERENCES core_users(id),
    approval_date TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE comp_off_balance (
    id CHAR(26) PRIMARY KEY,
    employee_id CHAR(26) NOT NULL REFERENCES employee_details(id),
    earned_hours DECIMAL(5,2) NOT NULL,
    used_hours DECIMAL(5,2) DEFAULT 0,
    expiry_date DATE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE comp_off_requests (
    id CHAR(26) PRIMARY KEY,
    employee_id CHAR(26) NOT NULL REFERENCES employee_details(id),
    overtime_work_id CHAR(26) REFERENCES overtime_work(id),
    request_date DATE NOT NULL,
    hours_requested DECIMAL(5,2) NOT NULL,
    status VARCHAR(50) NOT NULL, -- pending, approved, rejected
    approved_by CHAR(26) REFERENCES core_users(id),
    approval_date TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Mobile App Session Management
CREATE TABLE mobile_sessions (
    id CHAR(26) PRIMARY KEY,
    employee_id CHAR(26) NOT NULL REFERENCES employee_details(id),
    device_id VARCHAR(100) NOT NULL,
    device_details JSON, -- Device model, OS, app version
    session_token VARCHAR(200) NOT NULL,
    last_location JSON, -- Last known location
    session_start TIMESTAMP NOT NULL,
    session_end TIMESTAMP,
    status VARCHAR(50) NOT NULL, -- active, ended, terminated
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Attendance Verification Logs
CREATE TABLE attendance_verification_logs (
    id CHAR(26) PRIMARY KEY,
    attendance_id CHAR(26) NOT NULL REFERENCES attendance_records(id),
    verification_type VARCHAR(50) NOT NULL, -- geo_fence, biometric, facial, supervisor
    status VARCHAR(50) NOT NULL, -- passed, failed, needs_review
    verification_data JSON, -- Details of the verification
    verified_by CHAR(26) REFERENCES core_users(id),
    verification_time TIMESTAMP NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE shifts (
    id CHAR(26) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    break_duration INT, -- in minutes
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE employee_shifts (
    id CHAR(26) PRIMARY KEY,
    employee_id CHAR(26) NOT NULL REFERENCES employee_details(id),
    shift_id CHAR(26) NOT NULL REFERENCES shifts(id),
    effective_from DATE NOT NULL,
    effective_to DATE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE training_programs (
    id CHAR(26) PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    duration_hours INT,
    trainer VARCHAR(200),
    materials JSON,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE employee_training (
    id CHAR(26) PRIMARY KEY,
    employee_id CHAR(26) NOT NULL REFERENCES employee_details(id),
    program_id CHAR(26) NOT NULL REFERENCES training_programs(id),
    start_date DATE,
    completion_date DATE,
    status VARCHAR(50),
    score DECIMAL(5,2),
    certification_id VARCHAR(100),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE performance_reviews (
    id CHAR(26) PRIMARY KEY,
    employee_id CHAR(26) NOT NULL REFERENCES employee_details(id),
    reviewer_id CHAR(26) NOT NULL REFERENCES core_users(id),
    review_period_start DATE,
    review_period_end DATE,
    ratings JSON, -- Different performance parameters
    comments TEXT,
    goals JSON,
    status VARCHAR(50),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Holiday Management
CREATE TABLE holidays (
    id CHAR(26) PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    date DATE NOT NULL,
    type VARCHAR(50) NOT NULL, -- public, company, optional
    description TEXT,
    applicable_regions JSON, -- For different office locations
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Enhanced Leave Management
CREATE TABLE leave_policies (
    id CHAR(26) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    rules JSON NOT NULL, -- Accrual rules, carry forward limits, etc.
    effective_from DATE NOT NULL,
    effective_to DATE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Leave approval matrix
CREATE TABLE leave_approval_matrix (
    id CHAR(26) PRIMARY KEY,
    department_id CHAR(26),
    leave_type_id CHAR(26) REFERENCES leave_types(id),
    min_days INT, -- Minimum days for this approval level
    max_days INT, -- Maximum days for this approval level
    approval_levels JSON NOT NULL, -- Array of approval roles/users in sequence
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE leave_approval_history (
    id CHAR(26) PRIMARY KEY,
    leave_request_id CHAR(26) NOT NULL REFERENCES leave_requests(id),
    level_number INT NOT NULL,
    approver_id CHAR(26) REFERENCES core_users(id),
    status VARCHAR(50) NOT NULL, -- approved, rejected, pending
    comments TEXT,
    action_date TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Sick Leave Management
CREATE TABLE medical_certificates (
    id CHAR(26) PRIMARY KEY,
    employee_id CHAR(26) NOT NULL REFERENCES employee_details(id),
    leave_request_id CHAR(26) NOT NULL REFERENCES leave_requests(id),
    document_path TEXT NOT NULL,
    issue_date DATE NOT NULL,
    valid_from DATE NOT NULL,
    valid_to DATE NOT NULL,
    diagnosis TEXT,
    doctor_name VARCHAR(200),
    hospital_name VARCHAR(200),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Compliance Management
CREATE TABLE compliance_types (
    id CHAR(26) PRIMARY KEY,
    name VARCHAR(100) NOT NULL, -- PF, ESI, TDS, PT, etc.
    description TEXT,
    calculation_rules JSON, -- Rules for calculating deductions
    submission_frequency VARCHAR(50), -- monthly, quarterly, yearly
    company_id CHAR(26),
    INDEX idx_company (company_id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE employee_compliance (
    id CHAR(26) PRIMARY KEY,
    employee_id CHAR(26) NOT NULL REFERENCES employee_details(id),
    compliance_type_id CHAR(26) NOT NULL REFERENCES compliance_types(id),
    registration_number VARCHAR(100), -- PF number, ESI number etc.
    effective_from DATE NOT NULL,
    effective_to DATE,
    status VARCHAR(50) NOT NULL,
    documents JSON, -- Related compliance documents
    company_id CHAR(26),
    INDEX idx_employee_company (employee_id, company_id),
    INDEX idx_status_company (status, company_id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE compliance_transactions (
    id CHAR(26) PRIMARY KEY,
    employee_id CHAR(26) NOT NULL REFERENCES employee_details(id),
    compliance_type_id CHAR(26) NOT NULL REFERENCES compliance_types(id),
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    transaction_date DATE NOT NULL,
    payment_reference VARCHAR(100),
    status VARCHAR(50) NOT NULL,
    company_id CHAR(26),
    INDEX idx_employee_company (employee_id, company_id),
    INDEX idx_period_company (period_start, company_id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE compliance_submissions (
    id CHAR(26) PRIMARY KEY,
    compliance_type_id CHAR(26) NOT NULL REFERENCES compliance_types(id),
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    submission_date DATE,
    due_date DATE NOT NULL,
    submitted_by CHAR(26) REFERENCES core_users(id),
    submission_reference VARCHAR(100),
    documents JSON,
    status VARCHAR(50) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- On Duty Management
CREATE TABLE duty_types (
    id CHAR(26) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    requires_travel BOOLEAN DEFAULT false,
    requires_location_tracking BOOLEAN DEFAULT false,
    allowance_rules JSON, -- Daily allowance, travel allowance rules
    approval_required BOOLEAN DEFAULT true,
    company_id CHAR(26),
    INDEX idx_company (company_id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE on_duty_requests (
    id CHAR(26) PRIMARY KEY,
    employee_id CHAR(26) NOT NULL REFERENCES employee_details(id),
    duty_type_id CHAR(26) NOT NULL REFERENCES duty_types(id),
    start_datetime TIMESTAMP NOT NULL,
    end_datetime TIMESTAMP NOT NULL,
    purpose TEXT NOT NULL,
    location_details JSON, -- Address, coordinates, venue details
    travel_required BOOLEAN DEFAULT false,
    status VARCHAR(50) NOT NULL, -- pending, approved, rejected, completed
    approved_by CHAR(26) REFERENCES core_users(id),
    approval_date TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_employee_company (employee_id, company_id),
    INDEX idx_status_company (status, company_id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE duty_travel_details (
    id CHAR(26) PRIMARY KEY,
    duty_request_id CHAR(26) NOT NULL REFERENCES on_duty_requests(id),
    travel_type VARCHAR(50), -- flight, train, road
    departure_location JSON,
    arrival_location JSON,
    departure_datetime TIMESTAMP,
    arrival_datetime TIMESTAMP,
    booking_details JSON, -- Ticket numbers, booking references
    estimated_cost DECIMAL(10,2),
    actual_cost DECIMAL(10,2),
    status VARCHAR(50), -- booked, completed, cancelled
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE duty_allowances (
    id CHAR(26) PRIMARY KEY,
    duty_request_id CHAR(26) NOT NULL REFERENCES on_duty_requests(id),
    allowance_type VARCHAR(50), -- daily, travel, accommodation, food
    amount DECIMAL(10,2),
    currency VARCHAR(3),
    status VARCHAR(50), -- pending, approved, paid
    approved_by CHAR(26) REFERENCES core_users(id),
    payment_date TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE duty_location_logs (
    id CHAR(26) PRIMARY KEY,
    duty_request_id CHAR(26) NOT NULL REFERENCES on_duty_requests(id),
    location JSON, -- latitude, longitude
    recorded_at TIMESTAMP NOT NULL,
    accuracy_meters DECIMAL(10,2),
    device_id VARCHAR(100),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE duty_reports (
    id CHAR(26) PRIMARY KEY,
    duty_request_id CHAR(26) NOT NULL REFERENCES on_duty_requests(id),
    report_date TIMESTAMP NOT NULL,
    summary TEXT,
    activities JSON, -- List of activities performed
    outcomes TEXT,
    attachments JSON, -- Documents, photos, etc.
    submitted_by CHAR(26) REFERENCES core_users(id),
    status VARCHAR(50), -- draft, submitted, approved
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE duty_expenses (
    id CHAR(26) PRIMARY KEY,
    duty_request_id CHAR(26) NOT NULL REFERENCES on_duty_requests(id),
    expense_type VARCHAR(50), -- travel, accommodation, food, other
    amount DECIMAL(10,2),
    currency VARCHAR(3),
    receipt_details JSON, -- Receipt number, images
    description TEXT,
    incurred_date TIMESTAMP NOT NULL,
    status VARCHAR(50), -- submitted, approved, rejected, reimbursed
    approved_by CHAR(26) REFERENCES core_users(id),
    reimbursement_date TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Approval Matrix for On-Duty Requests
CREATE TABLE duty_approval_matrix (
    id CHAR(26) PRIMARY KEY,
    duty_type_id CHAR(26) NOT NULL REFERENCES duty_types(id),
    department_id CHAR(26),
    min_duration_hours INT, -- Minimum duration for this approval level
    max_duration_hours INT, -- Maximum duration for this approval level
    approval_levels JSON NOT NULL, -- Array of approval roles/users in sequence
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE duty_approval_history (
    id CHAR(26) PRIMARY KEY,
    duty_request_id CHAR(26) NOT NULL REFERENCES on_duty_requests(id),
    level_number INT NOT NULL,
    approver_id CHAR(26) REFERENCES core_users(id),
    status VARCHAR(50) NOT NULL, -- approved, rejected, pending
    comments TEXT,
    action_date TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Manual Entry and Correction System
CREATE TABLE manual_entry_types (
    id CHAR(26) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    affected_table VARCHAR(100) NOT NULL,
    requires_approval BOOLEAN DEFAULT true,
    approval_levels JSON, -- Array of roles required for approval
    documentation_required BOOLEAN DEFAULT true,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE manual_entries (
    id CHAR(26) PRIMARY KEY,
    entry_type_id CHAR(26) NOT NULL REFERENCES manual_entry_types(id),
    employee_id CHAR(26) REFERENCES employee_details(id),
    entered_by CHAR(26) NOT NULL REFERENCES core_users(id),
    entry_date TIMESTAMP NOT NULL,
    affected_record_id CHAR(26), -- ID of the record being corrected
    old_value JSON, -- Previous value
    new_value JSON, -- Corrected value
    reason TEXT NOT NULL,
    supporting_documents JSON,
    status VARCHAR(50) NOT NULL, -- pending, approved, rejected
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE manual_entry_approvals (
    id CHAR(26) PRIMARY KEY,
    manual_entry_id CHAR(26) NOT NULL REFERENCES manual_entries(id),
    approver_id CHAR(26) NOT NULL REFERENCES core_users(id),
    approval_level INT NOT NULL,
    status VARCHAR(50) NOT NULL, -- approved, rejected, pending
    comments TEXT,
    action_date TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Enhanced Training Module
CREATE TABLE training_categories (
    id CHAR(26) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    parent_id CHAR(26) REFERENCES training_categories(id),
    company_id CHAR(26),
    INDEX idx_company (company_id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE training_skills (
    id CHAR(26) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    category_id CHAR(26) REFERENCES training_categories(id),
    assessment_criteria JSON,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE training_courses (
    id CHAR(26) PRIMARY KEY,
    category_id CHAR(26) REFERENCES training_categories(id),
    name VARCHAR(200) NOT NULL,
    description TEXT,
    objectives TEXT,
    prerequisites JSON,
    duration_hours INT,
    format VARCHAR(50), -- online, classroom, hybrid
    max_participants INT,
    materials JSON,
    assessment_method VARCHAR(100),
    passing_criteria JSON,
    certification_provided BOOLEAN DEFAULT false,
    cost DECIMAL(10,2),
    status VARCHAR(50) NOT NULL, -- active, draft, archived
    company_id CHAR(26),
    INDEX idx_company_status (company_id, status),
    FOREIGN KEY (company_id) REFERENCES core_companies(id),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE course_modules (
    id CHAR(26) PRIMARY KEY,
    course_id CHAR(26) NOT NULL REFERENCES training_courses(id),
    name VARCHAR(200) NOT NULL,
    description TEXT,
    sequence_no INT NOT NULL,
    duration_hours INT,
    content_type VARCHAR(50), -- video, document, quiz, practical
    content_url TEXT,
    materials JSON,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE training_sessions (
    id CHAR(26) PRIMARY KEY,
    course_id CHAR(26) NOT NULL REFERENCES training_courses(id),
    trainer_id CHAR(26) REFERENCES core_users(id),
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    location VARCHAR(200),
    capacity INT,
    enrolled_count INT DEFAULT 0,
    status VARCHAR(50) NOT NULL, -- scheduled, in_progress, completed, cancelled
    feedback_score DECIMAL(3,2),
    company_id CHAR(26),
    INDEX idx_company_status (company_id, status),
    INDEX idx_course_company (course_id, company_id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE session_attendance (
    id CHAR(26) PRIMARY KEY,
    session_id CHAR(26) NOT NULL REFERENCES training_sessions(id),
    employee_id CHAR(26) NOT NULL REFERENCES employee_details(id),
    date DATE NOT NULL,
    status VARCHAR(50) NOT NULL, -- present, absent, late
    duration_minutes INT,
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE training_assessments (
    id CHAR(26) PRIMARY KEY,
    course_id CHAR(26) NOT NULL REFERENCES training_courses(id),
    module_id CHAR(26) REFERENCES course_modules(id),
    assessment_type VARCHAR(50), -- quiz, practical, project
    questions JSON,
    total_marks INT,
    passing_marks INT,
    duration_minutes INT,
    instructions TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE assessment_attempts (
    id CHAR(26) PRIMARY KEY,
    assessment_id CHAR(26) NOT NULL REFERENCES training_assessments(id),
    employee_id CHAR(26) NOT NULL REFERENCES employee_details(id),
    attempt_number INT NOT NULL,
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP,
    answers JSON,
    score DECIMAL(5,2),
    status VARCHAR(50) NOT NULL, -- in_progress, completed, expired
    reviewed_by CHAR(26) REFERENCES core_users(id),
    feedback TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE training_certifications (
    id CHAR(26) PRIMARY KEY,
    course_id CHAR(26) NOT NULL REFERENCES training_courses(id),
    employee_id CHAR(26) NOT NULL REFERENCES employee_details(id),
    certificate_number VARCHAR(100) UNIQUE,
    issue_date DATE NOT NULL,
    expiry_date DATE,
    issuing_authority VARCHAR(200),
    digital_signature TEXT,
    status VARCHAR(50) NOT NULL, -- active, expired, revoked
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE skill_matrix (
    id CHAR(26) PRIMARY KEY,
    employee_id CHAR(26) NOT NULL REFERENCES employee_details(id),
    skill_id CHAR(26) NOT NULL REFERENCES training_skills(id),
    proficiency_level INT NOT NULL, -- 1-5 or similar scale
    assessed_by CHAR(26) REFERENCES core_users(id),
    assessment_date DATE NOT NULL,
    evidence JSON, -- Certifications, projects, assessments
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE training_feedback (
    id CHAR(26) PRIMARY KEY,
    session_id CHAR(26) NOT NULL REFERENCES training_sessions(id),
    employee_id CHAR(26) NOT NULL REFERENCES employee_details(id),
    ratings JSON, -- Different aspects of training
    comments TEXT,
    suggestions TEXT,
    submitted_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE training_budgets (
    id CHAR(26) PRIMARY KEY,
    department_id CHAR(26),
    year INT NOT NULL,
    allocated_amount DECIMAL(12,2) NOT NULL,
    used_amount DECIMAL(12,2) DEFAULT 0,
    status VARCHAR(50) NOT NULL, -- active, closed
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE training_expenses (
    id CHAR(26) PRIMARY KEY,
    budget_id CHAR(26) NOT NULL REFERENCES training_budgets(id),
    session_id CHAR(26) REFERENCES training_sessions(id),
    expense_type VARCHAR(50) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    description TEXT,
    receipt_details JSON,
    status VARCHAR(50) NOT NULL, -- pending, approved, paid
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);