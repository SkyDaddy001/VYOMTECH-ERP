-- Core Module - Clients, Users, Roles, and Authentication

-- Enable strict mode and UTF8
SET GLOBAL sql_mode = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';
SET NAMES utf8mb4;

-- Client Management (Multi-tenant)
CREATE TABLE core_clients (
    id CHAR(26) PRIMARY KEY,                    -- ULID
    name VARCHAR(255) NOT NULL,
    code VARCHAR(50) NOT NULL UNIQUE,
    type ENUM('developer', 'agency', 'enterprise') NOT NULL,
    status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
    subscription_plan VARCHAR(50),
    subscription_status VARCHAR(50),
    subscription_expiry DATE,
    settings JSON,                              -- Client specific settings
    ui_theme JSON,                              -- Theme customization
    white_label_config JSON,                    -- White labeling settings
    contact_person VARCHAR(255),
    contact_email VARCHAR(255),
    contact_phone VARCHAR(50),
    address TEXT,
    billing_address TEXT,
    gst_number VARCHAR(20),
    pan_number VARCHAR(20),
    api_key VARCHAR(255),                       -- For API access
    rate_limit INT DEFAULT 1000,                -- API rate limit per hour
    features JSON,                              -- Enabled features
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status_subscription (status, subscription_status, subscription_expiry), -- Optimize subscription queries
    INDEX idx_code_status (code, status), -- Optimize lookups by code with status
    INDEX idx_name_status (name(50), status), -- Optimize search by name with status filter
    INDEX idx_status (status),
    INDEX idx_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Companies Management
CREATE TABLE core_companies (
    id CHAR(26) PRIMARY KEY,                    -- ULID
    client_id CHAR(26) NOT NULL,
    name VARCHAR(255) NOT NULL,
    code VARCHAR(50) NOT NULL,
    type ENUM('subsidiary', 'branch', 'franchise', 'affiliate') NOT NULL,
    status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
    registration_number VARCHAR(100),
    tax_number VARCHAR(100),
    gst_number VARCHAR(20),
    contact_person VARCHAR(255),
    contact_email VARCHAR(255),
    contact_phone VARCHAR(50),
    address TEXT,
    city VARCHAR(100),
    state VARCHAR(100),
    country VARCHAR(100),
    pincode VARCHAR(20),
    settings JSON,                              -- Company specific settings
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_client_status (client_id, status),
    INDEX idx_code_status (code, status),
    UNIQUE KEY uk_client_code (client_id, code),
    FOREIGN KEY (client_id) REFERENCES core_clients(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Role-Based Access Control
CREATE TABLE core_roles (
    id CHAR(26) PRIMARY KEY,                    -- ULID
    client_id CHAR(26) NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    permissions JSON NOT NULL COMMENT 'JSON structure containing role permissions with optional company-specific overrides', -- RBAC permissions
    abac_rules JSON,                           -- ABAC rules
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_client (client_id),
    UNIQUE KEY uk_client_name (client_id, name),
    FOREIGN KEY (client_id) REFERENCES core_clients(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- User Management
CREATE TABLE core_users (
    id CHAR(26) PRIMARY KEY,                    -- ULID
    client_id CHAR(26) NOT NULL,
    role_id CHAR(26) NOT NULL,
    email VARCHAR(255) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    designation VARCHAR(100),
    department VARCHAR(100),
    employee_code VARCHAR(50),
    phone VARCHAR(50),
    status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
    preferences JSON,                           -- User preferences
    permissions JSON,                          -- Additional permissions
    features JSON,                             -- Enabled features per user
    settings JSON,                             -- User specific settings
    timezone VARCHAR(50) DEFAULT 'UTC',
    language VARCHAR(10) DEFAULT 'en',
    avatar_url VARCHAR(255),
    can_make_calls BOOLEAN DEFAULT FALSE,
    can_receive_calls BOOLEAN DEFAULT FALSE,
    can_access_queue BOOLEAN DEFAULT FALSE,
    two_fa_enabled BOOLEAN DEFAULT FALSE,
    two_fa_secret VARCHAR(32),
    password_changed_at TIMESTAMP NULL,
    last_login TIMESTAMP NULL,
    last_ip VARCHAR(45),                       -- IPv6 compatible
    last_device VARCHAR(255),
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_client_email (client_id, email),
    INDEX idx_role (role_id),
    INDEX idx_client (client_id),
    INDEX idx_status (status),
    FOREIGN KEY (role_id) REFERENCES core_roles(id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- User-Company Mapping
CREATE TABLE core_user_companies (
    id CHAR(26) PRIMARY KEY,                    -- ULID
    user_id CHAR(26) NOT NULL,
    company_id CHAR(26) NOT NULL,
    is_primary BOOLEAN DEFAULT FALSE,           -- Indicates primary company assignment
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_company (company_id),
    UNIQUE KEY uk_user_company (user_id, company_id),
    FOREIGN KEY (user_id) REFERENCES core_users(id) ON DELETE CASCADE,
    FOREIGN KEY (company_id) REFERENCES core_companies(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- User Sessions and Authentication
CREATE TABLE core_sessions (
    id CHAR(26) PRIMARY KEY,                    -- ULID
    user_id CHAR(26) NOT NULL,
    client_id CHAR(26) NOT NULL,
    token VARCHAR(255) NOT NULL,
    refresh_token VARCHAR(255),
    device_id VARCHAR(100),
    device_info JSON,
    ip_address VARCHAR(45),
    location JSON,
    expires_at TIMESTAMP NOT NULL,
    revoked BOOLEAN DEFAULT FALSE,
    revoked_reason VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_token (token),
    INDEX idx_refresh (refresh_token),
    FOREIGN KEY (user_id) REFERENCES core_users(id) ON DELETE CASCADE,
    FOREIGN KEY (client_id) REFERENCES core_clients(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Password Reset Tokens
CREATE TABLE core_password_resets (
    id CHAR(26) PRIMARY KEY,                    -- ULID
    user_id CHAR(26) NOT NULL,
    token VARCHAR(255) NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    used BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_token (token),
    FOREIGN KEY (user_id) REFERENCES core_users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Feature Flag Management
CREATE TABLE core_feature_flags (
    id CHAR(26) PRIMARY KEY,                    -- ULID
    client_id CHAR(26),                        -- NULL for global flags
    name VARCHAR(100) NOT NULL,
    description TEXT,
    enabled BOOLEAN DEFAULT FALSE,
    conditions JSON,                           -- Conditions for feature availability
    settings JSON,                            -- Feature-specific settings
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_feature_client (name, client_id),
    INDEX idx_client (client_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- System Settings
CREATE TABLE core_settings (
    id CHAR(26) PRIMARY KEY,                    -- ULID
    client_id CHAR(26),                        -- NULL for global settings
    category VARCHAR(50) NOT NULL,
    name VARCHAR(100) NOT NULL,
    value JSON NOT NULL,
    description TEXT,
    is_encrypted BOOLEAN DEFAULT FALSE,
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_setting (client_id, category, name),
    INDEX idx_client_category (client_id, category),
    FOREIGN KEY (client_id) REFERENCES core_clients(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Remove direct company_id from core_users since we now use the mapping table
ALTER TABLE core_users DROP FOREIGN KEY core_users_ibfk_3;
ALTER TABLE core_users DROP COLUMN company_id;

-- Modify core_roles to remove company_id and add company-specific permissions
ALTER TABLE core_roles DROP FOREIGN KEY core_roles_ibfk_2;
ALTER TABLE core_roles DROP COLUMN company_id;
ALTER TABLE core_roles MODIFY COLUMN permissions JSON NOT NULL COMMENT 'JSON structure containing role permissions with optional company-specific overrides';