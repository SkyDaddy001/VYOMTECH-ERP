-- CRM Module - Leads, Contacts, and Activities Management

-- Team and Organization Structure
CREATE TABLE crm_organizations (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    settings JSON,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_client (client_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE crm_teams (
    id CHAR(26) PRIMARY KEY,
    organization_id CHAR(26) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    type VARCHAR(50) NOT NULL,
    settings JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_organization (organization_id),
    FOREIGN KEY (organization_id) REFERENCES crm_organizations(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE crm_team_members (
    id CHAR(26) PRIMARY KEY,
    team_id CHAR(26) NOT NULL,
    user_id CHAR(26) NOT NULL,
    role ENUM('member', 'leader', 'manager') NOT NULL,
    status ENUM('active', 'inactive') DEFAULT 'active',
    permissions JSON,
    settings JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_team_user (team_id, user_id),
    INDEX idx_user (user_id),
    FOREIGN KEY (team_id) REFERENCES crm_teams(id),
    FOREIGN KEY (user_id) REFERENCES core_users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Lead Management
CREATE TABLE crm_leads (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    source_id CHAR(26),
    assigned_to CHAR(26),
    project_id CHAR(26),
    code VARCHAR(50) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100),
    email VARCHAR(255) ENCRYPTED, -- Encrypt sensitive data
    phone VARCHAR(50) ENCRYPTED,
    alternate_phone VARCHAR(50) ENCRYPTED,
    address TEXT ENCRYPTED,
    city VARCHAR(100),
    state VARCHAR(100),
    country VARCHAR(100),
    pincode VARCHAR(20),
    status ENUM('new', 'contacted', 'qualified', 'proposal', 'negotiation', 'won', 'lost', 'duplicate'),
    stage VARCHAR(50),
    priority ENUM('low', 'normal', 'high', 'urgent') DEFAULT 'normal',
    budget_range VARCHAR(50),
    requirements TEXT,
    source_details JSON,
    preferences JSON,
    metadata JSON,
    last_contacted_at TIMESTAMP NULL,
    next_follow_up TIMESTAMP NULL,
    lost_reason TEXT,
    created_by CHAR(26) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_status_priority (status, priority), -- Optimize lead prioritization queries
    INDEX idx_followup_date (next_follow_up) INVISIBLE, -- For follow-up scheduling
    INDEX idx_client_stage (client_id, stage, status), -- Optimize pipeline analysis
    INDEX idx_source_date (source_id, created_at), -- For source effectiveness analysis
    PARTITION BY LIST COLUMNS(status) ( -- Partition by status for better performance
        PARTITION p_active VALUES IN ('new', 'contacted', 'qualified', 'proposal', 'negotiation'),
        PARTITION p_closed VALUES IN ('won', 'lost'),
        PARTITION p_other VALUES IN ('duplicate')
    ),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Lead Sources
CREATE TABLE crm_sources (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    parent_id CHAR(26),
    name VARCHAR(100) NOT NULL,
    type VARCHAR(50) NOT NULL,
    description TEXT,
    settings JSON,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_client (client_id),
    INDEX idx_parent (parent_id),
    UNIQUE KEY uk_client_name (client_id, name),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (parent_id) REFERENCES crm_sources(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Activities and Follow-ups
CREATE TABLE crm_activities (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    lead_id CHAR(26) NOT NULL,
    type ENUM('call', 'meeting', 'email', 'task', 'note'),
    subject VARCHAR(255) NOT NULL,
    description TEXT,
    status ENUM('planned', 'in_progress', 'completed', 'cancelled'),
    scheduled_at TIMESTAMP NULL,
    completed_at TIMESTAMP NULL,
    duration INT,
    priority ENUM('low', 'normal', 'high', 'urgent'),
    assigned_to CHAR(26) NOT NULL,
    created_by CHAR(26) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_lead_status (lead_id, status, scheduled_at), -- Optimize activity tracking
    INDEX idx_assigned_date (assigned_to, scheduled_at), -- For staff workload analysis
    INDEX idx_client_company (client_id, company_id),
    INDEX idx_assigned_company (assigned_to, company_id),
    PARTITION BY RANGE (UNIX_TIMESTAMP(created_at)) (
        PARTITION p_2024 VALUES LESS THAN (UNIX_TIMESTAMP('2025-01-01 00:00:00')),
        PARTITION p_2025 VALUES LESS THAN (UNIX_TIMESTAMP('2026-01-01 00:00:00')),
        PARTITION p_future VALUES LESS THAN MAXVALUE
    ),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Documents
CREATE TABLE crm_documents (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    lead_id CHAR(26) NOT NULL,
    type VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    file_type VARCHAR(100),
    file_size BIGINT,
    storage_provider VARCHAR(50),
    storage_path VARCHAR(255),
    metadata JSON,
    uploaded_by CHAR(26) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_client_lead (client_id, lead_id),
    INDEX idx_type (type),
    INDEX idx_client_company (client_id, company_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (lead_id) REFERENCES crm_leads(id),
    FOREIGN KEY (uploaded_by) REFERENCES core_users(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Notes and Comments
CREATE TABLE crm_notes (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    lead_id CHAR(26) NOT NULL,
    parent_id CHAR(26),
    content TEXT NOT NULL,
    is_private BOOLEAN DEFAULT FALSE,
    attachments JSON,
    created_by CHAR(26) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_client_lead (client_id, lead_id),
    INDEX idx_parent (parent_id),
    INDEX idx_client_company (client_id, company_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (lead_id) REFERENCES crm_leads(id),
    FOREIGN KEY (parent_id) REFERENCES crm_notes(id),
    FOREIGN KEY (created_by) REFERENCES core_users(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Lead Assignment Rules
CREATE TABLE crm_assignment_rules (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    conditions JSON NOT NULL,
    assigned_to CHAR(26) NOT NULL,
    priority INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_client (client_id),
    INDEX idx_assigned (assigned_to),
    INDEX idx_client_company (client_id, company_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (assigned_to) REFERENCES core_users(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Lead Stage History
CREATE TABLE crm_stage_history (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    lead_id CHAR(26) NOT NULL,
    from_stage VARCHAR(50),
    to_stage VARCHAR(50) NOT NULL,
    changed_by CHAR(26) NOT NULL,
    reason TEXT,
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_client_lead (client_id, lead_id),
    INDEX idx_client_company (client_id, company_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (lead_id) REFERENCES crm_leads(id),
    FOREIGN KEY (changed_by) REFERENCES core_users(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Duplicate Lead Detection Rules
CREATE TABLE crm_duplicate_rules (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    match_fields JSON NOT NULL, -- Array of fields to check for duplicates and matching logic
    score_threshold DECIMAL(5,2) NOT NULL, -- Minimum score to consider as duplicate
    auto_merge BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_client (client_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Duplicate Lead Matches
CREATE TABLE crm_duplicate_matches (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    lead_id CHAR(26) NOT NULL,
    potential_duplicate_id CHAR(26) NOT NULL,
    rule_id CHAR(26) NOT NULL,
    match_score DECIMAL(5,2) NOT NULL,
    matched_fields JSON NOT NULL,
    status ENUM('pending', 'merged', 'ignored') DEFAULT 'pending',
    resolved_by CHAR(26),
    resolved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_lead (lead_id),
    INDEX idx_duplicate (potential_duplicate_id),
    INDEX idx_rule (rule_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (lead_id) REFERENCES crm_leads(id),
    FOREIGN KEY (potential_duplicate_id) REFERENCES crm_leads(id),
    FOREIGN KEY (rule_id) REFERENCES crm_duplicate_rules(id),
    FOREIGN KEY (resolved_by) REFERENCES core_users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;