-- Finance Module - Accounts, Transactions, and Budgets

-- Chart of Accounts
CREATE TABLE fin_accounts (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    parent_id CHAR(26),
    code VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    type ENUM('asset', 'liability', 'equity', 'revenue', 'expense') NOT NULL,
    sub_type VARCHAR(50),
    description TEXT,
    is_group BOOLEAN DEFAULT FALSE,
    level INT NOT NULL,
    balance DECIMAL(15,2) DEFAULT 0,
    opening_balance DECIMAL(15,2) DEFAULT 0,
    status ENUM('active', 'inactive') DEFAULT 'active',
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_client_type (client_id, type),
    INDEX idx_parent (parent_id),
    INDEX idx_client_company (client_id, company_id),
    INDEX idx_client_type_company (client_id, type, company_id),
    UNIQUE KEY uk_client_code (client_id, code),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (parent_id) REFERENCES fin_accounts(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Cost Centers
CREATE TABLE fin_cost_centers (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    parent_id CHAR(26),
    code VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_client (client_id),
    INDEX idx_parent (parent_id),
    INDEX idx_client_company (client_id, company_id),
    UNIQUE KEY uk_client_code (client_id, code),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (parent_id) REFERENCES fin_cost_centers(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Transactions
CREATE TABLE fin_transactions (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    transaction_date DATE NOT NULL,
    posting_date DATE NOT NULL,
    type ENUM('journal', 'payment', 'receipt', 'contra', 'adjustment') NOT NULL,
    reference_type VARCHAR(50),
    reference_id CHAR(26),
    description TEXT,
    status ENUM('draft', 'posted', 'voided') DEFAULT 'draft',
    total_debit DECIMAL(15,2) DEFAULT 0,
    total_credit DECIMAL(15,2) DEFAULT 0,
    metadata JSON,
    created_by CHAR(26) NOT NULL,
    approved_by CHAR(26),
    voided_by CHAR(26),
    void_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    company_id CHAR(26),
    INDEX idx_client_dates (client_id, transaction_date, posting_date),
    INDEX idx_reference (reference_type, reference_id),
    INDEX idx_status (status),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (created_by) REFERENCES core_users(id),
    FOREIGN KEY (approved_by) REFERENCES core_users(id),
    FOREIGN KEY (voided_by) REFERENCES core_users(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE fin_transaction_lines (
    id CHAR(26) PRIMARY KEY,
    transaction_id CHAR(26) NOT NULL,
    account_id CHAR(26) NOT NULL,
    description TEXT,
    debit_amount DECIMAL(15,2) DEFAULT 0,
    credit_amount DECIMAL(15,2) DEFAULT 0,
    cost_center_id CHAR(26),
    project_id CHAR(26),
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_transaction (transaction_id),
    INDEX idx_account (account_id),
    INDEX idx_project (project_id),
    FOREIGN KEY (transaction_id) REFERENCES fin_transactions(id),
    FOREIGN KEY (account_id) REFERENCES fin_accounts(id),
    FOREIGN KEY (project_id) REFERENCES prop_projects(id),
    FOREIGN KEY (cost_center_id) REFERENCES fin_cost_centers(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Budgets
CREATE TABLE fin_budgets (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    project_id CHAR(26),
    cost_center_id CHAR(26),
    fiscal_year VARCHAR(10) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    status ENUM('draft', 'approved', 'closed') DEFAULT 'draft',
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    total_budget DECIMAL(15,2) DEFAULT 0,
    actual_spent DECIMAL(15,2) DEFAULT 0,
    metadata JSON,
    created_by CHAR(26) NOT NULL,
    approved_by CHAR(26),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_client_year (client_id, fiscal_year),
    INDEX idx_project (project_id),
    INDEX idx_cost_center (cost_center_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (project_id) REFERENCES prop_projects(id),
    FOREIGN KEY (cost_center_id) REFERENCES fin_cost_centers(id),
    FOREIGN KEY (created_by) REFERENCES core_users(id),
    FOREIGN KEY (approved_by) REFERENCES core_users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE fin_budget_lines (
    id CHAR(26) PRIMARY KEY,
    budget_id CHAR(26) NOT NULL,
    account_id CHAR(26) NOT NULL,
    period VARCHAR(7) NOT NULL,
    amount DECIMAL(15,2) DEFAULT 0,
    actual_amount DECIMAL(15,2) DEFAULT 0,
    variance DECIMAL(15,2) DEFAULT 0,
    notes TEXT,
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_budget_account (budget_id, account_id),
    INDEX idx_period (period),
    FOREIGN KEY (budget_id) REFERENCES fin_budgets(id),
    FOREIGN KEY (account_id) REFERENCES fin_accounts(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tax Configuration
CREATE TABLE fin_tax_config (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(50) NOT NULL,
    rate DECIMAL(5,2) NOT NULL,
    hsn_code VARCHAR(50),
    account_id CHAR(26) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_client (client_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (account_id) REFERENCES fin_accounts(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;