-- Communications Module - Messages, Templates, and Notifications

-- Communication providers configuration
CREATE TABLE comm_providers (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    name VARCHAR(255) NOT NULL,
    type ENUM('sms', 'email', 'whatsapp', 'telegram') NOT NULL,
    provider_code VARCHAR(50) NOT NULL,
    config JSON NOT NULL,
    rate_limit_per_minute INT,
    rate_limit_per_day INT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_client_type (client_id, type),
    UNIQUE KEY uk_client_provider (client_id, provider_code),
    FOREIGN KEY (client_id) REFERENCES core_clients(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Message Templates
CREATE TABLE comm_templates (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    type ENUM('email', 'sms', 'whatsapp', 'telegram', 'notification') NOT NULL,
    code VARCHAR(100) NOT NULL,
    name VARCHAR(255) NOT NULL,
    subject VARCHAR(255),
    content TEXT NOT NULL,
    variables JSON,
    placeholders JSON,
    metadata JSON,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_client_type (client_id, type),
    UNIQUE KEY uk_client_code (client_id, code),
    FOREIGN KEY (client_id) REFERENCES core_clients(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Communication Logs
CREATE TABLE comm_logs (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    template_id CHAR(26),
    type ENUM('email', 'sms', 'whatsapp', 'telegram', 'notification') NOT NULL,
    status VARCHAR(50) NOT NULL,
    from_address VARCHAR(255),
    to_address VARCHAR(255),
    cc_address TEXT,
    bcc_address TEXT,
    subject VARCHAR(255),
    content TEXT,
    variables JSON,
    attachments JSON,
    provider VARCHAR(50),
    provider_message_id VARCHAR(255),
    sent_at TIMESTAMP NULL,
    delivered_at TIMESTAMP NULL,
    read_at TIMESTAMP NULL,
    error TEXT,
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_client_type (client_id, type),
    INDEX idx_template (template_id),
    INDEX idx_status (status),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (template_id) REFERENCES comm_templates(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Notifications
CREATE TABLE comm_notifications (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    user_id CHAR(26) NOT NULL,
    type VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    priority ENUM('low', 'normal', 'high', 'urgent') DEFAULT 'normal',
    read BOOLEAN DEFAULT FALSE,
    read_at TIMESTAMP NULL,
    data JSON,
    action_url VARCHAR(255),
    icon_url VARCHAR(255),
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_unread (user_id, read),
    INDEX idx_client (client_id),
    INDEX idx_type (type),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (user_id) REFERENCES core_users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- User Notification Preferences
CREATE TABLE comm_notification_preferences (
    id CHAR(26) PRIMARY KEY,
    user_id CHAR(26) NOT NULL,
    client_id CHAR(26) NOT NULL,
    notification_type VARCHAR(50) NOT NULL,
    channel ENUM('email', 'sms', 'whatsapp', 'telegram', 'in_app') NOT NULL,
    enabled BOOLEAN DEFAULT TRUE,
    quiet_hours_start TIME,
    quiet_hours_end TIME,
    settings JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_user_type_channel (user_id, notification_type, channel),
    INDEX idx_client (client_id),
    FOREIGN KEY (user_id) REFERENCES core_users(id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Email Configuration
CREATE TABLE comm_email_config (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    provider ENUM('smtp', 'aws_ses', 'sendgrid', 'mailgun') NOT NULL,
    is_default BOOLEAN DEFAULT FALSE,
    from_email VARCHAR(255) NOT NULL,
    from_name VARCHAR(255),
    reply_to VARCHAR(255),
    host VARCHAR(255),
    port INT,
    username VARCHAR(255),
    password_encrypted VARCHAR(255),
    encryption_type ENUM('tls', 'ssl') DEFAULT 'tls',
    api_key_encrypted VARCHAR(255),
    settings JSON,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_client (client_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- SMS Configuration
CREATE TABLE comm_sms_config (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    provider ENUM('twilio', 'aws_sns', 'msg91', 'custom') NOT NULL,
    is_default BOOLEAN DEFAULT FALSE,
    from_number VARCHAR(20),
    account_sid VARCHAR(255),
    auth_token_encrypted VARCHAR(255),
    api_key_encrypted VARCHAR(255),
    settings JSON,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_client (client_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- WhatsApp Configuration
CREATE TABLE comm_whatsapp_config (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    provider ENUM('twilio', 'facebook', 'custom') NOT NULL,
    is_default BOOLEAN DEFAULT FALSE,
    phone_number VARCHAR(20),
    business_account_id VARCHAR(255),
    api_key_encrypted VARCHAR(255),
    webhook_url VARCHAR(255),
    webhook_secret_encrypted VARCHAR(255),
    template_namespace VARCHAR(255),
    settings JSON,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_client (client_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;