-- Quality Control & Testing Module
CREATE TABLE qc_inspection_types (
    id CHAR(26) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    checklist_template JSON NOT NULL
        CHECK (JSON_VALID(checklist_template) 
            AND JSON_LENGTH(checklist_template) > 0),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE qc_inspections (
    id CHAR(26) PRIMARY KEY,
    inspection_type_id CHAR(26) NOT NULL,
    inspector_id CHAR(26) NOT NULL,
    status VARCHAR(50) NOT NULL,
    inspection_date TIMESTAMP,
    results JSON NOT NULL
        CHECK (JSON_VALID(results)),
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_type_status (inspection_type_id, status), -- Optimize inspection queries
    INDEX idx_inspector_date (inspector_id, inspection_date), -- For inspector workload analysis
    INDEX idx_date_status (inspection_date, status), -- For timeline analysis
    FOREIGN KEY (inspection_type_id) REFERENCES qc_inspection_types(id),
    FOREIGN KEY (inspector_id) REFERENCES core_users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
PARTITION BY RANGE (UNIX_TIMESTAMP(inspection_date)) ( -- Partition by date for better performance
    PARTITION p_history VALUES LESS THAN (UNIX_TIMESTAMP('2024-01-01 00:00:00')),
    PARTITION p_current VALUES LESS THAN (UNIX_TIMESTAMP('2025-01-01 00:00:00')),
    PARTITION p_future VALUES LESS THAN MAXVALUE
);

CREATE TABLE material_tests (
    id CHAR(26) PRIMARY KEY,
    material_id CHAR(26) NOT NULL,
    test_type VARCHAR(100) NOT NULL,
    test_date TIMESTAMP NOT NULL,
    performed_by CHAR(26) NOT NULL,
    results JSON NOT NULL
        CHECK (JSON_VALID(results)),
    pass_fail BOOLEAN,
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_material_date (material_id, test_date), -- For material history
    INDEX idx_type_result (test_type, pass_fail), -- For test analysis
    INDEX idx_performer (performed_by), -- For staff performance tracking
    FOREIGN KEY (material_id) REFERENCES stk_materials(id),
    FOREIGN KEY (performed_by) REFERENCES core_users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE quality_checklists (
    id CHAR(26) PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    checklist_items JSON NOT NULL
        CHECK (JSON_VALID(checklist_items) 
            AND JSON_LENGTH(checklist_items) > 0),
    category VARCHAR(100),
    version INT NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_category_version (category, version), -- For version management
    INDEX idx_name_version (name, version) -- For quick lookups
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE defect_tracking (
    id CHAR(26) PRIMARY KEY,
    project_id CHAR(26) NOT NULL,
    reported_by CHAR(26) NOT NULL,
    assigned_to CHAR(26) NOT NULL,
    defect_type VARCHAR(100) NOT NULL,
    severity VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL,
    description TEXT,
    resolution TEXT,
    discovery_date TIMESTAMP NOT NULL,
    resolution_date TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_project_status (project_id, status), -- For project quality analysis
    INDEX idx_severity_status (severity, status), -- For critical issues monitoring
    INDEX idx_assigned_status (assigned_to, status), -- For workload management
    INDEX idx_discovery_resolution (discovery_date, resolution_date), -- For resolution time analysis
    FOREIGN KEY (project_id) REFERENCES prop_projects(id),
    FOREIGN KEY (reported_by) REFERENCES core_users(id),
    FOREIGN KEY (assigned_to) REFERENCES core_users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;