-- BOQ (Bill of Quantities) Module - Construction and Property Development Cost Estimation

-- Common Category Table (replaces separate category tables for materials, labor, and equipment)
CREATE TABLE boq_categories (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    parent_id CHAR(26),
    type ENUM('material', 'labor', 'equipment') NOT NULL,
    code VARCHAR(50) NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    level INT NOT NULL,
    sort_order INT DEFAULT 0,
    company_id CHAR(26),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_client_type (client_id, type),
    INDEX idx_parent (parent_id),
    INDEX idx_client_company (client_id, company_id),
    INDEX idx_type_company (type, company_id),
    UNIQUE KEY uk_client_code_type (client_id, code, type),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (parent_id) REFERENCES boq_categories(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Resource Base Table (common fields for materials, labor, and equipment)
CREATE TABLE boq_resources (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    category_id CHAR(26) NOT NULL,
    type ENUM('material', 'labor', 'equipment') NOT NULL,
    code VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    unit_id CHAR(26) NOT NULL,
    base_rate DECIMAL(15,4) NOT NULL,
    specifications JSON,
    is_active BOOLEAN DEFAULT TRUE,
    company_id CHAR(26),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_client_type (client_id, type),
    INDEX idx_category (category_id),
    INDEX idx_client_company (client_id, company_id),
    INDEX idx_type_company (type, company_id),
    INDEX idx_category_company (category_id, company_id),
    UNIQUE KEY uk_client_code (client_id, code),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (category_id) REFERENCES boq_categories(id),
    FOREIGN KEY (unit_id) REFERENCES ref_units(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Material-specific attributes
CREATE TABLE boq_material_attributes (
    resource_id CHAR(26) PRIMARY KEY,
    markup_percentage DECIMAL(5,2) DEFAULT 0,
    wastage_percentage DECIMAL(5,2) DEFAULT 0,
    minimum_order_qty DECIMAL(15,4),
    lead_time_days INT,
    FOREIGN KEY (resource_id) REFERENCES boq_resources(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Labor-specific attributes
CREATE TABLE boq_labor_attributes (
    resource_id CHAR(26) PRIMARY KEY,
    overtime_multiplier DECIMAL(5,2) DEFAULT 1.5,
    weekend_multiplier DECIMAL(5,2) DEFAULT 2.0,
    holiday_multiplier DECIMAL(5,2) DEFAULT 2.5,
    minimum_hours DECIMAL(5,2) DEFAULT 8,
    FOREIGN KEY (resource_id) REFERENCES boq_resources(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Equipment-specific attributes
CREATE TABLE boq_equipment_attributes (
    resource_id CHAR(26) PRIMARY KEY,
    rate_per_day DECIMAL(15,4),
    rate_per_week DECIMAL(15,4),
    rate_per_month DECIMAL(15,4),
    minimum_rental_period VARCHAR(20),
    FOREIGN KEY (resource_id) REFERENCES boq_resources(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Work Items (Activities)
CREATE TABLE boq_work_items (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    parent_id CHAR(26),
    code VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    unit_id CHAR(26) NOT NULL,
    estimated_duration DECIMAL(10,2),
    duration_unit VARCHAR(20),
    resources JSON, -- Combines materials, labor, and equipment in a structured format
    overhead_percentage DECIMAL(5,2) DEFAULT 0,
    profit_percentage DECIMAL(5,2) DEFAULT 0,
    specifications JSON,
    prerequisites JSON,
    is_template BOOLEAN DEFAULT FALSE,
    company_id CHAR(26),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_client (client_id),
    INDEX idx_parent (parent_id),
    INDEX idx_client_company (client_id, company_id),
    INDEX idx_template_company (is_template, company_id),
    UNIQUE KEY uk_client_code (client_id, code),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (parent_id) REFERENCES boq_work_items(id),
    FOREIGN KEY (unit_id) REFERENCES ref_units(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Projects
CREATE TABLE boq_projects (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    property_id CHAR(26),
    code VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    start_date DATE,
    end_date DATE,
    status ENUM('draft', 'submitted', 'approved', 'in_progress', 'completed', 'cancelled') DEFAULT 'draft',
    currency_code VARCHAR(3) NOT NULL,
    exchange_rate DECIMAL(15,6) DEFAULT 1,
    total_cost DECIMAL(15,4),
    financial_settings JSON, -- Combines overhead, profit, contingency, and tax percentages
    metadata JSON,
    created_by CHAR(26) NOT NULL,
    approved_by CHAR(26),
    approved_at TIMESTAMP NULL,
    company_id CHAR(26),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_client_status (client_id, status),
    INDEX idx_property (property_id),
    INDEX idx_client_company (client_id, company_id),
    INDEX idx_status_company (status, company_id),
    UNIQUE KEY uk_client_code (client_id, code),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (property_id) REFERENCES prop_properties(id),
    FOREIGN KEY (created_by) REFERENCES core_users(id),
    FOREIGN KEY (approved_by) REFERENCES core_users(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Project Items
CREATE TABLE boq_project_items (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    project_id CHAR(26) NOT NULL,
    work_item_id CHAR(26) NOT NULL,
    parent_id CHAR(26),
    code VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    quantity DECIMAL(15,4) NOT NULL,
    unit_id CHAR(26) NOT NULL,
    costs JSON, -- Structured JSON containing unit_rate, total_cost, and breakdown by resource type
    resources JSON, -- Structured JSON containing materials, labor, and equipment details
    specifications JSON,
    sort_order INT DEFAULT 0,
    company_id CHAR(26),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_project (project_id),
    INDEX idx_work_item (work_item_id),
    INDEX idx_parent (parent_id),
    INDEX idx_client_company (client_id, company_id),
    INDEX idx_project_company (project_id, company_id),
    UNIQUE KEY uk_project_code (project_id, code),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (project_id) REFERENCES boq_projects(id),
    FOREIGN KEY (work_item_id) REFERENCES boq_work_items(id),
    FOREIGN KEY (parent_id) REFERENCES boq_project_items(id),
    FOREIGN KEY (unit_id) REFERENCES ref_units(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Versions (Revision History)
CREATE TABLE boq_versions (
    id CHAR(26) PRIMARY KEY,
    client_id CHAR(26) NOT NULL,
    project_id CHAR(26) NOT NULL,
    version_number INT NOT NULL,
    description TEXT,
    changes_summary TEXT,
    total_cost DECIMAL(15,4) NOT NULL,
    status ENUM('draft', 'submitted', 'approved', 'rejected') DEFAULT 'draft',
    data JSON NOT NULL,
    created_by CHAR(26) NOT NULL,
    approved_by CHAR(26),
    approved_at TIMESTAMP NULL,
    company_id CHAR(26),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_project_version (project_id, version_number),
    INDEX idx_client_company (client_id, company_id),
    INDEX idx_project_company (project_id, company_id),
    INDEX idx_status_company (status, company_id),
    FOREIGN KEY (client_id) REFERENCES core_clients(id),
    FOREIGN KEY (project_id) REFERENCES boq_projects(id),
    FOREIGN KEY (created_by) REFERENCES core_users(id),
    FOREIGN KEY (approved_by) REFERENCES core_users(id),
    FOREIGN KEY (company_id) REFERENCES core_companies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;