-- Equipment & Asset Management Module
CREATE TABLE equipment (
    id CHAR(26) PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    model VARCHAR(100),
    serial_number VARCHAR(100),
    manufacturer VARCHAR(100),
    purchase_date TIMESTAMP,
    warranty_expiry TIMESTAMP,
    status VARCHAR(50) NOT NULL, -- active, maintenance, retired
    location VARCHAR(200),
    department_id CHAR(26),
    specifications JSON,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE maintenance_schedules (
    id CHAR(26) PRIMARY KEY,
    equipment_id CHAR(26) NOT NULL REFERENCES equipment(id),
    maintenance_type VARCHAR(100) NOT NULL,
    frequency_days INT NOT NULL,
    last_maintenance TIMESTAMP,
    next_maintenance TIMESTAMP,
    instructions TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE maintenance_logs (
    id CHAR(26) PRIMARY KEY,
    equipment_id CHAR(26) NOT NULL REFERENCES equipment(id),
    maintenance_type VARCHAR(100) NOT NULL,
    performed_by CHAR(26) REFERENCES core_users(id),
    maintenance_date TIMESTAMP NOT NULL,
    work_done TEXT,
    parts_replaced JSON,
    cost DECIMAL(10,2),
    next_maintenance TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE equipment_calibration (
    id CHAR(26) PRIMARY KEY,
    equipment_id CHAR(26) NOT NULL REFERENCES equipment(id),
    calibration_date TIMESTAMP NOT NULL,
    performed_by CHAR(26) REFERENCES core_users(id),
    calibration_results JSON,
    next_calibration TIMESTAMP,
    certificate_number VARCHAR(100),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE asset_lifecycle (
    id CHAR(26) PRIMARY KEY,
    equipment_id CHAR(26) NOT NULL REFERENCES equipment(id),
    lifecycle_stage VARCHAR(50) NOT NULL,
    acquisition_cost DECIMAL(10,2),
    current_value DECIMAL(10,2),
    depreciation_method VARCHAR(50),
    expected_lifetime_months INT,
    disposal_date TIMESTAMP,
    disposal_value DECIMAL(10,2),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE iot_sensors (
    id CHAR(26) PRIMARY KEY,
    equipment_id CHAR(26) NOT NULL REFERENCES equipment(id),
    sensor_type VARCHAR(100) NOT NULL,
    location VARCHAR(200),
    specifications JSON,
    last_reading TIMESTAMP,
    status VARCHAR(50),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE sensor_readings (
    id CHAR(26) PRIMARY KEY,
    sensor_id CHAR(26) NOT NULL REFERENCES iot_sensors(id),
    reading_timestamp TIMESTAMP NOT NULL,
    reading_type VARCHAR(50) NOT NULL,
    reading_value JSON NOT NULL,
    units VARCHAR(50),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);