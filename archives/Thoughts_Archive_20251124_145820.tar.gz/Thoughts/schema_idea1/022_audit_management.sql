-- Enhanced Audit Trail Management
CREATE TABLE sys_audit_config (
    id CHAR(26) PRIMARY KEY,
    entity_type VARCHAR(100) NOT NULL,
    tracking_level ENUM('none', 'basic', 'detailed', 'full') NOT NULL,
    tracked_fields JSON,
    retention_days INT DEFAULT 365,
    alert_config JSON,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_entity_type (entity_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Audit Alerts Configuration
CREATE TABLE sys_audit_alerts (
    id CHAR(26) PRIMARY KEY,
    alert_type VARCHAR(50) NOT NULL,
    entity_types JSON NOT NULL,
    conditions JSON NOT NULL,
    notification_channels JSON NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_alert_type (alert_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Audit Trail Procedures
DELIMITER //

CREATE PROCEDURE sp_track_data_change(
    IN p_entity_type VARCHAR(100),
    IN p_entity_id CHAR(26),
    IN p_action VARCHAR(50),
    IN p_old_values JSON,
    IN p_new_values JSON,
    IN p_user_id CHAR(26)
)
BEGIN
    DECLARE v_tracking_level VARCHAR(10);
    DECLARE v_alert_config JSON;
    DECLARE v_alert_needed BOOLEAN DEFAULT FALSE;
    
    -- Get audit configuration
    SELECT 
        tracking_level,
        alert_config
    INTO 
        v_tracking_level,
        v_alert_config
    FROM sys_audit_config
    WHERE entity_type = p_entity_type;
    
    -- Insert audit log based on tracking level
    IF v_tracking_level != 'none' THEN
        INSERT INTO sys_audit_logs (
            id,
            entity_type,
            entity_id,
            action,
            old_values,
            new_values,
            user_id,
            created_at
        ) VALUES (
            REPLACE(UUID(),'-',''),
            p_entity_type,
            p_entity_id,
            p_action,
            CASE 
                WHEN v_tracking_level = 'full' THEN p_old_values
                WHEN v_tracking_level = 'detailed' THEN JSON_REMOVE(p_old_values, '$.sensitive_data')
                ELSE NULL
            END,
            CASE 
                WHEN v_tracking_level = 'full' THEN p_new_values
                WHEN v_tracking_level = 'detailed' THEN JSON_REMOVE(p_new_values, '$.sensitive_data')
                ELSE NULL
            END,
            p_user_id,
            NOW()
        );
    END IF;
    
    -- Process alerts
    FOR alert_config IN 
        SELECT *
        FROM sys_audit_alerts
        WHERE is_active = TRUE
        AND JSON_CONTAINS(entity_types, JSON_ARRAY(p_entity_type))
    DO
        IF sp_evaluate_alert_conditions(
            alert_config.conditions, 
            p_action,
            p_old_values,
            p_new_values
        ) THEN
            CALL sp_generate_audit_alert(
                alert_config.id,
                p_entity_type,
                p_entity_id,
                p_action,
                p_user_id
            );
        END IF;
    END FOR;
END //

CREATE PROCEDURE sp_evaluate_alert_conditions(
    IN p_conditions JSON,
    IN p_action VARCHAR(50),
    IN p_old_values JSON,
    IN p_new_values JSON
)
RETURNS BOOLEAN
BEGIN
    DECLARE v_result BOOLEAN DEFAULT FALSE;
    
    -- Evaluate conditions based on action type
    CASE p_action
        WHEN 'update' THEN
            -- Check for specific field changes
            SET v_result = (
                SELECT COUNT(*)
                FROM JSON_TABLE(
                    p_conditions->'$.fields',
                    '$[*]' COLUMNS(
                        field_path VARCHAR(100) PATH '$'
                    )
                ) fields
                WHERE JSON_EXTRACT(p_old_values, field_path) != 
                      JSON_EXTRACT(p_new_values, field_path)
            ) > 0;
        WHEN 'delete' THEN
            -- Always alert on deletes if configured
            SET v_result = JSON_EXTRACT(p_conditions, '$.alert_on_delete');
        ELSE
            -- Custom condition evaluation
            SET v_result = FALSE;
    END CASE;
    
    RETURN v_result;
END //

CREATE PROCEDURE sp_generate_audit_alert(
    IN p_alert_config_id CHAR(26),
    IN p_entity_type VARCHAR(100),
    IN p_entity_id CHAR(26),
    IN p_action VARCHAR(50),
    IN p_user_id CHAR(26)
)
BEGIN
    DECLARE v_alert_config JSON;
    
    -- Get alert configuration
    SELECT notification_channels
    INTO v_alert_config
    FROM sys_audit_alerts
    WHERE id = p_alert_config_id;
    
    -- Generate alert
    INSERT INTO sys_alerts (
        id,
        alert_type,
        severity,
        message,
        context,
        created_at
    ) VALUES (
        REPLACE(UUID(),'-',''),
        'AUDIT_ALERT',
        CASE 
            WHEN p_action IN ('delete', 'bulk_delete') THEN 'high'
            WHEN p_action IN ('update', 'bulk_update') THEN 'medium'
            ELSE 'low'
        END,
        CONCAT('Audit alert for ', p_entity_type, ' - ', p_action),
        JSON_OBJECT(
            'entity_type', p_entity_type,
            'entity_id', p_entity_id,
            'action', p_action,
            'user_id', p_user_id,
            'alert_config_id', p_alert_config_id
        ),
        NOW()
    );
    
    -- Send notifications based on configured channels
    CALL sp_send_audit_notifications(
        LAST_INSERT_ID(),
        v_alert_config
    );
END //

CREATE PROCEDURE sp_cleanup_audit_logs()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_entity_type VARCHAR(100);
    DECLARE v_retention_days INT;
    DECLARE cur CURSOR FOR 
        SELECT entity_type, retention_days 
        FROM sys_audit_config;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN cur;
    read_loop: LOOP
        FETCH cur INTO v_entity_type, v_retention_days;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        -- Archive old audit logs before deletion
        INSERT INTO sys_audit_logs_archive
        SELECT *
        FROM sys_audit_logs 
        WHERE entity_type = v_entity_type
        AND created_at < DATE_SUB(NOW(), INTERVAL v_retention_days DAY);
        
        -- Delete old audit logs
        DELETE FROM sys_audit_logs 
        WHERE entity_type = v_entity_type
        AND created_at < DATE_SUB(NOW(), INTERVAL v_retention_days DAY)
        AND id IN (SELECT id FROM sys_audit_logs_archive);
    END LOOP;
    CLOSE cur;
END //

DELIMITER ;