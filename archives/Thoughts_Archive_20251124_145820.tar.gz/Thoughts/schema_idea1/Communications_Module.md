# Communications Module

## Overview
The Communications Module is designed to handle all communication-related functionalities, including messages, templates, notifications, and configurations for various communication channels such as email, SMS, WhatsApp, and Telegram.

## Database Design

### Tables

1. **comm_providers**
   - Stores configuration details for communication providers.
   - Fields: `id`, `client_id`, `name`, `type`, `provider_code`, `config`, `rate_limit_per_minute`, `rate_limit_per_day`, `is_active`, `created_at`, `updated_at`.

2. **comm_templates**
   - Manages message templates for different communication types.
   - Fields: `id`, `client_id`, `type`, `code`, `name`, `subject`, `content`, `variables`, `placeholders`, `metadata`, `is_active`, `created_at`, `updated_at`.

3. **comm_logs**
   - Logs all communication activities.
   - Fields: `id`, `client_id`, `template_id`, `type`, `status`, `from_address`, `to_address`, `cc_address`, `bcc_address`, `subject`, `content`, `variables`, `attachments`, `provider`, `provider_message_id`, `sent_at`, `delivered_at`, `read_at`, `error`, `metadata`, `created_at`, `updated_at`.

4. **comm_notifications**
   - Handles user notifications.
   - Fields: `id`, `client_id`, `user_id`, `type`, `title`, `message`, `priority`, `read`, `read_at`, `data`, `action_url`, `icon_url`, `expires_at`, `created_at`, `updated_at`.

5. **comm_notification_preferences**
   - Stores user preferences for notifications.
   - Fields: `id`, `user_id`, `client_id`, `notification_type`, `channel`, `enabled`, `quiet_hours_start`, `quiet_hours_end`, `settings`, `created_at`, `updated_at`.

6. **comm_email_config**
   - Configuration for email providers.
   - Fields: `id`, `client_id`, `provider`, `is_default`, `from_email`, `from_name`, `reply_to`, `host`, `port`, `username`, `password_encrypted`, `encryption_type`, `api_key_encrypted`, `settings`, `is_active`, `created_at`, `updated_at`.

7. **comm_sms_config**
   - Configuration for SMS providers.
   - Fields: `id`, `client_id`, `provider`, `is_default`, `from_number`, `account_sid`, `auth_token_encrypted`, `api_key_encrypted`, `settings`, `is_active`, `created_at`, `updated_at`.

8. **comm_whatsapp_config**
   - Configuration for WhatsApp providers.
   - Fields: `id`, `client_id`, `provider`, `is_default`, `phone_number`, `business_account_id`, `api_key_encrypted`, `webhook_url`, `webhook_secret_encrypted`, `template_namespace`, `settings`, `is_active`, `created_at`, `updated_at`.

## Functions

- **Provider Management**
  - Add, update, and deactivate communication providers.

- **Template Management**
  - Create, update, and delete message templates.

- **Notification Management**
  - Send and track notifications.

- **Logging**
  - Maintain logs for all communication activities.

- **Configuration**
  - Manage configurations for email, SMS, and WhatsApp providers.

## Future Enhancements

- Add support for additional communication channels.
- Implement advanced analytics for communication logs.