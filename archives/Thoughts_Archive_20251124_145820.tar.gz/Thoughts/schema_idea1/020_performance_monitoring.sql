-- Performance monitoring views
CREATE OR REPLACE VIEW vw_slow_queries AS
SELECT event_name, count_star, avg_timer_wait/1000000000 as avg_latency_ms,
       sum_timer_wait/1000000000 as total_latency_ms,
       sum_lock_time/1000000000 as total_lock_time_ms
FROM performance_schema.events_statements_summary_by_digest
WHERE avg_timer_wait > 1000000000 -- queries taking more than 1 second
ORDER BY avg_timer_wait DESC;

CREATE OR REPLACE VIEW vw_table_stats AS
SELECT 
    t.TABLE_NAME,
    t.TABLE_ROWS,
    t.AVG_ROW_LENGTH,
    t.DATA_LENGTH/1024/1024 as data_size_mb,
    t.INDEX_LENGTH/1024/1024 as index_size_mb,
    t.UPDATE_TIME
FROM information_schema.TABLES t
WHERE t.TABLE_SCHEMA = DATABASE();

-- Add partitioning to tables with high data volume
ALTER TABLE crm_activities
    PARTITION BY RANGE COLUMNS(created_at) (
        PARTITION p_2024h1 VALUES LESS THAN ('2024-07-01 00:00:00'),
        PARTITION p_2024h2 VALUES LESS THAN ('2025-01-01 00:00:00'),
        PARTITION p_2025h1 VALUES LESS THAN ('2025-07-01 00:00:00'),
        PARTITION p_future VALUES LESS THAN (MAXVALUE)
    );

ALTER TABLE sys_audit_logs
    PARTITION BY RANGE (UNIX_TIMESTAMP(created_at)) (
        PARTITION p_2024 VALUES LESS THAN (UNIX_TIMESTAMP('2025-01-01 00:00:00')),
        PARTITION p_2025 VALUES LESS THAN (UNIX_TIMESTAMP('2026-01-01 00:00:00')),
        PARTITION p_future VALUES LESS THAN MAXVALUE
    );

-- Add compression to historical data tables
ALTER TABLE sys_audit_logs ROW_FORMAT=COMPRESSED KEY_BLOCK_SIZE=8;
ALTER TABLE sys_error_logs ROW_FORMAT=COMPRESSED KEY_BLOCK_SIZE=8;

-- Performance Configuration
CREATE TABLE sys_performance_settings (
    id CHAR(26) PRIMARY KEY,
    setting_type VARCHAR(50) NOT NULL,
    setting_name VARCHAR(100) NOT NULL,
    setting_value JSON NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_setting (setting_type, setting_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Query Performance Monitoring
CREATE TABLE sys_query_statistics (
    id CHAR(26) PRIMARY KEY,
    query_pattern_id CHAR(26),
    query_text TEXT NOT NULL,
    execution_time_ms DECIMAL(10,2) NOT NULL,
    rows_examined INT,
    rows_affected INT,
    full_scan_count INT,
    index_usage JSON,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_pattern (query_pattern_id),
    INDEX idx_execution_time (execution_time_ms)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
PARTITION BY RANGE (UNIX_TIMESTAMP(created_at)) (
    PARTITION p_current VALUES LESS THAN (UNIX_TIMESTAMP(NOW())),
    PARTITION p_future VALUES LESS THAN MAXVALUE
);

-- Index Usage Tracking
CREATE TABLE sys_index_usage_stats (
    id CHAR(26) PRIMARY KEY,
    table_name VARCHAR(100) NOT NULL,
    index_name VARCHAR(100) NOT NULL,
    used_count BIGINT DEFAULT 0,
    last_used TIMESTAMP,
    avg_impact_percentage DECIMAL(5,2),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_table_index (table_name, index_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sharding Configuration
CREATE TABLE sys_sharding_config (
    id CHAR(26) PRIMARY KEY,
    table_name VARCHAR(100) NOT NULL,
    shard_key VARCHAR(100) NOT NULL,
    shard_algorithm ENUM('hash', 'range', 'list') NOT NULL,
    num_shards INT NOT NULL,
    shard_distribution JSON NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_table (table_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create performance monitoring stored procedures
DELIMITER //

CREATE PROCEDURE sp_analyze_table_growth()
BEGIN
    SELECT 
        TABLE_NAME,
        TABLE_ROWS,
        ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) AS size_mb,
        UPDATE_TIME
    FROM information_schema.TABLES
    WHERE TABLE_SCHEMA = DATABASE()
    ORDER BY (DATA_LENGTH + INDEX_LENGTH) DESC;
END //

CREATE PROCEDURE sp_identify_missing_indexes()
BEGIN
    SELECT 
        t.TABLE_NAME,
        COUNT(s.COLUMN_NAME) as columns_without_index
    FROM information_schema.TABLES t
    LEFT JOIN information_schema.COLUMNS s ON t.TABLE_NAME = s.TABLE_NAME
    LEFT JOIN information_schema.STATISTICS i ON s.TABLE_NAME = i.TABLE_NAME 
        AND s.COLUMN_NAME = i.COLUMN_NAME
    WHERE t.TABLE_SCHEMA = DATABASE()
        AND i.INDEX_NAME IS NULL
        AND s.COLUMN_KEY = ''
    GROUP BY t.TABLE_NAME
    HAVING COUNT(s.COLUMN_NAME) > 0;
END //

CREATE PROCEDURE sp_monitor_fragmentation()
BEGIN
    SELECT 
        TABLE_NAME,
        DATA_FREE/1024/1024 as fragmented_space_mb
    FROM information_schema.TABLES
    WHERE TABLE_SCHEMA = DATABASE()
        AND ENGINE='InnoDB'
        AND DATA_FREE > 0
    ORDER BY DATA_FREE DESC;
END //

CREATE PROCEDURE sp_analyze_query_patterns()
BEGIN
    INSERT INTO sys_query_statistics (
        id, query_pattern_id, query_text,
        execution_time_ms, rows_examined, rows_affected,
        full_scan_count, index_usage
    )
    SELECT 
        REPLACE(UUID(),'-',''),
        NULL,
        DIGEST_TEXT,
        AVG_TIMER_WAIT/1000000 as execution_time_ms,
        SUM_ROWS_EXAMINED,
        SUM_ROWS_AFFECTED,
        COUNT_STAR,
        JSON_OBJECT(
            'index_uses', INDEX_USES,
            'no_index_uses', NO_INDEX_USES
        )
    FROM performance_schema.events_statements_summary_by_digest
    WHERE LAST_SEEN >= DATE_SUB(NOW(), INTERVAL 1 HOUR);
END //

CREATE PROCEDURE sp_optimize_table_indexes(
    IN p_table_name VARCHAR(100)
)
BEGIN
    -- Analyze existing indexes
    ANALYZE TABLE p_table_name;
    
    -- Get index statistics
    SELECT 
        INDEX_NAME,
        CARDINALITY,
        NON_UNIQUE,
        COLUMN_NAME
    FROM information_schema.STATISTICS
    WHERE TABLE_NAME = p_table_name
    ORDER BY SEQ_IN_INDEX;
    
    -- Update index usage stats
    INSERT INTO sys_index_usage_stats (
        id, table_name, index_name, 
        used_count, last_used,
        avg_impact_percentage
    )
    SELECT 
        REPLACE(UUID(),'-',''),
        p_table_name,
        INDEX_NAME,
        0,
        NULL,
        0
    FROM information_schema.STATISTICS
    WHERE TABLE_NAME = p_table_name
    ON DUPLICATE KEY UPDATE
        updated_at = NOW();
END //

CREATE PROCEDURE sp_manage_partitions(
    IN p_table_name VARCHAR(100),
    IN p_partition_key VARCHAR(100),
    IN p_interval VARCHAR(20)
)
BEGIN
    -- Check if table exists and is partitioned
    IF EXISTS (
        SELECT 1 FROM information_schema.TABLES 
        WHERE TABLE_NAME = p_table_name 
        AND TABLE_TYPE = 'BASE TABLE'
    ) THEN
        -- Create partitioning if not exists
        SET @partition_sql = CONCAT(
            'ALTER TABLE ', p_table_name,
            ' PARTITION BY RANGE (', p_partition_key, ') (',
            CASE p_interval
                WHEN 'MONTHLY' THEN 
                    'PARTITION p_current VALUES LESS THAN (UNIX_TIMESTAMP(DATE_FORMAT(NOW(), "%Y-%m-01"))),',
                    'PARTITION p_next VALUES LESS THAN (UNIX_TIMESTAMP(DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 1 MONTH), "%Y-%m-01"))),',
                    'PARTITION p_future VALUES LESS THAN MAXVALUE'
                WHEN 'YEARLY' THEN
                    'PARTITION p_current VALUES LESS THAN (UNIX_TIMESTAMP(DATE_FORMAT(NOW(), "%Y-01-01"))),',
                    'PARTITION p_next VALUES LESS THAN (UNIX_TIMESTAMP(DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 1 YEAR), "%Y-01-01"))),',
                    'PARTITION p_future VALUES LESS THAN MAXVALUE'
                ELSE
                    'PARTITION p_future VALUES LESS THAN MAXVALUE'
            END,
            ')'
        );
        
        PREPARE stmt FROM @partition_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END //

CREATE PROCEDURE sp_analyze_deadlocks()
BEGIN
    SELECT 
        THREAD_ID,
        EVENT_ID,
        CURRENT_SCHEMA,
        CURRENT_TABLE,
        BLOCKING_THREAD_ID,
        BLOCKING_EVENT_ID,
        BLOCKING_SCHEMA,
        BLOCKING_TABLE
    FROM performance_schema.events_transactions_history_long
    WHERE TIMER_WAIT > 0
    AND STATE = 'COMMITTED'
    AND TIMER_WAIT > 1000000000000; -- Transactions taking more than 1 second
END //

CREATE PROCEDURE sp_create_sharded_table(
    IN p_table_name VARCHAR(100),
    IN p_shard_key VARCHAR(100),
    IN p_num_shards INT
)
BEGIN
    DECLARE i INT DEFAULT 0;
    
    -- Create sharding configuration
    INSERT INTO sys_sharding_config (
        id, table_name, shard_key, 
        shard_algorithm, num_shards,
        shard_distribution
    ) VALUES (
        REPLACE(UUID(),'-',''),
        p_table_name,
        p_shard_key,
        'hash',
        p_num_shards,
        JSON_OBJECT(
            'type', 'hash',
            'shards', JSON_ARRAY()
        )
    );
    
    -- Create shard tables
    WHILE i < p_num_shards DO
        SET @create_sql = CONCAT(
            'CREATE TABLE ', p_table_name, '_shard_', i,
            ' LIKE ', p_table_name
        );
        PREPARE stmt FROM @create_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
        
        -- Update shard distribution
        UPDATE sys_sharding_config
        SET shard_distribution = JSON_ARRAY_APPEND(
            shard_distribution,
            '$.shards',
            JSON_OBJECT(
                'shard_id', i,
                'table_name', CONCAT(p_table_name, '_shard_', i),
                'range_start', i * (4294967295 / p_num_shards),
                'range_end', (i + 1) * (4294967295 / p_num_shards) - 1
            )
        )
        WHERE table_name = p_table_name;
        
        SET i = i + 1;
    END WHILE;
END //

CREATE PROCEDURE sp_manage_table_partitions(
    IN p_table_name VARCHAR(100)
)
BEGIN
    DECLARE v_partition_exists INT;
    DECLARE v_next_partition_date DATE;
    
    -- Check if table is partitioned
    SELECT COUNT(*) INTO v_partition_exists
    FROM information_schema.PARTITIONS
    WHERE TABLE_NAME = p_table_name
    AND PARTITION_NAME IS NOT NULL;
    
    IF v_partition_exists > 0 THEN
        -- Get next partition date
        SET v_next_partition_date = DATE_ADD(CURRENT_DATE(), INTERVAL 1 MONTH);
        
        -- Create next month's partition if it doesn't exist
        SET @partition_sql = CONCAT(
            'ALTER TABLE ', p_table_name,
            ' ADD PARTITION (PARTITION p_',
            DATE_FORMAT(v_next_partition_date, '%Y%m'),
            ' VALUES LESS THAN (UNIX_TIMESTAMP("',
            DATE_FORMAT(DATE_ADD(v_next_partition_date, INTERVAL 1 MONTH), '%Y-%m-01'),
            '")))'
        );
        
        PREPARE stmt FROM @partition_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
        
        -- Drop old partitions (older than 12 months)
        SET @drop_sql = CONCAT(
            'ALTER TABLE ', p_table_name,
            ' DROP PARTITION p_',
            DATE_FORMAT(DATE_SUB(CURRENT_DATE(), INTERVAL 12 MONTH), '%Y%m')
        );
        
        PREPARE stmt FROM @drop_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END //

CREATE PROCEDURE sp_automated_maintenance()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_table_name VARCHAR(100);
    DECLARE cur CURSOR FOR 
        SELECT DISTINCT TABLE_NAME 
        FROM information_schema.PARTITIONS 
        WHERE TABLE_SCHEMA = DATABASE()
        AND PARTITION_NAME IS NOT NULL;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    -- Manage partitions for all partitioned tables
    OPEN cur;
    read_loop: LOOP
        FETCH cur INTO v_table_name;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        CALL sp_manage_table_partitions(v_table_name);
    END LOOP;
    CLOSE cur;
    
    -- Analyze and optimize tables
    CALL sp_analyze_table_growth();
    CALL sp_monitor_fragmentation();
    
    -- Update statistics
    ANALYZE TABLE sys_audit_logs, crm_activities, call_records UPDATE HISTOGRAM ON status;
END //

DELIMITER ;