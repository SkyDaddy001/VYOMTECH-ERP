-- Migration: Add accounting indexes for performance
-- Description: Creates indexes to optimize accounting queries and reports

-- Transaction date index for efficient date range queries
CREATE INDEX IF NOT EXISTS idx_transactions_date 
ON transactions(company_id, transaction_date DESC);

-- Transaction details index for efficient balance calculations
CREATE INDEX IF NOT EXISTS idx_transaction_details_ledger 
ON transaction_details(ledger_id);

-- Compound index for transaction listing with ledger filter
CREATE INDEX IF NOT EXISTS idx_transaction_details_composite
ON transaction_details(transaction_id, ledger_id);

-- Index for company member lookups (auth checks)
CREATE INDEX IF NOT EXISTS idx_company_members_lookup
ON company_members(company_id, user_id);

-- Specific index for trial balance queries
CREATE INDEX IF NOT EXISTS idx_ledgers_company
ON ledgers(company_id);

-- Add tags column and GIN index for ledger categories if used
DO $$
BEGIN
  -- Add tags column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'ledgers' AND column_name = 'tags'
  ) THEN
    ALTER TABLE ledgers ADD COLUMN tags JSONB;
    
    -- Create the GIN index
    CREATE INDEX IF NOT EXISTS idx_ledgers_tags
    ON ledgers USING GIN (tags jsonb_path_ops)
    WHERE tags IS NOT NULL;
  END IF;
END $$;

-- Add status column and fiscal year index for active companies
DO $$
BEGIN
  -- Add status column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'companies' AND column_name = 'status'
  ) THEN
    ALTER TABLE companies 
    ADD COLUMN status TEXT DEFAULT 'active' 
    CHECK (status IN ('active', 'inactive', 'suspended'));

    -- Update existing records to 'active'
    UPDATE companies SET status = 'active';
  END IF;

  -- Add fiscal year columns if they don't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'companies' AND column_name = 'fiscal_year_start'
  ) THEN
    ALTER TABLE companies 
    ADD COLUMN fiscal_year_start DATE,
    ADD COLUMN fiscal_year_end DATE;
  END IF;

  -- Create the index
  CREATE INDEX IF NOT EXISTS idx_companies_active_fy
  ON companies(fiscal_year_start, fiscal_year_end)
  WHERE status = 'active';
END $$;

-- Add GST type and index for GST related queries
DO $$
BEGIN
  -- Add gst_type column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'transactions' AND column_name = 'gst_type'
  ) THEN
    ALTER TABLE transactions 
    ADD COLUMN gst_type TEXT 
    CHECK (gst_type IN ('IGST', 'CGST_SGST', 'exempt', 'zero_rated', 'nil_rated'));
  END IF;

  -- Create the index
  CREATE INDEX IF NOT EXISTS idx_transactions_gst
  ON transactions(company_id, gst_type)
  WHERE gst_type IS NOT NULL;
END $$;

-- Ensure updated_at is maintained
CREATE OR REPLACE FUNCTION trigger_set_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply updated_at trigger to relevant tables
DO $$ 
BEGIN
  -- Transactions table
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'set_timestamp_transactions'
  ) THEN
    CREATE TRIGGER set_timestamp_transactions
    BEFORE UPDATE ON transactions
    FOR EACH ROW
    EXECUTE FUNCTION trigger_set_timestamp();
  END IF;

  -- Transaction details table
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'set_timestamp_transaction_details'
  ) THEN
    CREATE TRIGGER set_timestamp_transaction_details
    BEFORE UPDATE ON transaction_details
    FOR EACH ROW
    EXECUTE FUNCTION trigger_set_timestamp();
  END IF;

  -- Ledgers table
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'set_timestamp_ledgers'
  ) THEN
    CREATE TRIGGER set_timestamp_ledgers
    BEFORE UPDATE ON ledgers
    FOR EACH ROW
    EXECUTE FUNCTION trigger_set_timestamp();
  END IF;
END $$;