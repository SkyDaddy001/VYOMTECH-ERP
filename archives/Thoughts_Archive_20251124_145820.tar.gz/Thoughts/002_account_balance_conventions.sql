-- Standardize account balance conventions and add enhanced RLS policies
-- This script implements debit-positive/credit-negative convention with separate tracking

-- Add balance convention columns to ledgers
ALTER TABLE ledgers ADD COLUMN IF NOT EXISTS balance_convention TEXT DEFAULT 'debit-positive' CHECK (balance_convention IN ('debit-positive', 'separate'));
ALTER TABLE ledgers ADD COLUMN IF NOT EXISTS debit_total DECIMAL(15, 2) DEFAULT 0;
ALTER TABLE ledgers ADD COLUMN IF NOT EXISTS credit_total DECIMAL(15, 2) DEFAULT 0;

-- Create audit_log table for transaction tracking
CREATE TABLE IF NOT EXISTS audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  table_name TEXT NOT NULL,
  record_id UUID NOT NULL,
  action TEXT NOT NULL CHECK (action IN ('INSERT', 'UPDATE', 'DELETE')),
  old_values JSONB,
  new_values JSONB,
  changed_by UUID REFERENCES auth.users(id),
  changed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  ip_address TEXT,
  user_agent TEXT
);

-- Create financial_statements table for cached reports
CREATE TABLE IF NOT EXISTS financial_statements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  statement_type TEXT NOT NULL CHECK (statement_type IN ('trial_balance', 'profit_loss', 'balance_sheet', 'cash_flow')),
  statement_date DATE NOT NULL,
  statement_data JSONB NOT NULL,
  generated_by UUID REFERENCES auth.users(id),
  generated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(company_id, statement_type, statement_date)
);

-- Create tds_records table for TDS compliance
CREATE TABLE IF NOT EXISTS tds_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  transaction_id UUID REFERENCES transactions(id) ON DELETE CASCADE,
  tds_section TEXT NOT NULL,
  payee_name TEXT NOT NULL,
  payee_pan TEXT,
  tds_rate DECIMAL(5, 2) NOT NULL,
  transaction_amount DECIMAL(15, 2) NOT NULL,
  tds_amount DECIMAL(15, 2) NOT NULL,
  payment_date DATE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create e_invoice_records table for GST e-invoice compliance
CREATE TABLE IF NOT EXISTS e_invoice_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  transaction_id UUID REFERENCES transactions(id) ON DELETE CASCADE,
  irn TEXT UNIQUE,
  ack_number TEXT,
  ack_date TIMESTAMP WITH TIME ZONE,
  qr_code TEXT,
  e_invoice_json JSONB,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'generated', 'cancelled', 'failed')),
  error_message TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create e_way_bill_records table for e-way bill compliance
CREATE TABLE IF NOT EXISTS e_way_bill_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  transaction_id UUID REFERENCES transactions(id) ON DELETE CASCADE,
  ewb_number TEXT UNIQUE,
  irn TEXT REFERENCES e_invoice_records(irn),
  vehicle_number TEXT,
  transporter_id TEXT,
  from_location TEXT,
  to_location TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'generated', 'cancelled', 'expired')),
  valid_from TIMESTAMP WITH TIME ZONE,
  valid_till TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on new tables
ALTER TABLE audit_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE financial_statements ENABLE ROW LEVEL SECURITY;
ALTER TABLE tds_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE e_invoice_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE e_way_bill_records ENABLE ROW LEVEL SECURITY;

-- RLS Policies for audit_log
CREATE POLICY "audit_logs_select" ON audit_log FOR SELECT USING (
  EXISTS (SELECT 1 FROM company_members WHERE company_members.company_id = audit_logs.company_id AND company_members.user_id = auth.uid() AND company_members.role IN ('admin', 'accountant'))
  OR EXISTS (SELECT 1 FROM companies WHERE companies.id = audit_logs.company_id AND companies.owner_id = auth.uid())
);

-- RLS Policies for financial_statements
CREATE POLICY "financial_statements_select" ON financial_statements FOR SELECT USING (
  EXISTS (SELECT 1 FROM company_members WHERE company_members.company_id = financial_statements.company_id AND company_members.user_id = auth.uid())
  OR EXISTS (SELECT 1 FROM companies WHERE companies.id = financial_statements.company_id AND companies.owner_id = auth.uid())
);

CREATE POLICY "financial_statements_insert" ON financial_statements FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM company_members WHERE company_members.company_id = financial_statements.company_id AND company_members.user_id = auth.uid() AND company_members.role IN ('admin', 'accountant'))
  OR EXISTS (SELECT 1 FROM companies WHERE companies.id = financial_statements.company_id AND companies.owner_id = auth.uid())
);

-- RLS Policies for tds_records
CREATE POLICY "tds_records_select" ON tds_records FOR SELECT USING (
  EXISTS (SELECT 1 FROM company_members WHERE company_members.company_id = tds_records.company_id AND company_members.user_id = auth.uid())
  OR EXISTS (SELECT 1 FROM companies WHERE companies.id = tds_records.company_id AND companies.owner_id = auth.uid())
);

CREATE POLICY "tds_records_insert" ON tds_records FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM company_members WHERE company_members.company_id = tds_records.company_id AND company_members.user_id = auth.uid() AND company_members.role IN ('admin', 'accountant'))
  OR EXISTS (SELECT 1 FROM companies WHERE companies.id = tds_records.company_id AND companies.owner_id = auth.uid())
);

-- RLS Policies for e_invoice_records
CREATE POLICY "e_invoice_records_select" ON e_invoice_records FOR SELECT USING (
  EXISTS (SELECT 1 FROM company_members WHERE company_members.company_id = e_invoice_records.company_id AND company_members.user_id = auth.uid())
  OR EXISTS (SELECT 1 FROM companies WHERE companies.id = e_invoice_records.company_id AND companies.owner_id = auth.uid())
);

CREATE POLICY "e_invoice_records_insert" ON e_invoice_records FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM company_members WHERE company_members.company_id = e_invoice_records.company_id AND company_members.user_id = auth.uid() AND company_members.role IN ('admin', 'accountant'))
  OR EXISTS (SELECT 1 FROM companies WHERE companies.id = e_invoice_records.company_id AND companies.owner_id = auth.uid())
);

-- RLS Policies for e_way_bill_records
CREATE POLICY "e_way_bill_records_select" ON e_way_bill_records FOR SELECT USING (
  EXISTS (SELECT 1 FROM company_members WHERE company_members.company_id = e_way_bill_records.company_id AND company_members.user_id = auth.uid())
  OR EXISTS (SELECT 1 FROM companies WHERE companies.id = e_way_bill_records.company_id AND companies.owner_id = auth.uid())
);

CREATE POLICY "e_way_bill_records_insert" ON e_way_bill_records FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM company_members WHERE company_members.company_id = e_way_bill_records.company_id AND company_members.user_id = auth.uid() AND company_members.role IN ('admin', 'accountant', 'sales_manager'))
  OR EXISTS (SELECT 1 FROM companies WHERE companies.id = e_way_bill_records.company_id AND companies.owner_id = auth.uid())
);

-- Create indexes for performance
CREATE INDEX idx_audit_logs_company_id ON audit_logs(company_id);
CREATE INDEX idx_audit_logs_table_name ON audit_logs(table_name);
CREATE INDEX idx_audit_logs_changed_at ON audit_logs(changed_at);
CREATE INDEX idx_financial_statements_company_id ON financial_statements(company_id);
CREATE INDEX idx_financial_statements_date ON financial_statements(statement_date);
CREATE INDEX idx_tds_records_company_id ON tds_records(company_id);
CREATE INDEX idx_tds_records_payment_date ON tds_records(payment_date);
CREATE INDEX idx_e_invoice_records_company_id ON e_invoice_records(company_id);
CREATE INDEX idx_e_invoice_records_irn ON e_invoice_records(irn);
CREATE INDEX idx_e_way_bill_records_company_id ON e_way_bill_records(company_id);
CREATE INDEX idx_e_way_bill_records_ewb_number ON e_way_bill_records(ewb_number);
