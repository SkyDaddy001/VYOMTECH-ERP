-- Function to create company schema
CREATE OR REPLACE FUNCTION create_company_schema(company_name TEXT, company_id UUID)
RETURNS VOID AS $$
DECLARE
    schema_name TEXT;
BEGIN
    -- Create schema name: comp_{company_name} (lowercase, replace spaces with underscores)
    schema_name := 'comp_' || lower(replace(company_name, ' ', '_'));

    -- Create the schema if it doesn't exist
    EXECUTE 'CREATE SCHEMA IF NOT EXISTS ' || quote_ident(schema_name);

    -- Set search path to include the new schema
    EXECUTE 'SET LOCAL search_path TO ' || quote_ident(schema_name) || ', public, auth';

    -- Create company-specific tables in the new schema

    -- Ledger Groups
    EXECUTE '
    CREATE TABLE IF NOT EXISTS ' || quote_ident(schema_name) || '.ledger_groups (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      name TEXT NOT NULL,
      type TEXT NOT NULL CHECK (type IN (''asset'', ''liability'', ''equity'', ''income'', ''expense'')),
      description TEXT,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    )';

    -- Ledgers
    EXECUTE '
    CREATE TABLE IF NOT EXISTS ' || quote_ident(schema_name) || '.ledgers (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      ledger_group_id UUID NOT NULL REFERENCES ' || quote_ident(schema_name) || '.ledger_groups(id) ON DELETE CASCADE,
      code TEXT NOT NULL,
      name TEXT NOT NULL,
      description TEXT,
      opening_balance DECIMAL(15, 2) DEFAULT 0,
      current_balance DECIMAL(15, 2) DEFAULT 0,
      is_active BOOLEAN DEFAULT TRUE,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
      UNIQUE(code)
    )';

    -- Transactions
    EXECUTE '
    CREATE TABLE IF NOT EXISTS ' || quote_ident(schema_name) || '.transactions (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      voucher_number TEXT NOT NULL,
      voucher_type TEXT NOT NULL CHECK (voucher_type IN (''journal'', ''payment'', ''receipt'', ''contra'')),
      transaction_date DATE NOT NULL,
      description TEXT,
      reference_number TEXT,
      total_debit DECIMAL(15, 2) DEFAULT 0,
      total_credit DECIMAL(15, 2) DEFAULT 0,
      status TEXT DEFAULT ''draft'' CHECK (status IN (''draft'', ''posted'', ''cancelled'')),
      created_by UUID REFERENCES auth.users(id),
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
      UNIQUE(voucher_number)
    )';

    -- Transaction Details
    EXECUTE '
    CREATE TABLE IF NOT EXISTS ' || quote_ident(schema_name) || '.transaction_details (
