-- Advanced Analytics & BI Dashboard Schema
-- Manages dashboards, KPIs, and business intelligence features

CREATE TABLE IF NOT EXISTS dashboards (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  dashboard_type VARCHAR(50), -- 'executive', 'operational', 'financial', 'sales', 'inventory'
  layout JSONB, -- Dashboard grid layout configuration
  is_public BOOLEAN DEFAULT FALSE,
  is_default BOOLEAN DEFAULT FALSE,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(company_id, name)
);

CREATE TABLE IF NOT EXISTS dashboard_widgets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  dashboard_id UUID NOT NULL REFERENCES dashboards(id) ON DELETE CASCADE,
  widget_type VARCHAR(50), -- 'kpi', 'chart', 'table', 'gauge', 'heatmap'
  title VARCHAR(255),
  description TEXT,
  data_source JSONB, -- Query or data source configuration
  visualization_config JSONB, -- Chart/widget specific config
  position_x INTEGER,
  position_y INTEGER,
  width INTEGER,
  height INTEGER,
  refresh_interval_seconds INTEGER DEFAULT 300,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS kpis (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  kpi_type VARCHAR(50), -- 'revenue', 'profit', 'growth', 'efficiency', 'quality'
  calculation_method JSONB, -- How to calculate the KPI
  target_value DECIMAL(15, 2),
  current_value DECIMAL(15, 2),
  previous_value DECIMAL(15, 2),
  unit VARCHAR(50), -- '%', '$', 'units', etc.
  threshold_good DECIMAL(15, 2),
  threshold_warning DECIMAL(15, 2),
  threshold_critical DECIMAL(15, 2),
  status VARCHAR(20), -- 'good', 'warning', 'critical'
  last_calculated_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(company_id, name)
);

CREATE TABLE IF NOT EXISTS kpi_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  kpi_id UUID NOT NULL REFERENCES kpis(id) ON DELETE CASCADE,
  value DECIMAL(15, 2),
  recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  period_start DATE,
  period_end DATE
);

CREATE TABLE IF NOT EXISTS analytics_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  event_type VARCHAR(100), -- 'transaction_created', 'order_completed', 'payment_received'
  entity_type VARCHAR(50), -- 'transaction', 'order', 'payment'
  entity_id UUID,
  event_data JSONB,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cohort_analysis (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  cohort_name VARCHAR(255),
  cohort_date DATE,
  cohort_size INTEGER,
  retention_data JSONB, -- Retention by period
  revenue_data JSONB, -- Revenue by period
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS predictive_models (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  model_name VARCHAR(255),
  model_type VARCHAR(50), -- 'churn_prediction', 'revenue_forecast', 'customer_lifetime_value'
  training_data_size INTEGER,
  accuracy DECIMAL(5, 2),
  last_trained_at TIMESTAMP,
  model_config JSONB,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS predictions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  model_id UUID NOT NULL REFERENCES predictive_models(id) ON DELETE CASCADE,
  entity_type VARCHAR(50), -- 'customer', 'order', 'product'
  entity_id UUID,
  prediction_value DECIMAL(15, 2),
  confidence_score DECIMAL(5, 2),
  prediction_date DATE,
  actual_value DECIMAL(15, 2),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_dashboards_company ON dashboards(company_id);
CREATE INDEX idx_dashboard_widgets_dashboard ON dashboard_widgets(dashboard_id);
CREATE INDEX idx_kpis_company ON kpis(company_id);
CREATE INDEX idx_kpi_history_kpi ON kpi_history(kpi_id);
CREATE INDEX idx_analytics_events_company ON analytics_events(company_id);
CREATE INDEX idx_analytics_events_created_at ON analytics_events(created_at);
CREATE INDEX idx_predictive_models_company ON predictive_models(company_id);
CREATE INDEX idx_predictions_model ON predictions(model_id);

ALTER TABLE dashboards ENABLE ROW LEVEL SECURITY;
ALTER TABLE dashboard_widgets ENABLE ROW LEVEL SECURITY;
ALTER TABLE kpis ENABLE ROW LEVEL SECURITY;
ALTER TABLE analytics_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view dashboards in their company"
  ON dashboards FOR SELECT
  USING (company_id IN (SELECT company_id FROM company_members WHERE user_id = auth.uid()));

CREATE POLICY "Users can create dashboards in their company"
  ON dashboards FOR INSERT
  WITH CHECK (company_id IN (SELECT company_id FROM company_members WHERE user_id = auth.uid()));

CREATE POLICY "Users can view KPIs in their company"
  ON kpis FOR SELECT
  USING (company_id IN (SELECT company_id FROM company_members WHERE user_id = auth.uid()));

CREATE POLICY "Users can view analytics events in their company"
  ON analytics_events FOR SELECT
  USING (company_id IN (SELECT company_id FROM company_members WHERE user_id = auth.uid()));
