e ## 🧾 1. Accounting & Financial Management

> **Purpose:** Core double-entry bookkeeping, ledgers, and financial statements.

**Key Features:**

* Multi-company accounting
* Multi-currency transactions
* Chart of accounts with group/sub-group structure
* Cost centres & profit centres
* Budgeting & variance analysis
* Scenario management (Forecast/Actual/What-if)
* Contra, Journal, Payment, Receipt, and Sales/Purchase vouchers
* Day book, cash book, and bank book
* Auto interest calculation on outstanding balances
* Group-wise, ledger-wise, and cost-centre-wise reports
* Fund flow / cash flow statements
* Balance Sheet, Profit & Loss, and Trial Balance (real time)
* Consolidation of group companies

---

## 📦 2. Inventory & Stock Management

> **Purpose:** To manage stock, warehouses, and material movements.

**Key Features:**

* Multi-location (Godown/Warehouse) management
* Stock item categorisation, stock groups, units of measure
* Batch-wise, lot-wise, and expiry date tracking
* Item-wise reorder level & stock ageing reports
* Stock valuation methods (FIFO, LIFO, Average Cost, Std. Cost)
* Inventory vouchers (Goods Receipt, Delivery Note, Stock Journal, Physical Stock)
* Negative stock control and tracking
* BOM (Bill of Material) for manufacturing setups
* Item-wise profitability & consumption reports
* Movement analysis (material in/out, top items, slow movers)

---

## 🏭 3. Manufacturing & Job Work

> **Purpose:** Control over production, job costing, and subcontracting.

**Key Features:**

* Bill of Material (BOM) definition per finished good
* Production and consumption entries (Stock Journal/Job Work)
* Job costing and job work tracking (inward & outward)
* Multiple stage/process manufacturing
* Wastage and by-product tracking
* Material issue & receipt tracking for job workers
* Job cost sheets, variance and profitability analysis

---

## 🧑‍💼 4. Payroll & HR Management

> **Purpose:** Manage employee data, attendance, payroll, and compliance.

**Key Features:**

* Employee master & group configuration
* Pay heads and salary structure creation
* Attendance & leave management
* Payroll processing with salary slips
* Auto calculation of deductions (PF, ESI, PT, TDS, Loans)
* Employer’s statutory contributions tracking
* Employee loan & advance management
* Payslip, pay sheet, and pay register reports
* Full integration with accounting ledgers

---

## 💰 5. Statutory & Taxation (India-Ready)

> **Purpose:** Compliance for GST, TDS, TCS, Excise, and more.

**Key Features:**

* GST (Central, State, UT) enabled invoicing
* Automatic GST return computation (GSTR-1, 3B, 9, etc.)
* HSN/SAC codes and multi-rate support
* E-Invoice and E-Way Bill generation (with portal integration)
* TDS, TCS configuration with section-wise rates
* Auto TDS deduction in vouchers
* Service Tax, VAT, Excise (legacy support for older data)
* Payroll-related statutory returns (PF, ESI, PT, etc.)
* Tax Audit report generation

---

## 🏦 6. Banking & Financial Utilities

> **Purpose:** Bank reconciliation, payments, and collections automation.

**Key Features:**

* Cheque printing (customisable templates)
* Bank reconciliation (manual / auto-import from Excel/CSV)
* Post-dated cheque management
* Electronic fund transfer (NEFT/RTGS) support
* Payment advice printing/emailing
* Bank ledger interest & charge accounting
* Deposit/withdrawal vouchers linked to accounts
* Bank overview dashboards

---

## 🧑‍🤝‍🧑 7. Multi-User, Multi-Location, Remote Access

> **Purpose:** Enterprise-level access and collaboration.

**Key Features:**

* Multi-user access (Tally.ERP 9 Gold or TallyPrime Gold)
* Role-based access & user permissions
* Audit trail & activity log
* Remote access to company data (Tally.NET)
* Data synchronisation between branches/locations
* Support for offline work and later sync
* Group company consolidation & reporting

---

## 🔐 8. Security, Audit & Administration

> **Purpose:** Control, compliance, and system protection.

**Key Features:**

* TallyVault encryption (AES 256-bit)
* User role & access control (admin/operator/data entry)
* Password policies & expiry
* Audit trail (user activity log)
* Data backup & restore (manual / scheduled)
* Tally Audit tools for chartered accountants
* Company-level and voucher-level approvals

---

## 📊 9. Reports, MIS & Business Intelligence

> **Purpose:** Real-time decision support with drill-down data.

**Key Features:**

* Balance sheet, P&L, cash flow, ratio analysis
* Cost centre & job-wise profitability reports
* Stock summary, ageing, and movement analysis
* Collection, payment, outstanding reports
* Budget vs actual, variance analysis
* Customisable MIS dashboards
* Drill-down to voucher level from any report
* Export to Excel, PDF, or HTML

---

## ⚙️ 10. Customization & Extensions

> **Purpose:** Adaptation to business-specific workflows.

**Key Features:**

* TDL (Tally Definition Language) support
* Add-on modules (industry-specific)
* API integration (via ODBC/ODBC bridge, XML, or JSON in TallyPrime)
* Custom invoice templates, reports, and automation scripts
* Third-party connectors for CRM, ERP, POS, etc.

---

## 🌐 11. Connectivity & Integration

> **Purpose:** Connect with digital platforms and e-governance systems.

**Key Features:**

* E-Invoice & E-Way bill portal integration
* Direct Excel import/export for ledgers & vouchers
* Data import/export in XML/JSON/CSV
* Integration with payroll & attendance systems
* Remote audit by CAs via Tally.NET

---

## 🧮 12. Support for Multiple Business Types

> **Built-in configurations for:**

* Trading & Distribution
* Manufacturing & Processing
* Service Providers
* Construction & Real Estate
* Retail / POS
* Educational / NGO Accounting

---
-- Backup, Audit Trails & Retention Policies Configuration

-- Create backup_metadata table to track backups
CREATE TABLE IF NOT EXISTS backup_metadata (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  backup_name TEXT NOT NULL,
  backup_type TEXT NOT NULL CHECK (backup_type IN ('full', 'incremental', 'transaction')),
  backup_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  backup_size_bytes BIGINT,
  status TEXT DEFAULT 'completed' CHECK (status IN ('pending', 'in_progress', 'completed', 'failed')),
  retention_until TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create retention_policies table
CREATE TABLE IF NOT EXISTS retention_policies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  table_name TEXT NOT NULL,
  retention_days INTEGER NOT NULL,
  policy_type TEXT NOT NULL CHECK (policy_type IN ('archive', 'delete', 'anonymize')),
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(company_id, table_name)
);

-- Create audit_trail_archive table for long-term audit storage
CREATE TABLE IF NOT EXISTS audit_trail_archive (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  audit_log_id UUID REFERENCES audit_log(id) ON DELETE SET NULL,
  table_name TEXT NOT NULL,
  record_id UUID NOT NULL,
  action TEXT NOT NULL,
  old_values JSONB,
  new_values JSONB,
  changed_by UUID REFERENCES auth.users(id),
  changed_at TIMESTAMP WITH TIME ZONE NOT NULL,
  ip_address TEXT,
  user_agent TEXT,
  archived_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create data_export_logs table for compliance tracking
CREATE TABLE IF NOT EXISTS data_export_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  export_type TEXT NOT NULL CHECK (export_type IN ('trial_balance', 'profit_loss', 'balance_sheet', 'gstr3b', 'tds_summary', 'full_export')),
  exported_by UUID REFERENCES auth.users(id),
  export_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  record_count INTEGER,
  file_format TEXT,
  file_size_bytes BIGINT,
  export_reason TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on new tables
ALTER TABLE backup_metadata ENABLE ROW LEVEL SECURITY;
ALTER TABLE retention_policies ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_trail_archive ENABLE ROW LEVEL SECURITY;
ALTER TABLE data_export_logs ENABLE ROW LEVEL SECURITY;

-- RLS Policies for backup_metadata
CREATE POLICY "backup_metadata_select" ON backup_metadata FOR SELECT USING (
  EXISTS (SELECT 1 FROM company_members WHERE company_members.company_id = backup_metadata.company_id AND company_members.user_id = auth.uid() AND company_members.role = 'admin')
  OR EXISTS (SELECT 1 FROM companies WHERE companies.id = backup_metadata.company_id AND companies.owner_id = auth.uid())
);

CREATE POLICY "backup_metadata_insert" ON backup_metadata FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM companies WHERE companies.id = backup_metadata.company_id AND companies.owner_id = auth.uid())
);

-- RLS Policies for retention_policies
CREATE POLICY "retention_policies_select" ON retention_policies FOR SELECT USING (
  EXISTS (SELECT 1 FROM company_members WHERE company_members.company_id = retention_policies.company_id AND company_members.user_id = auth.uid() AND company_members.role = 'admin')
  OR EXISTS (SELECT 1 FROM companies WHERE companies.id = retention_policies.company_id AND companies.owner_id = auth.uid())
);

CREATE POLICY "retention_policies_insert" ON retention_policies FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM companies WHERE companies.id = retention_policies.company_id AND companies.owner_id = auth.uid())
);

CREATE POLICY "retention_policies_update" ON retention_policies FOR UPDATE USING (
  EXISTS (SELECT 1 FROM companies WHERE companies.id = retention_policies.company_id AND companies.owner_id = auth.uid())
);

-- RLS Policies for audit_trail_archive
CREATE POLICY "audit_trail_archive_select" ON audit_trail_archive FOR SELECT USING (
  EXISTS (SELECT 1 FROM company_members WHERE company_members.company_id = audit_trail_archive.company_id AND company_members.user_id = auth.uid() AND company_members.role IN ('admin', 'accountant'))
  OR EXISTS (SELECT 1 FROM companies WHERE companies.id = audit_trail_archive.company_id AND companies.owner_id = auth.uid())
);

CREATE POLICY "audit_trail_archive_insert" ON audit_trail_archive FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM companies WHERE companies.id = audit_trail_archive.company_id AND companies.owner_id = auth.uid())
);

-- RLS Policies for data_export_logs
CREATE POLICY "data_export_logs_select" ON data_export_logs FOR SELECT USING (
  EXISTS (SELECT 1 FROM company_members WHERE company_members.company_id = data_export_logs.company_id AND company_members.user_id = auth.uid())
  OR EXISTS (SELECT 1 FROM companies WHERE companies.id = data_export_logs.company_id AND companies.owner_id = auth.uid())
);

CREATE POLICY "data_export_logs_insert" ON data_export_logs FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM company_members WHERE company_members.company_id = data_export_logs.company_id AND company_members.user_id = auth.uid())
  OR EXISTS (SELECT 1 FROM companies WHERE companies.id = data_export_logs.company_id AND companies.owner_id = auth.uid())
);

-- Create indexes for performance
CREATE INDEX idx_backup_metadata_company_id ON backup_metadata(company_id);
CREATE INDEX idx_backup_metadata_backup_date ON backup_metadata(backup_date);
CREATE INDEX idx_retention_policies_company_id ON retention_policies(company_id);
CREATE INDEX idx_audit_trail_archive_company_id ON audit_trail_archive(company_id);
CREATE INDEX idx_audit_trail_archive_changed_at ON audit_trail_archive(changed_at);
CREATE INDEX idx_data_export_logs_company_id ON data_export_logs(company_id);
CREATE INDEX idx_data_export_logs_export_date ON data_export_logs(export_date);

-- Insert default retention policies for all existing companies.
-- Avoid using random UUIDs for company_id (would violate FK); insert one row per company per policy if missing.
INSERT INTO retention_policies (company_id, table_name, retention_days, policy_type)
SELECT c.id, t.table_name, t.retention_days, t.policy_type
FROM companies c
CROSS JOIN (VALUES
  ('transactions', 2555, 'archive'),
  ('transaction_details', 2555, 'archive'),
  ('gst_records', 2555, 'archive'),
  ('tds_records', 2555, 'archive'),
  ('audit_logs', 1825, 'archive'),
  ('e_invoice_records', 2555, 'archive'),
  ('e_way_bill_records', 365, 'delete')
) AS t(table_name, retention_days, policy_type)
WHERE NOT EXISTS (
  SELECT 1 FROM retention_policies rp WHERE rp.company_id = c.id AND rp.table_name = t.table_name
);

-- Create function to archive old audit logs
CREATE OR REPLACE FUNCTION archive_old_audit_logs()
RETURNS void AS $$
BEGIN
  INSERT INTO audit_trail_archive (
    company_id, audit_log_id, table_name, record_id, action,
    old_values, new_values, changed_by, changed_at, ip_address, user_agent
  )
  SELECT
    company_id, id, table_name, record_id, action,
    old_values, new_values, changed_by, changed_at, ip_address, user_agent
  FROM audit_log
  WHERE changed_at < NOW() - INTERVAL '90 days'
  AND id NOT IN (SELECT audit_log_id FROM audit_trail_archive WHERE audit_log_id IS NOT NULL);

  DELETE FROM audit_log
  WHERE changed_at < NOW() - INTERVAL '90 days';
END;
$$ LANGUAGE plpgsql;

-- Create function to enforce retention policies
CREATE OR REPLACE FUNCTION enforce_retention_policies()
RETURNS void AS $$
DECLARE
  policy RECORD;
BEGIN
  FOR policy IN SELECT * FROM retention_policies WHERE is_active = TRUE LOOP
    IF policy.policy_type = 'delete' THEN
      EXECUTE format(
        'DELETE FROM %I WHERE created_at < NOW() - INTERVAL ''%s days''',
        policy.table_name,
        policy.retention_days
      );
    ELSIF policy.policy_type = 'archive' THEN
      -- Archive logic would be implemented per table
      NULL;
    END IF;
  END LOOP;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to log all transaction changes
CREATE OR REPLACE FUNCTION log_transaction_changes()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO audit_log (
    company_id, table_name, record_id, action,
    old_values, new_values, changed_by, changed_at
  ) VALUES (
    NEW.company_id,
    'transactions',
    NEW.id,
    TG_OP,
    to_jsonb(OLD),
    to_jsonb(NEW),
    auth.uid(),
    NOW()
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER transaction_audit_trigger
AFTER INSERT OR UPDATE OR DELETE ON transactions
FOR EACH ROW
EXECUTE FUNCTION log_transaction_changes();

-- Create trigger to log all ledger changes
CREATE OR REPLACE FUNCTION log_ledger_changes()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO audit_log (
    company_id, table_name, record_id, action,
    old_values, new_values, changed_by, changed_at
  ) VALUES (
    NEW.company_id,
    'ledgers',
    NEW.id,
    TG_OP,
    to_jsonb(OLD),
    to_jsonb(NEW),
    auth.uid(),
    NOW()
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER ledger_audit_trigger
AFTER INSERT OR UPDATE OR DELETE ON ledgers
FOR EACH ROW
EXECUTE FUNCTION log_ledger_changes();
