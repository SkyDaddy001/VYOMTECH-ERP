-- 013_booking_details.sql
-- Add detailed booking/customer fields to the bookings table

ALTER TABLE IF EXISTS public.bookings
  ADD COLUMN IF NOT EXISTS customer_name text,
  ADD COLUMN IF NOT EXISTS status varchar(32),
  ADD COLUMN IF NOT EXISTS booking_date date,
  ADD COLUMN IF NOT EXISTS welcome_date date,
  ADD COLUMN IF NOT EXISTS allotment_date date,
  ADD COLUMN IF NOT EXISTS agreement_date date,
  ADD COLUMN IF NOT EXISTS registration_date date,
  ADD COLUMN IF NOT EXISTS handover_date date,
  ADD COLUMN IF NOT EXISTS rate_per_sqft numeric,
  ADD COLUMN IF NOT EXISTS composite_guideline_value numeric,
  ADD COLUMN IF NOT EXISTS car_parking_type varchar(64),
  -- Applicant details
  ADD COLUMN IF NOT EXISTS applicant_name varchar(255),
  ADD COLUMN IF NOT EXISTS applicant_number varchar(64),
  ADD COLUMN IF NOT EXISTS applicant_alt_number varchar(64),
  ADD COLUMN IF NOT EXISTS applicant_email varchar(255),
  ADD COLUMN IF NOT EXISTS applicant_comm_address text,
  ADD COLUMN IF NOT EXISTS applicant_perm_address text,
  ADD COLUMN IF NOT EXISTS applicant_aadhar varchar(32),
  ADD COLUMN IF NOT EXISTS applicant_pan varchar(32),
  ADD COLUMN IF NOT EXISTS applicant_care_of varchar(255),
  ADD COLUMN IF NOT EXISTS applicant_relation_to_co_applicant varchar(128),
  -- Co-applicant details
  ADD COLUMN IF NOT EXISTS co_applicant_name varchar(255),
  ADD COLUMN IF NOT EXISTS co_applicant_number varchar(64),
  ADD COLUMN IF NOT EXISTS co_applicant_alt_number varchar(64),
  ADD COLUMN IF NOT EXISTS co_applicant_email varchar(255),
  ADD COLUMN IF NOT EXISTS co_applicant_comm_address text,
  ADD COLUMN IF NOT EXISTS co_applicant_perm_address text,
  ADD COLUMN IF NOT EXISTS co_applicant_aadhar varchar(32),
  ADD COLUMN IF NOT EXISTS co_applicant_pan varchar(32),
  ADD COLUMN IF NOT EXISTS co_applicant_care_of varchar(255),
  ADD COLUMN IF NOT EXISTS co_applicant_relation_to_applicant varchar(128),
  -- PoA details
  ADD COLUMN IF NOT EXISTS poa_name varchar(255),
  ADD COLUMN IF NOT EXISTS poa_number varchar(64),
  ADD COLUMN IF NOT EXISTS poa_alt_number varchar(64),
  ADD COLUMN IF NOT EXISTS poa_email varchar(255),
  ADD COLUMN IF NOT EXISTS poa_comm_address text,
  ADD COLUMN IF NOT EXISTS poa_perm_address text,
  ADD COLUMN IF NOT EXISTS poa_aadhar varchar(32),
  ADD COLUMN IF NOT EXISTS poa_pan varchar(32),
  ADD COLUMN IF NOT EXISTS poa_care_of varchar(255),
  ADD COLUMN IF NOT EXISTS poa_relation_to_applicant varchar(128),
  ADD COLUMN IF NOT EXISTS poa_document_no varchar(128),
  ADD COLUMN IF NOT EXISTS life_certificate boolean DEFAULT false,
  -- Bank/loan details
  ADD COLUMN IF NOT EXISTS bank_name varchar(255),
  ADD COLUMN IF NOT EXISTS bank_contact_person varchar(255),
  ADD COLUMN IF NOT EXISTS bank_number varchar(64),
  ADD COLUMN IF NOT EXISTS loan_sanction_date date,
  ADD COLUMN IF NOT EXISTS connector_code_number varchar(128),
  ADD COLUMN IF NOT EXISTS sanction_amount numeric,
  -- Booking meta
  ADD COLUMN IF NOT EXISTS lead_id uuid REFERENCES public.leads(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS sales_executives text,
  ADD COLUMN IF NOT EXISTS sales_head varchar(255),
  ADD COLUMN IF NOT EXISTS booking_source varchar(255),
  ADD COLUMN IF NOT EXISTS allotted_to uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  -- Charges
  ADD COLUMN IF NOT EXISTS other_works numeric,
  ADD COLUMN IF NOT EXISTS maintenance numeric,
  ADD COLUMN IF NOT EXISTS corpus numeric,
  ADD COLUMN IF NOT EXISTS eb_deposit numeric,
  ADD COLUMN IF NOT EXISTS noc_received_date date;

-- Indexes for frequent lookups
CREATE INDEX IF NOT EXISTS idx_bookings_customer_name ON public.bookings (customer_name);
CREATE INDEX IF NOT EXISTS idx_bookings_booking_date ON public.bookings (booking_date);
CREATE INDEX IF NOT EXISTS idx_bookings_lead_id ON public.bookings (lead_id);

-- NOTE: If your environment uses RLS policies, ensure the policies permit reading/writing these columns for the intended roles.
