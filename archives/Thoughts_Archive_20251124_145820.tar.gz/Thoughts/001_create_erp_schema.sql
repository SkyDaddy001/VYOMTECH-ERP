-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Create auth schema for user management
CREATE SCHEMA IF NOT EXISTS auth;

-- Create auth.users table (simplified for local development)
CREATE TABLE IF NOT EXISTS auth.users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  raw_user_meta_data JSONB DEFAULT '{}',
  raw_app_meta_data JSONB DEFAULT '{}'
);

-- Create companies table in public schema (for multi-tenancy)
CREATE TABLE IF NOT EXISTS public.companies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('real_estate', 'general', 'manufacturing', 'retail')),
  owner_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  schema_name TEXT UNIQUE,
  gst_number TEXT,
  pan_number TEXT,
  address TEXT,
  city TEXT,
  state TEXT,
  country TEXT,
  postal_code TEXT,
  phone TEXT,
  email TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Function to create company schema
CREATE OR REPLACE FUNCTION create_company_schema(company_name TEXT)
RETURNS TEXT AS $$
DECLARE
  schema_name TEXT;
BEGIN
  -- Generate schema name: comp_{company_name}
  schema_name := 'comp_' || lower(regexp_replace(company_name, '[^a-zA-Z0-9]', '_', 'g'));

  -- Create schema if it doesn't exist
  EXECUTE 'CREATE SCHEMA IF NOT EXISTS ' || schema_name;

  -- Return the schema name
  RETURN schema_name;
END;
$$ LANGUAGE plpgsql;

-- Function to create company tables in the schema
CREATE OR REPLACE FUNCTION create_company_tables(schema_name TEXT)
RETURNS VOID AS $$
BEGIN
  -- Create accounting tables
  EXECUTE 'CREATE TABLE IF NOT EXISTS ' || schema_name || '.accounts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_number TEXT UNIQUE NOT NULL,
    account_name TEXT NOT NULL,
    account_type TEXT NOT NULL CHECK (account_type IN (''asset'', ''liability'', ''equity'', ''income'', ''expense'')),
    parent_account_id UUID REFERENCES ' || schema_name || '.accounts(id),
    balance DECIMAL(15,2) DEFAULT 0,
    currency_code TEXT DEFAULT ''INR'',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  )';

  EXECUTE 'CREATE TABLE IF NOT EXISTS ' || schema_name || '.transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    transaction_date DATE NOT NULL,
    description TEXT,
    reference_number TEXT,
    status VARCHAR(20) DEFAULT ''draft'',
    total_debit DECIMAL(15,2) DEFAULT 0,
    total_credit DECIMAL(15,2) DEFAULT 0,
    created_by UUID NOT NULL REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  )';

  EXECUTE 'CREATE TABLE IF NOT EXISTS ' || schema_name || '.transaction_details (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    transaction_id UUID REFERENCES ' || schema_name || '.transactions(id) ON DELETE CASCADE,
    account_id UUID REFERENCES ' || schema_name || '.accounts(id),
    debit DECIMAL(15,2) DEFAULT 0,
    credit DECIMAL(15,2) DEFAULT 0,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  )';

  -- Create inventory tables
  EXECUTE 'CREATE TABLE IF NOT EXISTS ' || schema_name || '.products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    sku TEXT UNIQUE,
    category TEXT,
    unit_price DECIMAL(10,2),
    stock_quantity INTEGER DEFAULT 0,
    reorder_level INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  )';

  -- Create sales tables
  EXECUTE 'CREATE TABLE IF NOT EXISTS ' || schema_name || '.customers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    address TEXT,
    gst_number TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  )';

  EXECUTE 'CREATE TABLE IF NOT EXISTS ' || schema_name || '.sales_orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_number TEXT UNIQUE NOT NULL,
    customer_id UUID REFERENCES ' || schema_name || '.customers(id),
    order_date DATE NOT NULL,
    total_amount DECIMAL(15,2) NOT NULL,
    status TEXT DEFAULT ''pending'' CHECK (status IN (''pending'', ''confirmed'', ''shipped'', ''delivered'', ''cancelled'')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  )';

  -- Create real estate tables (if applicable)
  EXECUTE 'CREATE TABLE IF NOT EXISTS ' || schema_name || '.properties (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    property_name TEXT NOT NULL,
    property_type TEXT NOT NULL CHECK (property_type IN (''residential'', ''commercial'', ''industrial'')),
    address TEXT,
    city TEXT,
    state TEXT,
    postal_code TEXT,
    total_area DECIMAL(10,2),
    built_up_area DECIMAL(10,2),
    status TEXT DEFAULT ''available'' CHECK (status IN (''available'', ''sold'', ''rented'', ''under_construction'')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  )';

  EXECUTE 'CREATE TABLE IF NOT EXISTS ' || schema_name || '.units (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    property_id UUID NOT NULL REFERENCES ' || schema_name || '.properties(id),
    unit_number TEXT NOT NULL,
    floor_number INTEGER,
    area DECIMAL(10,2),
    bedrooms INTEGER,
    bathrooms INTEGER,
    price DECIMAL(15,2),
    status TEXT DEFAULT ''available'' CHECK (status IN (''available'', ''sold'', ''rented'', ''reserved'')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  )';

  -- Create bookings table
  EXECUTE 'CREATE TABLE IF NOT EXISTS ' || schema_name || '.bookings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    unit_id UUID REFERENCES ' || schema_name || '.units(id),
    customer_id UUID REFERENCES ' || schema_name || '.customers(id),
    booking_date DATE NOT NULL,
    booking_amount DECIMAL(15,2) NOT NULL,
    total_amount DECIMAL(15,2) NOT NULL,
    status TEXT DEFAULT ''pending'' CHECK (status IN (''pending'', ''confirmed'', ''cancelled'')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  )';

  -- Create compliance tables
  EXECUTE 'CREATE TABLE IF NOT EXISTS ' || schema_name || '.e_invoices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_number TEXT UNIQUE NOT NULL,
    invoice_date DATE NOT NULL,
    customer_id UUID REFERENCES ' || schema_name || '.customers(id),
    total_amount DECIMAL(15,2) NOT NULL,
    gst_amount DECIMAL(15,2),
    irn TEXT,
    qr_code TEXT,
    status TEXT DEFAULT ''generated'' CHECK (status IN (''generated'', ''cancelled'')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  )';

  EXECUTE 'CREATE TABLE IF NOT EXISTS ' || schema_name || '.eway_bills (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    eway_bill_number TEXT UNIQUE NOT NULL,
    generation_date DATE NOT NULL,
    expiry_date DATE,
    from_address TEXT,
    to_address TEXT,
    distance INTEGER,
    vehicle_number TEXT,
    total_amount DECIMAL(15,2),
    status TEXT DEFAULT ''active'' CHECK (status IN (''active'', ''cancelled'', ''expired'')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  )';

  -- Create tax tables
  EXECUTE 'CREATE TABLE IF NOT EXISTS ' || schema_name || '.tds_entries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    section TEXT NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    rate DECIMAL(5,2) NOT NULL,
    tds_amount DECIMAL(15,2) NOT NULL,
    payment_date DATE NOT NULL,
    deductee_name TEXT,
    deductee_pan TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  )';

  -- Create reporting tables
  EXECUTE 'CREATE TABLE IF NOT EXISTS ' || schema_name || '.reports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    report_name TEXT NOT NULL,
    report_type TEXT NOT NULL,
    parameters JSONB,
    generated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    generated_by UUID REFERENCES auth.users(id),
    file_path TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  )';

  -- Create audit log
  EXECUTE 'CREATE TABLE IF NOT EXISTS ' || schema_name || '.audit_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    table_name TEXT NOT NULL,
    operation TEXT NOT NULL CHECK (operation IN (''INSERT'', ''UPDATE'', ''DELETE'')),
    old_values JSONB,
    new_values JSONB,
    user_id UUID REFERENCES auth.users(id),
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  )';

END;
$$ LANGUAGE plpgsql;

-- Trigger function to create schema and tables when a company is created
CREATE OR REPLACE FUNCTION on_company_created()
RETURNS TRIGGER AS $$
DECLARE
  generated_schema_name TEXT;
BEGIN
  -- Create schema for the company
  generated_schema_name := create_company_schema(NEW.name);

  -- Update the company record with the schema name
  UPDATE public.companies SET schema_name = generated_schema_name WHERE id = NEW.id;

  -- Create tables in the schema
  PERFORM create_company_tables(generated_schema_name);

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger on companies table
CREATE TRIGGER trigger_create_company_schema
  AFTER INSERT ON public.companies
  FOR EACH ROW
  EXECUTE FUNCTION on_company_created();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_companies_owner_id ON public.companies(owner_id);
CREATE INDEX IF NOT EXISTS idx_companies_type ON public.companies(type);
CREATE INDEX IF NOT EXISTS idx_companies_schema_name ON public.companies(schema_name);

-- Insert some sample data for testing
INSERT INTO auth.users (email, password_hash) VALUES
('admin@example.com', '$2a$10$example.hash.here'),
('user@example.com', '$2a$10$example.hash.here')
ON CONFLICT (email) DO NOTHING;

-- Insert sample company
INSERT INTO public.companies (name, type, owner_id) VALUES
('Sample Real Estate Company', 'real_estate', (SELECT id FROM auth.users WHERE email = 'admin@example.com' LIMIT 1))
ON CONFLICT DO NOTHING;
