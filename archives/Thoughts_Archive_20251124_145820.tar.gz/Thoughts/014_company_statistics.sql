-- Function to get member role counts
CREATE OR REPLACE FUNCTION get_member_role_counts(p_company_id UUID)
RETURNS TABLE (
  role TEXT,
  count BIGINT
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    cm.role,
    COUNT(*)::BIGINT
  FROM company_members cm
  WHERE cm.company_id = p_company_id
  GROUP BY cm.role;
END;
$$ LANGUAGE plpgsql;

-- Function to get transaction statistics
CREATE OR REPLACE FUNCTION get_transaction_stats(
  p_company_id UUID,
  p_start_date TIMESTAMP WITH TIME ZONE
) 
RETURNS TABLE (
  type TEXT,
  count BIGINT,
  sum DECIMAL
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    t.type,
    COUNT(*)::BIGINT as count,
    COALESCE(SUM(t.amount), 0)::DECIMAL as sum
  FROM transactions t
  WHERE 
    t.company_id = p_company_id
    AND t.created_at >= p_start_date
  GROUP BY t.type;
END;
$$ LANGUAGE plpgsql;