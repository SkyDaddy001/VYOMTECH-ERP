-- Advanced Reporting with Custom Queries
-- Adds support for custom report definitions and saved queries

CREATE TABLE IF NOT EXISTS report_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  report_type VARCHAR(50), -- 'custom', 'standard', 'compliance'
  query_definition JSONB NOT NULL, -- Stores query parameters and filters
  columns JSONB NOT NULL, -- Array of column definitions
  filters JSONB, -- Default filters
  grouping JSONB, -- Grouping configuration
  sorting JSONB, -- Sorting configuration
  is_public BOOLEAN DEFAULT FALSE,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(company_id, name)
);

CREATE TABLE IF NOT EXISTS saved_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  template_id UUID NOT NULL REFERENCES report_templates(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  parameters JSONB, -- Runtime parameters
  generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  generated_by UUID REFERENCES auth.users(id),
  file_path VARCHAR(500), -- Path to stored report file
  file_format VARCHAR(20), -- 'pdf', 'excel', 'csv', 'json'
  row_count INTEGER,
  execution_time_ms INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS report_schedules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  template_id UUID NOT NULL REFERENCES report_templates(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  frequency VARCHAR(50), -- 'daily', 'weekly', 'monthly', 'quarterly', 'yearly'
  day_of_week INTEGER, -- 0-6 for weekly
  day_of_month INTEGER, -- 1-31 for monthly
  time_of_day TIME,
  recipients TEXT[], -- Email addresses
  file_format VARCHAR(20),
  is_active BOOLEAN DEFAULT TRUE,
  last_run_at TIMESTAMP,
  next_run_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS query_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id),
  query_text TEXT,
  execution_time_ms INTEGER,
  row_count INTEGER,
  status VARCHAR(20), -- 'success', 'error'
  error_message TEXT,
  executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_report_templates_company ON report_templates(company_id);
CREATE INDEX idx_saved_reports_company ON saved_reports(company_id);
CREATE INDEX idx_saved_reports_template ON saved_reports(template_id);
CREATE INDEX idx_report_schedules_company ON report_schedules(company_id);
CREATE INDEX idx_query_logs_company ON query_logs(company_id);
CREATE INDEX idx_query_logs_executed_at ON query_logs(executed_at);

ALTER TABLE report_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE saved_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE report_schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE query_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view report templates in their company"
  ON report_templates FOR SELECT
  USING (company_id IN (SELECT company_id FROM company_members WHERE user_id = auth.uid()));

CREATE POLICY "Users can create report templates in their company"
  ON report_templates FOR INSERT
  WITH CHECK (company_id IN (SELECT company_id FROM company_members WHERE user_id = auth.uid() AND role IN ('admin', 'accountant')));

CREATE POLICY "Users can view saved reports in their company"
  ON saved_reports FOR SELECT
  USING (company_id IN (SELECT company_id FROM company_members WHERE user_id = auth.uid()));

CREATE POLICY "Users can view report schedules in their company"
  ON report_schedules FOR SELECT
  USING (company_id IN (SELECT company_id FROM company_members WHERE user_id = auth.uid()));

CREATE POLICY "Users can view query logs in their company"
  ON query_logs FOR SELECT
  USING (company_id IN (SELECT company_id FROM company_members WHERE user_id = auth.uid()));
