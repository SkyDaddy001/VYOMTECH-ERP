-- Initial database setup for schema isolation
-- This script sets up the basic schema structure before other migrations

-- Create public schema if it doesn't exist
CREATE SCHEMA IF NOT EXISTS public;

-- Set search path to include public
SET search_path TO public;

-- Create schema_migrations table in public schema
CREATE TABLE IF NOT EXISTS public.schema_migrations (
    version TEXT PRIMARY KEY,
    applied_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create auth schema
CREATE SCHEMA IF NOT EXISTS auth;

-- Grant necessary permissions
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA auth TO postgres;
