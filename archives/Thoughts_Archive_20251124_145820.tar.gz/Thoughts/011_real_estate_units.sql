-- 011_real_estate_units.sql
-- Create a dedicated table for real estate project units (apartments/plots)

CREATE TABLE IF NOT EXISTS public.real_estate_units (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid REFERENCES public.companies(id) ON DELETE CASCADE,
  project_id uuid REFERENCES public.projects(id) ON DELETE CASCADE,
  apt_no varchar(64) NOT NULL,
  floor varchar(64),
  unit_type varchar(128), -- e.g., 2BHK, Plot, Apartment, Penthouse
  facing varchar(64), -- e.g., North, South-East
  rera_carpet_area numeric, -- RERA carpet area
  rera_carpet_area_with_balcony numeric, -- RERA carpet area including balcony and utility (sq.ft.)
  plinth_area numeric,
  sbua numeric, -- Super built-up area
  uds_per_sqft numeric, -- UDS per sqft
  allotted_to uuid REFERENCES public.profiles(id), -- optional reference to profile/lead/user
  unit_key varchar(128), -- unique key/id allocated by project
  block varchar(64),
  status varchar(32) DEFAULT 'available', -- available | booked | sold | cancelled
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Indexes for common queries
CREATE INDEX IF NOT EXISTS idx_real_estate_units_project_id ON public.real_estate_units (project_id);
CREATE INDEX IF NOT EXISTS idx_real_estate_units_company_id ON public.real_estate_units (company_id);
CREATE INDEX IF NOT EXISTS idx_real_estate_units_apt_no ON public.real_estate_units (apt_no);

-- Trigger to update updated_at
CREATE OR REPLACE FUNCTION public.tr_real_estate_units_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS tr_real_estate_units_updated_at ON public.real_estate_units;
CREATE TRIGGER tr_real_estate_units_updated_at
BEFORE UPDATE ON public.real_estate_units
FOR EACH ROW
EXECUTE PROCEDURE public.tr_real_estate_units_updated_at();
