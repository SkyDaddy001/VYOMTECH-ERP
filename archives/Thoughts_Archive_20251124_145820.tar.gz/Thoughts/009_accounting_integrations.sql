-- Accounting Software Integration Schema
-- Manages integrations with QuickBooks, Xero, SAP, etc.

CREATE TABLE IF NOT EXISTS accounting_integrations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  integration_name VARCHAR(100), -- 'quickbooks', 'xero', 'sap', 'tally'
  api_key VARCHAR(500),
  api_secret VARCHAR(500),
  realm_id VARCHAR(100), -- For QuickBooks
  tenant_id VARCHAR(100), -- For Xero
  access_token VARCHAR(1000),
  refresh_token VARCHAR(1000),
  token_expires_at TIMESTAMP,
  is_active BOOLEAN DEFAULT TRUE,
  last_sync_at TIMESTAMP,
  sync_status VARCHAR(20), -- 'pending', 'syncing', 'success', 'error'
  error_message TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(company_id, integration_name)
);

CREATE TABLE IF NOT EXISTS sync_mappings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  integration_id UUID NOT NULL REFERENCES accounting_integrations(id) ON DELETE CASCADE,
  source_table VARCHAR(100), -- 'transactions', 'ledgers', 'customers'
  source_field VARCHAR(100),
  target_field VARCHAR(100),
  transformation_logic JSONB, -- Custom transformation rules
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sync_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  integration_id UUID NOT NULL REFERENCES accounting_integrations(id) ON DELETE CASCADE,
  sync_type VARCHAR(50), -- 'export', 'import', 'bidirectional'
  records_synced INTEGER,
  records_failed INTEGER,
  status VARCHAR(20), -- 'success', 'error', 'partial'
  error_details JSONB,
  started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  completed_at TIMESTAMP,
  execution_time_ms INTEGER
);

CREATE TABLE IF NOT EXISTS sync_conflicts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  integration_id UUID NOT NULL REFERENCES accounting_integrations(id) ON DELETE CASCADE,
  record_type VARCHAR(50),
  local_record_id UUID,
  remote_record_id VARCHAR(100),
  conflict_type VARCHAR(50), -- 'duplicate', 'mismatch', 'missing'
  local_data JSONB,
  remote_data JSONB,
  resolution VARCHAR(50), -- 'keep_local', 'keep_remote', 'merge'
  resolved_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS integration_audit_trail (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  integration_id UUID NOT NULL REFERENCES accounting_integrations(id) ON DELETE CASCADE,
  action VARCHAR(100), -- 'sync_started', 'record_exported', 'error_occurred'
  record_type VARCHAR(50),
  record_id VARCHAR(100),
  details JSONB,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_accounting_integrations_company ON accounting_integrations(company_id);
CREATE INDEX idx_sync_mappings_integration ON sync_mappings(integration_id);
CREATE INDEX idx_sync_logs_integration ON sync_logs(integration_id);
CREATE INDEX idx_sync_logs_started_at ON sync_logs(started_at);
CREATE INDEX idx_sync_conflicts_integration ON sync_conflicts(integration_id);
CREATE INDEX idx_integration_audit_trail_integration ON integration_audit_trail(integration_id);

ALTER TABLE accounting_integrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE sync_mappings ENABLE ROW LEVEL SECURITY;
ALTER TABLE sync_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE sync_conflicts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view accounting integrations in their company"
  ON accounting_integrations FOR SELECT
  USING (company_id IN (SELECT company_id FROM company_members WHERE user_id = auth.uid() AND role = 'admin'));

CREATE POLICY "Users can view sync mappings in their company"
  ON sync_mappings FOR SELECT
  USING (company_id IN (SELECT company_id FROM company_members WHERE user_id = auth.uid() AND role = 'admin'));

CREATE POLICY "Users can view sync logs in their company"
  ON sync_logs FOR SELECT
  USING (company_id IN (SELECT company_id FROM company_members WHERE user_id = auth.uid()));

CREATE POLICY "Users can view sync conflicts in their company"
  ON sync_conflicts FOR SELECT
  USING (company_id IN (SELECT company_id FROM company_members WHERE user_id = auth.uid() AND role = 'admin'));
