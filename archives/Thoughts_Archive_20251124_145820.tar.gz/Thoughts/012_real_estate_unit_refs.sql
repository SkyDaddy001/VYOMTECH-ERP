-- 012_real_estate_unit_refs.sql
-- Add project_unit_id (FK) columns and ledger mapping for real estate units

ALTER TABLE IF EXISTS public.bookings
  ADD COLUMN IF NOT EXISTS project_unit_id uuid REFERENCES public.real_estate_units(id) ON DELETE SET NULL;

ALTER TABLE IF EXISTS public.sales_orders
  ADD COLUMN IF NOT EXISTS project_unit_id uuid REFERENCES public.real_estate_units(id) ON DELETE SET NULL;

ALTER TABLE IF EXISTS public.payments
  ADD COLUMN IF NOT EXISTS project_unit_id uuid REFERENCES public.real_estate_units(id) ON DELETE SET NULL;

ALTER TABLE IF EXISTS public.transactions
  ADD COLUMN IF NOT EXISTS project_unit_id uuid REFERENCES public.real_estate_units(id) ON DELETE SET NULL;

-- Add optional ledger mapping to real_estate_units for sale posting
ALTER TABLE IF EXISTS public.real_estate_units
  ADD COLUMN IF NOT EXISTS sale_ledger_id uuid NULL;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_bookings_project_unit_id ON public.bookings (project_unit_id);
CREATE INDEX IF NOT EXISTS idx_sales_orders_project_unit_id ON public.sales_orders (project_unit_id);
CREATE INDEX IF NOT EXISTS idx_payments_project_unit_id ON public.payments (project_unit_id);
CREATE INDEX IF NOT EXISTS idx_transactions_project_unit_id ON public.transactions (project_unit_id);

-- Note: adjust RLS policies if needed to allow service role or session-based access to these columns.
