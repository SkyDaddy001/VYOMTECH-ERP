-- LEAD PIPELINE SCHEMA

-- Dependencies: shared_utilities.sql, shared_triggers_and_functions.sql, lead_management.sql

-- PIPELINE DEFINITIONS TABLE
CREATE TABLE pipelines (
    id TEXT PRIMARY KEY DEFAULT generate_ulid(),
    name VARCHAR(255) NOT NULL,
    description TEXT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- PIPELINE STAGES TABLE
CREATE TABLE pipeline_stages (
    id TEXT PRIMARY KEY DEFAULT generate_ulid(),
    pipeline_id TEXT REFERENCES pipelines(id) ON DELETE CASCADE,
    stage_name VARCHAR(255) NOT NULL,
    is_terminal BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- TRIGGERS
-- Trigger for updating `updated_at` column is defined in shared_triggers_and_functions.sql
