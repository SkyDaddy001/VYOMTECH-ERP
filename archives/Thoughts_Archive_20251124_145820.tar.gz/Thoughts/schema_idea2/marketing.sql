-- MARKETING SCHEMA

-- Dependencies: shared_utilities.sql, shared_triggers_and_functions.sql, user_management.sql

-- VENDORS TABLE
CREATE TABLE vendors (
    id TEXT PRIMARY KEY DEFAULT generate_ulid(),
    name VARCHAR(255) NOT NULL,
    contact_email VARCHAR(255) NOT NULL,
    contact_phone VARCHAR(20) NULL,
    api_key TEXT UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- CAMPAIGNS TABLE
CREATE TABLE campaigns (
    id TEXT PRIMARY KEY DEFAULT generate_ulid(),
    vendor_id TEXT REFERENCES vendors(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    platform VARCHAR(255) NOT NULL,
    budget DECIMAL(15, 2) NOT NULL,
    start_date TIMESTAMP NOT NULL,
    end_date TIMESTAMP NOT NULL,
    status VARCHAR(50) DEFAULT 'active',
    project_name VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- INDEXES FOR PERFORMANCE
CREATE INDEX idx_campaigns_vendor_id ON campaigns(vendor_id);

-- TRIGGERS
-- Trigger for updating `updated_at` column is defined in shared_triggers_and_functions.sql
