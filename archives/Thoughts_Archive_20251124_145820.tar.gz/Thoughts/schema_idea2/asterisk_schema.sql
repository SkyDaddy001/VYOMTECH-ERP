-- ASTERISK SCHEMA

-- Dependencies: shared_utilities.sql, shared_triggers_and_functions.sql, user_management.sql

-- EXTENSIONS TABLE
CREATE TABLE extensions (
    extension_id SERIAL PRIMARY KEY,
    user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
    extension_number VARCHAR(10) NOT NULL UNIQUE,
    context VARCHAR(50) DEFAULT 'default',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- CALL LOGS TABLE
CREATE TABLE call_logs (
    call_id SERIAL PRIMARY KEY,
    caller_extension VARCHAR(10) NOT NULL,
    receiver_extension VARCHAR(10) NOT NULL,
    call_start TIMESTAMP NOT NULL,
    call_end TIMESTAMP,
    status VARCHAR(20) NOT NULL CHECK (status IN ('completed', 'missed', 'failed')),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Add trigger for updating `updated_at`
CREATE TRIGGER trigger_update_call_logs_updated_at
BEFORE UPDATE ON call_logs
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();
