-- USER MANAGEMENT SCHEMA

-- Extensions and shared utilities must be loaded before this file
-- Dependencies: shared_utilities.sql, shared_triggers_and_functions.sql

-- USERS TABLE
-- Stores user information
CREATE TABLE users (
    id TEXT PRIMARY KEY DEFAULT generate_ulid(),
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    email_verified_at TIMESTAMP NULL DEFAULT NULL,
    password TEXT NOT NULL,
    remember_token TEXT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- JWT REFRESH TOKENS TABLE
-- Stores refresh tokens for JWT authentication
CREATE TABLE jwt_refresh_tokens (
    id TEXT PRIMARY KEY DEFAULT generate_ulid(),
    user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
    refresh_token TEXT NOT NULL UNIQUE,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

-- USERS TABLE OPTIMIZATION
-- Add constraints for email format and password length
ALTER TABLE users
    ADD CONSTRAINT chk_users_email_format CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'),
    ADD CONSTRAINT chk_users_password_length CHECK (LENGTH(password) >= 8);

-- TRIGGERS
-- Trigger for hashing passwords is defined in shared_triggers_and_functions.sql
-- Trigger for updating `updated_at` column is defined in shared_triggers_and_functions.sql
