-- SHARED UTILITIES

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "pg_cron";
CREATE EXTENSION IF NOT EXISTS "vector";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";

-- Utility Functions

-- Function to generate ULID (Universally Unique Lexicographically Sortable Identifier)
CREATE OR REPLACE FUNCTION generate_ulid() RETURNS TEXT AS $$
DECLARE
    ulid TEXT;
    timestamp_part BIGINT;
    random_part BYTEA;
BEGIN
    SET TIMEZONE = 'Asia/Kolkata';
    timestamp_part := FLOOR(EXTRACT(EPOCH FROM clock_timestamp()) * 1000);
    random_part := gen_random_bytes(10);
    ulid := lpad(to_hex(timestamp_part), 12, '0') || encode(random_part, 'hex');
    RETURN ulid;
END;
$$ LANGUAGE plpgsql;

-- Function to clean old data from a table based on a specified interval
CREATE OR REPLACE FUNCTION clean_old_data(table_name TEXT, column_name TEXT, interval TEXT)
RETURNS VOID AS $$
BEGIN
    EXECUTE format(
        'DELETE FROM %I WHERE %I < NOW() - INTERVAL %L',
        table_name, column_name, interval
    );
END;
$$ LANGUAGE plpgsql;

-- Function to perform database maintenance tasks
CREATE OR REPLACE FUNCTION perform_maintenance()
RETURNS VOID AS $$
BEGIN
    PERFORM pg_stat_statements_reset();
    PERFORM vacuum analyze;
END;
$$ LANGUAGE plpgsql;

-- Schedule maintenance using pg_cron
SELECT cron.schedule('perform_maintenance', '0 3 * * *', $$CALL perform_maintenance();$$);
