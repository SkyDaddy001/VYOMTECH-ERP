-- SHARED TRIGGERS AND FUNCTIONS

-- Function to hash passwords using bcrypt
CREATE OR REPLACE FUNCTION hash_password()
RETURNS TRIGGER AS $$
BEGIN
    NEW.password = crypt(NEW.password, gen_salt('bf'));
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to hash passwords before inserting or updating the `password` column
CREATE TRIGGER trigger_hash_password
BEFORE INSERT OR UPDATE OF password ON users
FOR EACH ROW
WHEN (NEW.password IS DISTINCT FROM OLD.password)
EXECUTE FUNCTION hash_password();

-- Function to update the `updated_at` column automatically
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function to clean expired JWT tokens
CREATE OR REPLACE FUNCTION clean_expired_jwt_tokens()
RETURNS VOID AS $$
BEGIN
    DELETE FROM jwt_refresh_tokens WHERE expires_at < NOW();
END;
$$ LANGUAGE plpgsql;

-- Schedule cleaning of expired JWT tokens using pg_cron
SELECT cron.schedule('clean_expired_jwt_tokens', '0 0 * * *', $$CALL clean_expired_jwt_tokens();$$);

-- Function to encrypt sensitive data
CREATE OR REPLACE FUNCTION encrypt_sensitive_data()
RETURNS TRIGGER AS $$
BEGIN
    NEW.password = crypt(NEW.password, gen_salt('bf'));
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to encrypt passwords
CREATE TRIGGER trigger_encrypt_password
BEFORE INSERT OR UPDATE OF password ON users
FOR EACH ROW
WHEN (NEW.password IS DISTINCT FROM OLD.password)
EXECUTE FUNCTION encrypt_sensitive_data();
