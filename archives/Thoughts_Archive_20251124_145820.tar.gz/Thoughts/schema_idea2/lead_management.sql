-- LEAD MANAGEMENT SCHEMA

-- Dependencies: shared_utilities.sql, shared_triggers_and_functions.sql, user_management.sql

-- Leads
CREATE TABLE leads (
    id TEXT PRIMARY KEY DEFAULT generate_ulid(),
    pre_sales_person VARCHAR(255) NOT NULL,
    reporting_tl VARCHAR(255) NOT NULL,
    sales_person VARCHAR(255) NOT NULL,
    project_name VARCHAR(255) NOT NULL,
    milestone VARCHAR(255) NULL,
    status VARCHAR(255) NOT NULL,
    enquiry_date TIMESTAMP NULL,
    revisit_date TIMESTAMP NULL,
    booking_date TIMESTAMP NULL,
    site_visit_date TIMESTAMP NULL,
    next_follow_up_date TIMESTAMP NULL,
    lost_reason TEXT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_leads_project_name ON leads(project_name);
CREATE INDEX idx_leads_status ON leads(status);

-- Lead Campaigns
CREATE TABLE lead_campaigns (
    id TEXT PRIMARY KEY DEFAULT generate_ulid(),
    lead_id TEXT REFERENCES leads(id) ON DELETE CASCADE,
    campaign_id TEXT REFERENCES campaigns(id) ON DELETE CASCADE,
    source_id TEXT REFERENCES sources(id) ON DELETE CASCADE,
    sub_source_name VARCHAR(255) NULL,
    credit_percentage DECIMAL(5, 2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Duplicate Leads
CREATE TABLE duplicate_leads (
    id TEXT PRIMARY KEY DEFAULT generate_ulid(),
    lead_id TEXT REFERENCES leads(id) ON DELETE CASCADE,
    duplicate_lead_id TEXT REFERENCES leads(id) ON DELETE CASCADE,
    similarity_score DECIMAL(5, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Lead Reassignments
CREATE TABLE lead_reassignments (
    id TEXT PRIMARY KEY DEFAULT generate_ulid(),
    lead_id TEXT REFERENCES leads(id) ON DELETE CASCADE,
    from_team_id TEXT NOT NULL,
    to_team_id TEXT NOT NULL,
    approval_status TEXT DEFAULT 'pending', -- e.g., pending, approved, rejected
    feedback TEXT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_lead_reassignments_lead_id ON lead_reassignments(lead_id);

-- Lead Feedbacks
CREATE TABLE lead_feedbacks (
    id TEXT PRIMARY KEY DEFAULT generate_ulid(),
    lead_id TEXT REFERENCES leads(id) ON DELETE CASCADE,
    team_id TEXT NOT NULL,
    feedback TEXT NOT NULL,
    notes TEXT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Add trigger for updating `updated_at`
CREATE TRIGGER trigger_update_lead_feedbacks_updated_at
BEFORE UPDATE ON lead_feedbacks
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

-- Indexes
CREATE INDEX idx_lead_feedbacks_lead_id ON lead_feedbacks(lead_id);

-- Teams Table
CREATE TABLE teams (
    id TEXT PRIMARY KEY DEFAULT generate_ulid(),
    name VARCHAR(255) NOT NULL,
    description TEXT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Team Members Table
CREATE TABLE team_members (
    id TEXT PRIMARY KEY DEFAULT generate_ulid(),
    team_id TEXT REFERENCES teams(id) ON DELETE CASCADE,
    user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
    role VARCHAR(255) NOT NULL, -- e.g., Manager, Member
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Tasks Table
CREATE TABLE tasks (
    id TEXT PRIMARY KEY DEFAULT generate_ulid(),
    team_id TEXT REFERENCES teams(id) ON DELETE CASCADE,
    assigned_to TEXT REFERENCES users(id) ON DELETE SET NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NULL,
    status VARCHAR(50) DEFAULT 'pending', -- e.g., pending, in-progress, completed
    due_date TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Add trigger for updating `updated_at`
CREATE TRIGGER trigger_update_teams_updated_at
BEFORE UPDATE ON teams
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trigger_update_tasks_updated_at
BEFORE UPDATE ON tasks
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

-- Triggers
-- Trigger for updating `updated_at` column is defined in shared_triggers_and_functions.sql
