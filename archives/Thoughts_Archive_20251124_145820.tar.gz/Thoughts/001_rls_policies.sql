-- Row Level Security (RLS) Policies for multi-tenant schema isolation

-- Enable RLS on public tables
ALTER TABLE public.companies ENABLE ROW LEVEL SECURITY;

-- Policy for companies table: users can only see companies they own
CREATE POLICY companies_owner_policy ON public.companies
  FOR ALL USING (owner_id = auth.uid());

-- Function to get current user's company schema
CREATE OR REPLACE FUNCTION get_current_user_schema()
RETURNS TEXT AS $$
DECLARE
  schema_name TEXT;
BEGIN
  SELECT c.schema_name INTO schema_name
  FROM public.companies c
  WHERE c.owner_id = auth.uid()
  LIMIT 1;

  RETURN schema_name;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to check if user has access to a specific schema
CREATE OR REPLACE FUNCTION has_schema_access(target_schema TEXT)
RETURNS BOOLEAN AS $$
DECLARE
  user_schema TEXT;
BEGIN
  SELECT c.schema_name INTO user_schema
  FROM public.companies c
  WHERE c.owner_id = auth.uid()
  LIMIT 1;

  RETURN user_schema = target_schema;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to dynamically create RLS policies for company schemas
CREATE OR REPLACE FUNCTION create_schema_rls_policies(schema_name TEXT)
RETURNS VOID AS $$
DECLARE
  table_name TEXT;
  policy_name TEXT;
BEGIN
  -- Get all tables in the schema
  FOR table_name IN
    SELECT t.table_name
    FROM information_schema.tables t
    WHERE t.table_schema = schema_name
    AND t.table_type = 'BASE TABLE'
  LOOP
    -- Enable RLS on the table
    EXECUTE 'ALTER TABLE ' || schema_name || '.' || table_name || ' ENABLE ROW LEVEL SECURITY';

    -- Create a policy that allows access only if the user has access to the schema
    policy_name := table_name || '_schema_access_policy';
    EXECUTE 'DROP POLICY IF EXISTS ' || policy_name || ' ON ' || schema_name || '.' || table_name;
    EXECUTE 'CREATE POLICY ' || policy_name || ' ON ' || schema_name || '.' || table_name || '
      FOR ALL USING (has_schema_access(''' || schema_name || '''))';
  END LOOP;
END;
$$ LANGUAGE plpgsql;

-- Function to set up RLS for a newly created company schema
CREATE OR REPLACE FUNCTION setup_company_rls(schema_name TEXT)
RETURNS VOID AS $$
BEGIN
  -- Create RLS policies for all tables in the schema
  PERFORM create_schema_rls_policies(schema_name);

  -- Grant usage on schema to authenticated users
  EXECUTE 'GRANT USAGE ON SCHEMA ' || schema_name || ' TO authenticated';

  -- Grant permissions on all tables in the schema
  EXECUTE 'GRANT ALL ON ALL TABLES IN SCHEMA ' || schema_name || ' TO authenticated';
  EXECUTE 'GRANT ALL ON ALL SEQUENCES IN SCHEMA ' || schema_name || ' TO authenticated';

  -- Grant permissions to anon role for public access (if needed)
  EXECUTE 'GRANT USAGE ON SCHEMA ' || schema_name || ' TO anon';
  EXECUTE 'GRANT SELECT ON ALL TABLES IN SCHEMA ' || schema_name || ' TO anon';
END;
$$ LANGUAGE plpgsql;

-- Update the company creation trigger to also set up RLS
CREATE OR REPLACE FUNCTION on_company_created()
RETURNS TRIGGER AS $$
DECLARE
  schema_name TEXT;
BEGIN
  -- Create schema for the company
  schema_name := create_company_schema(NEW.name);

  -- Update the company record with the schema name
  UPDATE public.companies SET schema_name = schema_name WHERE id = NEW.id;

  -- Create tables in the schema
  PERFORM create_company_tables(schema_name);

  -- Set up RLS for the schema
  PERFORM setup_company_rls(schema_name);

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Set up RLS for existing companies (if any)
DO $$
DECLARE
  company_record RECORD;
BEGIN
  FOR company_record IN SELECT id, name, schema_name FROM public.companies
  LOOP
    IF company_record.schema_name IS NOT NULL THEN
      -- Set up RLS for existing schema
      PERFORM setup_company_rls(company_record.schema_name);
    END IF;
  END LOOP;
END $$;

-- Create a view for users to see their company information
CREATE OR REPLACE VIEW user_companies AS
SELECT
  c.id,
  c.name,
  c.type,
  c.schema_name,
  c.gst_number,
  c.pan_number,
  c.address,
  c.city,
  c.state,
  c.country,
  c.postal_code,
  c.phone,
  c.email,
  c.created_at,
  c.updated_at
FROM public.companies c
WHERE c.owner_id = auth.uid();

-- Grant access to the view
GRANT SELECT ON user_companies TO authenticated;
GRANT SELECT ON user_companies TO anon;

-- Create a function to switch to a user's company schema context
CREATE OR REPLACE FUNCTION set_company_context(company_id UUID)
RETURNS TEXT AS $$
DECLARE
  schema_name TEXT;
BEGIN
  -- Check if user owns the company
  SELECT c.schema_name INTO schema_name
  FROM public.companies c
  WHERE c.id = company_id AND c.owner_id = auth.uid();

  IF schema_name IS NULL THEN
    RAISE EXCEPTION 'Access denied or company not found';
  END IF;

  -- Set the search path to include the company schema
  EXECUTE 'SET LOCAL search_path TO ' || schema_name || ', public, auth';

  RETURN schema_name;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create audit trigger function for all company tables
CREATE OR REPLACE FUNCTION audit_trigger_function()
RETURNS TRIGGER AS $$
DECLARE
  schema_name TEXT;
  table_name TEXT;
BEGIN
  -- Get current schema
  schema_name := current_schema();

  -- Get table name
  table_name := TG_TABLE_NAME;

  -- Insert audit record
  EXECUTE 'INSERT INTO ' || schema_name || '.audit_log (table_name, operation, old_values, new_values, user_id)
           VALUES ($1, $2, $3, $4, $5)'
  USING table_name, TG_OP, CASE WHEN TG_OP != 'INSERT' THEN row_to_json(OLD) ELSE NULL END,
        CASE WHEN TG_OP != 'DELETE' THEN row_to_json(NEW) ELSE NULL END,
        auth.uid();

  RETURN CASE WHEN TG_OP = 'DELETE' THEN OLD ELSE NEW END;
END;
$$ LANGUAGE plpgsql;

-- Function to create audit triggers for all tables in a schema
CREATE OR REPLACE FUNCTION create_audit_triggers(schema_name TEXT)
RETURNS VOID AS $$
DECLARE
  table_name TEXT;
BEGIN
  FOR table_name IN
    SELECT t.table_name
    FROM information_schema.tables t
    WHERE t.table_schema = schema_name
    AND t.table_type = 'BASE TABLE'
    AND t.table_name != 'audit_log'
  LOOP
    EXECUTE 'DROP TRIGGER IF EXISTS audit_trigger_' || table_name || ' ON ' || schema_name || '.' || table_name;
    EXECUTE 'CREATE TRIGGER audit_trigger_' || table_name || '
             AFTER INSERT OR UPDATE OR DELETE ON ' || schema_name || '.' || table_name || '
             FOR EACH ROW EXECUTE FUNCTION audit_trigger_function()';
  END LOOP;
END;
$$ LANGUAGE plpgsql;

-- Update company creation to also create audit triggers
CREATE OR REPLACE FUNCTION on_company_created()
RETURNS TRIGGER AS $$
DECLARE
  schema_name TEXT;
BEGIN
  -- Create schema for the company
  schema_name := create_company_schema(NEW.name);

  -- Update the company record with the schema name
  UPDATE public.companies SET schema_name = schema_name WHERE id = NEW.id;

  -- Create tables in the schema
  PERFORM create_company_tables(schema_name);

  -- Set up RLS for the schema
  PERFORM setup_company_rls(schema_name);

  -- Create audit triggers
  PERFORM create_audit_triggers(schema_name);

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
